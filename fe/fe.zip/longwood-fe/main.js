(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/moment/locale sync recursive ^\\.\\/.*$":
/*!**************************************************!*\
  !*** ./node_modules/moment/locale sync ^\.\/.*$ ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./af": "./node_modules/moment/locale/af.js",
	"./af.js": "./node_modules/moment/locale/af.js",
	"./ar": "./node_modules/moment/locale/ar.js",
	"./ar-dz": "./node_modules/moment/locale/ar-dz.js",
	"./ar-dz.js": "./node_modules/moment/locale/ar-dz.js",
	"./ar-kw": "./node_modules/moment/locale/ar-kw.js",
	"./ar-kw.js": "./node_modules/moment/locale/ar-kw.js",
	"./ar-ly": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ly.js": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ma": "./node_modules/moment/locale/ar-ma.js",
	"./ar-ma.js": "./node_modules/moment/locale/ar-ma.js",
	"./ar-sa": "./node_modules/moment/locale/ar-sa.js",
	"./ar-sa.js": "./node_modules/moment/locale/ar-sa.js",
	"./ar-tn": "./node_modules/moment/locale/ar-tn.js",
	"./ar-tn.js": "./node_modules/moment/locale/ar-tn.js",
	"./ar.js": "./node_modules/moment/locale/ar.js",
	"./az": "./node_modules/moment/locale/az.js",
	"./az.js": "./node_modules/moment/locale/az.js",
	"./be": "./node_modules/moment/locale/be.js",
	"./be.js": "./node_modules/moment/locale/be.js",
	"./bg": "./node_modules/moment/locale/bg.js",
	"./bg.js": "./node_modules/moment/locale/bg.js",
	"./bm": "./node_modules/moment/locale/bm.js",
	"./bm.js": "./node_modules/moment/locale/bm.js",
	"./bn": "./node_modules/moment/locale/bn.js",
	"./bn.js": "./node_modules/moment/locale/bn.js",
	"./bo": "./node_modules/moment/locale/bo.js",
	"./bo.js": "./node_modules/moment/locale/bo.js",
	"./br": "./node_modules/moment/locale/br.js",
	"./br.js": "./node_modules/moment/locale/br.js",
	"./bs": "./node_modules/moment/locale/bs.js",
	"./bs.js": "./node_modules/moment/locale/bs.js",
	"./ca": "./node_modules/moment/locale/ca.js",
	"./ca.js": "./node_modules/moment/locale/ca.js",
	"./cs": "./node_modules/moment/locale/cs.js",
	"./cs.js": "./node_modules/moment/locale/cs.js",
	"./cv": "./node_modules/moment/locale/cv.js",
	"./cv.js": "./node_modules/moment/locale/cv.js",
	"./cy": "./node_modules/moment/locale/cy.js",
	"./cy.js": "./node_modules/moment/locale/cy.js",
	"./da": "./node_modules/moment/locale/da.js",
	"./da.js": "./node_modules/moment/locale/da.js",
	"./de": "./node_modules/moment/locale/de.js",
	"./de-at": "./node_modules/moment/locale/de-at.js",
	"./de-at.js": "./node_modules/moment/locale/de-at.js",
	"./de-ch": "./node_modules/moment/locale/de-ch.js",
	"./de-ch.js": "./node_modules/moment/locale/de-ch.js",
	"./de.js": "./node_modules/moment/locale/de.js",
	"./dv": "./node_modules/moment/locale/dv.js",
	"./dv.js": "./node_modules/moment/locale/dv.js",
	"./el": "./node_modules/moment/locale/el.js",
	"./el.js": "./node_modules/moment/locale/el.js",
	"./en-au": "./node_modules/moment/locale/en-au.js",
	"./en-au.js": "./node_modules/moment/locale/en-au.js",
	"./en-ca": "./node_modules/moment/locale/en-ca.js",
	"./en-ca.js": "./node_modules/moment/locale/en-ca.js",
	"./en-gb": "./node_modules/moment/locale/en-gb.js",
	"./en-gb.js": "./node_modules/moment/locale/en-gb.js",
	"./en-ie": "./node_modules/moment/locale/en-ie.js",
	"./en-ie.js": "./node_modules/moment/locale/en-ie.js",
	"./en-il": "./node_modules/moment/locale/en-il.js",
	"./en-il.js": "./node_modules/moment/locale/en-il.js",
	"./en-nz": "./node_modules/moment/locale/en-nz.js",
	"./en-nz.js": "./node_modules/moment/locale/en-nz.js",
	"./eo": "./node_modules/moment/locale/eo.js",
	"./eo.js": "./node_modules/moment/locale/eo.js",
	"./es": "./node_modules/moment/locale/es.js",
	"./es-do": "./node_modules/moment/locale/es-do.js",
	"./es-do.js": "./node_modules/moment/locale/es-do.js",
	"./es-us": "./node_modules/moment/locale/es-us.js",
	"./es-us.js": "./node_modules/moment/locale/es-us.js",
	"./es.js": "./node_modules/moment/locale/es.js",
	"./et": "./node_modules/moment/locale/et.js",
	"./et.js": "./node_modules/moment/locale/et.js",
	"./eu": "./node_modules/moment/locale/eu.js",
	"./eu.js": "./node_modules/moment/locale/eu.js",
	"./fa": "./node_modules/moment/locale/fa.js",
	"./fa.js": "./node_modules/moment/locale/fa.js",
	"./fi": "./node_modules/moment/locale/fi.js",
	"./fi.js": "./node_modules/moment/locale/fi.js",
	"./fo": "./node_modules/moment/locale/fo.js",
	"./fo.js": "./node_modules/moment/locale/fo.js",
	"./fr": "./node_modules/moment/locale/fr.js",
	"./fr-ca": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ca.js": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ch": "./node_modules/moment/locale/fr-ch.js",
	"./fr-ch.js": "./node_modules/moment/locale/fr-ch.js",
	"./fr.js": "./node_modules/moment/locale/fr.js",
	"./fy": "./node_modules/moment/locale/fy.js",
	"./fy.js": "./node_modules/moment/locale/fy.js",
	"./gd": "./node_modules/moment/locale/gd.js",
	"./gd.js": "./node_modules/moment/locale/gd.js",
	"./gl": "./node_modules/moment/locale/gl.js",
	"./gl.js": "./node_modules/moment/locale/gl.js",
	"./gom-latn": "./node_modules/moment/locale/gom-latn.js",
	"./gom-latn.js": "./node_modules/moment/locale/gom-latn.js",
	"./gu": "./node_modules/moment/locale/gu.js",
	"./gu.js": "./node_modules/moment/locale/gu.js",
	"./he": "./node_modules/moment/locale/he.js",
	"./he.js": "./node_modules/moment/locale/he.js",
	"./hi": "./node_modules/moment/locale/hi.js",
	"./hi.js": "./node_modules/moment/locale/hi.js",
	"./hr": "./node_modules/moment/locale/hr.js",
	"./hr.js": "./node_modules/moment/locale/hr.js",
	"./hu": "./node_modules/moment/locale/hu.js",
	"./hu.js": "./node_modules/moment/locale/hu.js",
	"./hy-am": "./node_modules/moment/locale/hy-am.js",
	"./hy-am.js": "./node_modules/moment/locale/hy-am.js",
	"./id": "./node_modules/moment/locale/id.js",
	"./id.js": "./node_modules/moment/locale/id.js",
	"./is": "./node_modules/moment/locale/is.js",
	"./is.js": "./node_modules/moment/locale/is.js",
	"./it": "./node_modules/moment/locale/it.js",
	"./it.js": "./node_modules/moment/locale/it.js",
	"./ja": "./node_modules/moment/locale/ja.js",
	"./ja.js": "./node_modules/moment/locale/ja.js",
	"./jv": "./node_modules/moment/locale/jv.js",
	"./jv.js": "./node_modules/moment/locale/jv.js",
	"./ka": "./node_modules/moment/locale/ka.js",
	"./ka.js": "./node_modules/moment/locale/ka.js",
	"./kk": "./node_modules/moment/locale/kk.js",
	"./kk.js": "./node_modules/moment/locale/kk.js",
	"./km": "./node_modules/moment/locale/km.js",
	"./km.js": "./node_modules/moment/locale/km.js",
	"./kn": "./node_modules/moment/locale/kn.js",
	"./kn.js": "./node_modules/moment/locale/kn.js",
	"./ko": "./node_modules/moment/locale/ko.js",
	"./ko.js": "./node_modules/moment/locale/ko.js",
	"./ky": "./node_modules/moment/locale/ky.js",
	"./ky.js": "./node_modules/moment/locale/ky.js",
	"./lb": "./node_modules/moment/locale/lb.js",
	"./lb.js": "./node_modules/moment/locale/lb.js",
	"./lo": "./node_modules/moment/locale/lo.js",
	"./lo.js": "./node_modules/moment/locale/lo.js",
	"./lt": "./node_modules/moment/locale/lt.js",
	"./lt.js": "./node_modules/moment/locale/lt.js",
	"./lv": "./node_modules/moment/locale/lv.js",
	"./lv.js": "./node_modules/moment/locale/lv.js",
	"./me": "./node_modules/moment/locale/me.js",
	"./me.js": "./node_modules/moment/locale/me.js",
	"./mi": "./node_modules/moment/locale/mi.js",
	"./mi.js": "./node_modules/moment/locale/mi.js",
	"./mk": "./node_modules/moment/locale/mk.js",
	"./mk.js": "./node_modules/moment/locale/mk.js",
	"./ml": "./node_modules/moment/locale/ml.js",
	"./ml.js": "./node_modules/moment/locale/ml.js",
	"./mn": "./node_modules/moment/locale/mn.js",
	"./mn.js": "./node_modules/moment/locale/mn.js",
	"./mr": "./node_modules/moment/locale/mr.js",
	"./mr.js": "./node_modules/moment/locale/mr.js",
	"./ms": "./node_modules/moment/locale/ms.js",
	"./ms-my": "./node_modules/moment/locale/ms-my.js",
	"./ms-my.js": "./node_modules/moment/locale/ms-my.js",
	"./ms.js": "./node_modules/moment/locale/ms.js",
	"./mt": "./node_modules/moment/locale/mt.js",
	"./mt.js": "./node_modules/moment/locale/mt.js",
	"./my": "./node_modules/moment/locale/my.js",
	"./my.js": "./node_modules/moment/locale/my.js",
	"./nb": "./node_modules/moment/locale/nb.js",
	"./nb.js": "./node_modules/moment/locale/nb.js",
	"./ne": "./node_modules/moment/locale/ne.js",
	"./ne.js": "./node_modules/moment/locale/ne.js",
	"./nl": "./node_modules/moment/locale/nl.js",
	"./nl-be": "./node_modules/moment/locale/nl-be.js",
	"./nl-be.js": "./node_modules/moment/locale/nl-be.js",
	"./nl.js": "./node_modules/moment/locale/nl.js",
	"./nn": "./node_modules/moment/locale/nn.js",
	"./nn.js": "./node_modules/moment/locale/nn.js",
	"./pa-in": "./node_modules/moment/locale/pa-in.js",
	"./pa-in.js": "./node_modules/moment/locale/pa-in.js",
	"./pl": "./node_modules/moment/locale/pl.js",
	"./pl.js": "./node_modules/moment/locale/pl.js",
	"./pt": "./node_modules/moment/locale/pt.js",
	"./pt-br": "./node_modules/moment/locale/pt-br.js",
	"./pt-br.js": "./node_modules/moment/locale/pt-br.js",
	"./pt.js": "./node_modules/moment/locale/pt.js",
	"./ro": "./node_modules/moment/locale/ro.js",
	"./ro.js": "./node_modules/moment/locale/ro.js",
	"./ru": "./node_modules/moment/locale/ru.js",
	"./ru.js": "./node_modules/moment/locale/ru.js",
	"./sd": "./node_modules/moment/locale/sd.js",
	"./sd.js": "./node_modules/moment/locale/sd.js",
	"./se": "./node_modules/moment/locale/se.js",
	"./se.js": "./node_modules/moment/locale/se.js",
	"./si": "./node_modules/moment/locale/si.js",
	"./si.js": "./node_modules/moment/locale/si.js",
	"./sk": "./node_modules/moment/locale/sk.js",
	"./sk.js": "./node_modules/moment/locale/sk.js",
	"./sl": "./node_modules/moment/locale/sl.js",
	"./sl.js": "./node_modules/moment/locale/sl.js",
	"./sq": "./node_modules/moment/locale/sq.js",
	"./sq.js": "./node_modules/moment/locale/sq.js",
	"./sr": "./node_modules/moment/locale/sr.js",
	"./sr-cyrl": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr-cyrl.js": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr.js": "./node_modules/moment/locale/sr.js",
	"./ss": "./node_modules/moment/locale/ss.js",
	"./ss.js": "./node_modules/moment/locale/ss.js",
	"./sv": "./node_modules/moment/locale/sv.js",
	"./sv.js": "./node_modules/moment/locale/sv.js",
	"./sw": "./node_modules/moment/locale/sw.js",
	"./sw.js": "./node_modules/moment/locale/sw.js",
	"./ta": "./node_modules/moment/locale/ta.js",
	"./ta.js": "./node_modules/moment/locale/ta.js",
	"./te": "./node_modules/moment/locale/te.js",
	"./te.js": "./node_modules/moment/locale/te.js",
	"./tet": "./node_modules/moment/locale/tet.js",
	"./tet.js": "./node_modules/moment/locale/tet.js",
	"./tg": "./node_modules/moment/locale/tg.js",
	"./tg.js": "./node_modules/moment/locale/tg.js",
	"./th": "./node_modules/moment/locale/th.js",
	"./th.js": "./node_modules/moment/locale/th.js",
	"./tl-ph": "./node_modules/moment/locale/tl-ph.js",
	"./tl-ph.js": "./node_modules/moment/locale/tl-ph.js",
	"./tlh": "./node_modules/moment/locale/tlh.js",
	"./tlh.js": "./node_modules/moment/locale/tlh.js",
	"./tr": "./node_modules/moment/locale/tr.js",
	"./tr.js": "./node_modules/moment/locale/tr.js",
	"./tzl": "./node_modules/moment/locale/tzl.js",
	"./tzl.js": "./node_modules/moment/locale/tzl.js",
	"./tzm": "./node_modules/moment/locale/tzm.js",
	"./tzm-latn": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm-latn.js": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm.js": "./node_modules/moment/locale/tzm.js",
	"./ug-cn": "./node_modules/moment/locale/ug-cn.js",
	"./ug-cn.js": "./node_modules/moment/locale/ug-cn.js",
	"./uk": "./node_modules/moment/locale/uk.js",
	"./uk.js": "./node_modules/moment/locale/uk.js",
	"./ur": "./node_modules/moment/locale/ur.js",
	"./ur.js": "./node_modules/moment/locale/ur.js",
	"./uz": "./node_modules/moment/locale/uz.js",
	"./uz-latn": "./node_modules/moment/locale/uz-latn.js",
	"./uz-latn.js": "./node_modules/moment/locale/uz-latn.js",
	"./uz.js": "./node_modules/moment/locale/uz.js",
	"./vi": "./node_modules/moment/locale/vi.js",
	"./vi.js": "./node_modules/moment/locale/vi.js",
	"./x-pseudo": "./node_modules/moment/locale/x-pseudo.js",
	"./x-pseudo.js": "./node_modules/moment/locale/x-pseudo.js",
	"./yo": "./node_modules/moment/locale/yo.js",
	"./yo.js": "./node_modules/moment/locale/yo.js",
	"./zh-cn": "./node_modules/moment/locale/zh-cn.js",
	"./zh-cn.js": "./node_modules/moment/locale/zh-cn.js",
	"./zh-hk": "./node_modules/moment/locale/zh-hk.js",
	"./zh-hk.js": "./node_modules/moment/locale/zh-hk.js",
	"./zh-tw": "./node_modules/moment/locale/zh-tw.js",
	"./zh-tw.js": "./node_modules/moment/locale/zh-tw.js"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	var module = __webpack_require__(id);
	return module;
}
function webpackContextResolve(req) {
	var id = map[req];
	if(!(id + 1)) { // check for number or string
		var e = new Error('Cannot find module "' + req + '".');
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return id;
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "./node_modules/moment/locale sync recursive ^\\.\\/.*$";

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error('Cannot find module "' + req + '".');
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app-const.ts":
/*!******************************!*\
  !*** ./src/app/app-const.ts ***!
  \******************************/
/*! exports provided: AppConst */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppConst", function() { return AppConst; });
var AppConst = /** @class */ (function () {
    function AppConst() {
    }
    // public static serverPath ='http://localhost:8181/longwood-be';
    AppConst.serverPath = 'http://152.136.197.88:8181/longwood-be';
    return AppConst;
}());



/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<router-outlet></router-outlet>\n<div style=\"margin-bottom: 20px;\"></div>\n"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var AppComponent = /** @class */ (function () {
    function AppComponent() {
        this.title = 'LWVlabelSystem';
    }
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        })
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var _app_routing__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app.routing */ "./src/app/app.routing.ts");
/* harmony import */ var ng2_konva__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ng2-konva */ "./node_modules/ng2-konva/ng2-konva.es5.js");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @swimlane/ngx-datatable */ "./node_modules/@swimlane/ngx-datatable/release/index.js");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var ngx_perfect_scrollbar__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-perfect-scrollbar */ "./node_modules/ngx-perfect-scrollbar/dist/ngx-perfect-scrollbar.es5.js");
/* harmony import */ var ng_sidebar__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ng-sidebar */ "./node_modules/ng-sidebar/lib/index.js");
/* harmony import */ var ng_sidebar__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(ng_sidebar__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var ng2_charts_ng2_charts__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ng2-charts/ng2-charts */ "./node_modules/ng2-charts/ng2-charts.js");
/* harmony import */ var ng2_charts_ng2_charts__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(ng2_charts_ng2_charts__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _swimlane_ngx_charts__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @swimlane/ngx-charts */ "./node_modules/@swimlane/ngx-charts/release/index.js");
/* harmony import */ var _swimlane_ngx_charts__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_swimlane_ngx_charts__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/index.js");
/* harmony import */ var ngx_chips__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ngx-chips */ "./node_modules/ngx-chips/esm5/ngx-chips.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var ng2_file_upload__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ng2-file-upload */ "./node_modules/ng2-file-upload/index.js");
/* harmony import */ var ng2_file_upload__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(ng2_file_upload__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var angular2_notifications__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! angular2-notifications */ "./node_modules/angular2-notifications/angular2-notifications.umd.js");
/* harmony import */ var angular2_notifications__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(angular2_notifications__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var ngx_pagination__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ngx-pagination */ "./node_modules/ngx-pagination/dist/ngx-pagination.js");
/* harmony import */ var angular2_hotkeys__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! angular2-hotkeys */ "./node_modules/angular2-hotkeys/index.js");
/* harmony import */ var angular2_hotkeys__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(angular2_hotkeys__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var ngx_toggle_switch__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ngx-toggle-switch */ "./node_modules/ngx-toggle-switch/ui-switch.es5.js");
/* harmony import */ var ngx_smart_modal__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ngx-smart-modal */ "./node_modules/ngx-smart-modal/esm5/ngx-smart-modal.js");
/* harmony import */ var ngx_contextmenu__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ngx-contextmenu */ "./node_modules/ngx-contextmenu/fesm5/ngx-contextmenu.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _components_login_login_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./components/login/login.component */ "./src/app/components/login/login.component.ts");
/* harmony import */ var _services_login_service__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./services/login.service */ "./src/app/services/login.service.ts");
/* harmony import */ var _services_login_guard_service__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./services/login-guard.service */ "./src/app/services/login-guard.service.ts");
/* harmony import */ var _services_image_service_image_service__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./services/image-service/image.service */ "./src/app/services/image-service/image.service.ts");
/* harmony import */ var _services_task_service_task_service__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./services/task-service/task.service */ "./src/app/services/task-service/task.service.ts");
/* harmony import */ var _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./services/helper-service/helper.service */ "./src/app/services/helper-service/helper.service.ts");
/* harmony import */ var _services_user_service_user_service__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./services/user-service/user.service */ "./src/app/services/user-service/user.service.ts");
/* harmony import */ var _services_assignment_service_assignment_service__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./services/assignment-service/assignment.service */ "./src/app/services/assignment-service/assignment.service.ts");
/* harmony import */ var _services_patient_service_patient_service__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./services/patient-service/patient.service */ "./src/app/services/patient-service/patient.service.ts");
/* harmony import */ var _services_io_service_io_service__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./services/io-service/io.service */ "./src/app/services/io-service/io.service.ts");
/* harmony import */ var _services_segment_service_segment_service__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ./services/segment-service/segment.service */ "./src/app/services/segment-service/segment.service.ts");
/* harmony import */ var _components_home_home_component__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ./components/home/home.component */ "./src/app/components/home/home.component.ts");
/* harmony import */ var _components_user_panel_user_panel_component__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! ./components/user-panel/user-panel.component */ "./src/app/components/user-panel/user-panel.component.ts");
/* harmony import */ var _components_info_panel_info_panel_component__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ./components/info-panel/info-panel.component */ "./src/app/components/info-panel/info-panel.component.ts");
/* harmony import */ var _components_annotation_panel_annotation_panel_component__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! ./components/annotation-panel/annotation-panel.component */ "./src/app/components/annotation-panel/annotation-panel.component.ts");
/* harmony import */ var _components_annotation_panel_annotation_menu_annotation_menu_component__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! ./components/annotation-panel/annotation-menu/annotation-menu.component */ "./src/app/components/annotation-panel/annotation-menu/annotation-menu.component.ts");
/* harmony import */ var _components_annotation_panel_annotation_area_annotation_area_component__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! ./components/annotation-panel/annotation-area/annotation-area.component */ "./src/app/components/annotation-panel/annotation-area/annotation-area.component.ts");
/* harmony import */ var _components_annotation_panel_image_list_image_list_component__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! ./components/annotation-panel/image-list/image-list.component */ "./src/app/components/annotation-panel/image-list/image-list.component.ts");
/* harmony import */ var _components_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! ./components/dashboard/dashboard.component */ "./src/app/components/dashboard/dashboard.component.ts");
/* harmony import */ var _components_navbar_navbar_component__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! ./components/navbar/navbar.component */ "./src/app/components/navbar/navbar.component.ts");
/* harmony import */ var _components_settings_settings_component__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! ./components/settings/settings.component */ "./src/app/components/settings/settings.component.ts");
/* harmony import */ var _components_side_panel_side_panel_component__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! ./components/side-panel/side-panel.component */ "./src/app/components/side-panel/side-panel.component.ts");
/* harmony import */ var _components_forget_password_forget_password_component__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! ./components/forget-password/forget-password.component */ "./src/app/components/forget-password/forget-password.component.ts");
/* harmony import */ var _components_admin_panel_admin_panel_component__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(/*! ./components/admin-panel/admin-panel.component */ "./src/app/components/admin-panel/admin-panel.component.ts");
/* harmony import */ var _components_create_assignment_create_assignment_component__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(/*! ./components/create-assignment/create-assignment.component */ "./src/app/components/create-assignment/create-assignment.component.ts");
/* harmony import */ var _components_upload_images_upload_images_component__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(/*! ./components/upload-images/upload-images.component */ "./src/app/components/upload-images/upload-images.component.ts");
/* harmony import */ var _components_assignment_review_assignment_review_component__WEBPACK_IMPORTED_MODULE_49__ = __webpack_require__(/*! ./components/assignment-review/assignment-review.component */ "./src/app/components/assignment-review/assignment-review.component.ts");
/* harmony import */ var _components_assignment_review_annotation_modification_annotation_modification_component__WEBPACK_IMPORTED_MODULE_50__ = __webpack_require__(/*! ./components/assignment-review/annotation-modification/annotation-modification.component */ "./src/app/components/assignment-review/annotation-modification/annotation-modification.component.ts");
/* harmony import */ var _components_select_images_select_images_component__WEBPACK_IMPORTED_MODULE_51__ = __webpack_require__(/*! ./components/select-images/select-images.component */ "./src/app/components/select-images/select-images.component.ts");
/* harmony import */ var _components_file_manager_file_manager_component__WEBPACK_IMPORTED_MODULE_52__ = __webpack_require__(/*! ./components/file-manager/file-manager.component */ "./src/app/components/file-manager/file-manager.component.ts");
/* harmony import */ var _components_file_manager_file_manager_nav_file_manager_nav_component__WEBPACK_IMPORTED_MODULE_53__ = __webpack_require__(/*! ./components/file-manager/file-manager-nav/file-manager-nav.component */ "./src/app/components/file-manager/file-manager-nav/file-manager-nav.component.ts");
/* harmony import */ var _components_file_manager_file_manager_tree_file_manager_tree_component__WEBPACK_IMPORTED_MODULE_54__ = __webpack_require__(/*! ./components/file-manager/file-manager-tree/file-manager-tree.component */ "./src/app/components/file-manager/file-manager-tree/file-manager-tree.component.ts");
/* harmony import */ var _components_file_manager_file_manager_content_file_manager_content_component__WEBPACK_IMPORTED_MODULE_55__ = __webpack_require__(/*! ./components/file-manager/file-manager-content/file-manager-content.component */ "./src/app/components/file-manager/file-manager-content/file-manager-content.component.ts");
/* harmony import */ var ng2_tree__WEBPACK_IMPORTED_MODULE_56__ = __webpack_require__(/*! ng2-tree */ "./node_modules/ng2-tree/index.js");
/* harmony import */ var ng2_tree__WEBPACK_IMPORTED_MODULE_56___default = /*#__PURE__*/__webpack_require__.n(ng2_tree__WEBPACK_IMPORTED_MODULE_56__);
/* harmony import */ var _pipes_string_filter_pipe__WEBPACK_IMPORTED_MODULE_57__ = __webpack_require__(/*! ./pipes/string-filter.pipe */ "./src/app/pipes/string-filter.pipe.ts");
/* harmony import */ var _components_file_manager_select_file_component__WEBPACK_IMPORTED_MODULE_58__ = __webpack_require__(/*! ./components/file-manager/select-file.component */ "./src/app/components/file-manager/select-file.component.ts");
/* harmony import */ var _components_file_manager_select_file_nav_select_file_nav_component__WEBPACK_IMPORTED_MODULE_59__ = __webpack_require__(/*! ./components/file-manager/select-file-nav/select-file-nav.component */ "./src/app/components/file-manager/select-file-nav/select-file-nav.component.ts");
/* harmony import */ var _components_file_manager_select_file_content_select_file_content_component__WEBPACK_IMPORTED_MODULE_60__ = __webpack_require__(/*! ./components/file-manager/select-file-content/select-file-content.component */ "./src/app/components/file-manager/select-file-content/select-file-content.component.ts");
/* harmony import */ var _components_segment_panel_segment_panel_component__WEBPACK_IMPORTED_MODULE_61__ = __webpack_require__(/*! ./components/segment-panel/segment-panel.component */ "./src/app/components/segment-panel/segment-panel.component.ts");
/* harmony import */ var _components_admin_dashboard_admin_dashboard_component__WEBPACK_IMPORTED_MODULE_62__ = __webpack_require__(/*! ./components/admin-dashboard/admin-dashboard.component */ "./src/app/components/admin-dashboard/admin-dashboard.component.ts");
/* harmony import */ var _qontu_ngx_inline_editor__WEBPACK_IMPORTED_MODULE_63__ = __webpack_require__(/*! @qontu/ngx-inline-editor */ "./node_modules/@qontu/ngx-inline-editor/ngx-inline-editor.es5.js");
/* harmony import */ var _ngx_progressbar_core__WEBPACK_IMPORTED_MODULE_64__ = __webpack_require__(/*! @ngx-progressbar/core */ "./node_modules/@ngx-progressbar/core/fesm5/ngx-progressbar-core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

































































var DEFAULT_PERFECT_SCROLLBAR_CONFIG = {
    suppressScrollX: true
};
var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_22__["AppComponent"],
                _components_login_login_component__WEBPACK_IMPORTED_MODULE_23__["LoginComponent"],
                _components_home_home_component__WEBPACK_IMPORTED_MODULE_34__["HomeComponent"],
                _components_user_panel_user_panel_component__WEBPACK_IMPORTED_MODULE_35__["UserPanelComponent"],
                _components_info_panel_info_panel_component__WEBPACK_IMPORTED_MODULE_36__["InfoPanelComponent"],
                _components_annotation_panel_annotation_panel_component__WEBPACK_IMPORTED_MODULE_37__["AnnotationPanelComponent"],
                _components_annotation_panel_annotation_menu_annotation_menu_component__WEBPACK_IMPORTED_MODULE_38__["AnnotationMenuComponent"],
                _components_annotation_panel_annotation_area_annotation_area_component__WEBPACK_IMPORTED_MODULE_39__["AnnotationAreaComponent"],
                _components_annotation_panel_image_list_image_list_component__WEBPACK_IMPORTED_MODULE_40__["ImageListComponent"],
                _components_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_41__["DashboardComponent"],
                _components_navbar_navbar_component__WEBPACK_IMPORTED_MODULE_42__["NavbarComponent"],
                _components_settings_settings_component__WEBPACK_IMPORTED_MODULE_43__["SettingsComponent"],
                _components_side_panel_side_panel_component__WEBPACK_IMPORTED_MODULE_44__["SidePanelComponent"],
                _components_forget_password_forget_password_component__WEBPACK_IMPORTED_MODULE_45__["ForgetPasswordComponent"],
                _components_admin_panel_admin_panel_component__WEBPACK_IMPORTED_MODULE_46__["AdminPanelComponent"],
                _components_create_assignment_create_assignment_component__WEBPACK_IMPORTED_MODULE_47__["CreateAssignmentComponent"],
                _components_upload_images_upload_images_component__WEBPACK_IMPORTED_MODULE_48__["UploadImagesComponent"],
                _components_assignment_review_assignment_review_component__WEBPACK_IMPORTED_MODULE_49__["AssignmentReviewComponent"],
                _components_assignment_review_annotation_modification_annotation_modification_component__WEBPACK_IMPORTED_MODULE_50__["AnnotationModificationComponent"],
                _components_select_images_select_images_component__WEBPACK_IMPORTED_MODULE_51__["SelectImagesComponent"],
                _components_file_manager_file_manager_component__WEBPACK_IMPORTED_MODULE_52__["FileManagerComponent"],
                _components_file_manager_file_manager_nav_file_manager_nav_component__WEBPACK_IMPORTED_MODULE_53__["FileManagerNavComponent"],
                _components_file_manager_file_manager_tree_file_manager_tree_component__WEBPACK_IMPORTED_MODULE_54__["FileManagerTreeComponent"],
                _components_file_manager_file_manager_content_file_manager_content_component__WEBPACK_IMPORTED_MODULE_55__["FileManagerContentComponent"],
                _pipes_string_filter_pipe__WEBPACK_IMPORTED_MODULE_57__["StringFilterPipe"],
                _components_file_manager_select_file_component__WEBPACK_IMPORTED_MODULE_58__["SelectFileComponent"],
                _components_file_manager_select_file_nav_select_file_nav_component__WEBPACK_IMPORTED_MODULE_59__["SelectFileNavComponent"],
                _components_file_manager_select_file_content_select_file_content_component__WEBPACK_IMPORTED_MODULE_60__["SelectFileContentComponent"],
                _components_segment_panel_segment_panel_component__WEBPACK_IMPORTED_MODULE_61__["SegmentPanelComponent"],
                _components_admin_dashboard_admin_dashboard_component__WEBPACK_IMPORTED_MODULE_62__["AdminDashboardComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_2__["BrowserAnimationsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_13__["FormsModule"],
                _angular_http__WEBPACK_IMPORTED_MODULE_3__["HttpModule"],
                _app_routing__WEBPACK_IMPORTED_MODULE_4__["routing"],
                ng2_konva__WEBPACK_IMPORTED_MODULE_5__["KonvaModule"],
                _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_6__["NgxDatatableModule"],
                ngx_perfect_scrollbar__WEBPACK_IMPORTED_MODULE_7__["PerfectScrollbarModule"],
                ng2_charts_ng2_charts__WEBPACK_IMPORTED_MODULE_9__["ChartsModule"],
                _swimlane_ngx_charts__WEBPACK_IMPORTED_MODULE_10__["NgxChartsModule"],
                ngx_chips__WEBPACK_IMPORTED_MODULE_12__["TagInputModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_13__["ReactiveFormsModule"],
                ng2_file_upload__WEBPACK_IMPORTED_MODULE_14__["FileUploadModule"],
                ng2_tree__WEBPACK_IMPORTED_MODULE_56__["TreeModule"],
                ngx_pagination__WEBPACK_IMPORTED_MODULE_17__["NgxPaginationModule"],
                ng_sidebar__WEBPACK_IMPORTED_MODULE_8__["SidebarModule"].forRoot(),
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_11__["NgbModule"].forRoot(),
                angular2_notifications__WEBPACK_IMPORTED_MODULE_16__["SimpleNotificationsModule"].forRoot(),
                angular2_hotkeys__WEBPACK_IMPORTED_MODULE_18__["HotkeyModule"].forRoot(),
                ngx_toggle_switch__WEBPACK_IMPORTED_MODULE_19__["UiSwitchModule"],
                ngx_smart_modal__WEBPACK_IMPORTED_MODULE_20__["NgxSmartModalModule"].forRoot(),
                ngx_contextmenu__WEBPACK_IMPORTED_MODULE_21__["ContextMenuModule"].forRoot({
                    useBootstrap4: true
                }),
                _qontu_ngx_inline_editor__WEBPACK_IMPORTED_MODULE_63__["InlineEditorModule"],
                _ngx_progressbar_core__WEBPACK_IMPORTED_MODULE_64__["NgProgressModule"]
            ],
            providers: [
                _services_login_service__WEBPACK_IMPORTED_MODULE_24__["LoginService"],
                _services_login_guard_service__WEBPACK_IMPORTED_MODULE_25__["LoginGuardService"],
                _services_image_service_image_service__WEBPACK_IMPORTED_MODULE_26__["ImageService"],
                _services_task_service_task_service__WEBPACK_IMPORTED_MODULE_27__["TaskService"],
                _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_28__["HelperService"],
                _services_user_service_user_service__WEBPACK_IMPORTED_MODULE_29__["UserService"],
                _services_assignment_service_assignment_service__WEBPACK_IMPORTED_MODULE_30__["AssignmentService"],
                _services_patient_service_patient_service__WEBPACK_IMPORTED_MODULE_31__["PatientService"],
                _services_io_service_io_service__WEBPACK_IMPORTED_MODULE_32__["IoService"],
                _services_segment_service_segment_service__WEBPACK_IMPORTED_MODULE_33__["SegmentService"],
                { provide: _angular_common__WEBPACK_IMPORTED_MODULE_15__["LocationStrategy"], useClass: _angular_common__WEBPACK_IMPORTED_MODULE_15__["HashLocationStrategy"] },
                {
                    provide: ngx_perfect_scrollbar__WEBPACK_IMPORTED_MODULE_7__["PERFECT_SCROLLBAR_CONFIG"],
                    useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
                },
                _components_file_manager_file_manager_tree_file_manager_tree_component__WEBPACK_IMPORTED_MODULE_54__["FileManagerTreeComponent"],
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_22__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/app.routing.ts":
/*!********************************!*\
  !*** ./src/app/app.routing.ts ***!
  \********************************/
/*! exports provided: routing */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routing", function() { return routing; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _components_login_login_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./components/login/login.component */ "./src/app/components/login/login.component.ts");
/* harmony import */ var _components_home_home_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/home/home.component */ "./src/app/components/home/home.component.ts");
/* harmony import */ var _components_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/dashboard/dashboard.component */ "./src/app/components/dashboard/dashboard.component.ts");
/* harmony import */ var _components_settings_settings_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/settings/settings.component */ "./src/app/components/settings/settings.component.ts");
/* harmony import */ var _components_forget_password_forget_password_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/forget-password/forget-password.component */ "./src/app/components/forget-password/forget-password.component.ts");
/* harmony import */ var _components_admin_panel_admin_panel_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./components/admin-panel/admin-panel.component */ "./src/app/components/admin-panel/admin-panel.component.ts");
/* harmony import */ var _components_create_assignment_create_assignment_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./components/create-assignment/create-assignment.component */ "./src/app/components/create-assignment/create-assignment.component.ts");
/* harmony import */ var _components_upload_images_upload_images_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./components/upload-images/upload-images.component */ "./src/app/components/upload-images/upload-images.component.ts");
/* harmony import */ var _components_assignment_review_assignment_review_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./components/assignment-review/assignment-review.component */ "./src/app/components/assignment-review/assignment-review.component.ts");
/* harmony import */ var _components_assignment_review_annotation_modification_annotation_modification_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./components/assignment-review/annotation-modification/annotation-modification.component */ "./src/app/components/assignment-review/annotation-modification/annotation-modification.component.ts");
/* harmony import */ var _components_select_images_select_images_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./components/select-images/select-images.component */ "./src/app/components/select-images/select-images.component.ts");
/* harmony import */ var _components_file_manager_file_manager_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./components/file-manager/file-manager.component */ "./src/app/components/file-manager/file-manager.component.ts");
/* harmony import */ var _components_file_manager_select_file_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./components/file-manager/select-file.component */ "./src/app/components/file-manager/select-file.component.ts");
/* harmony import */ var _components_segment_panel_segment_panel_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./components/segment-panel/segment-panel.component */ "./src/app/components/segment-panel/segment-panel.component.ts");
/* harmony import */ var _services_login_guard_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./services/login-guard.service */ "./src/app/services/login-guard.service.ts");
/* harmony import */ var _components_admin_dashboard_admin_dashboard_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./components/admin-dashboard/admin-dashboard.component */ "./src/app/components/admin-dashboard/admin-dashboard.component.ts");

















var appRoutes = [
    {
        path: '',
        redirectTo: '/login',
        pathMatch: 'full'
    },
    {
        path: 'login',
        component: _components_login_login_component__WEBPACK_IMPORTED_MODULE_1__["LoginComponent"]
    },
    {
        path: 'home/:assignmentItemId',
        component: _components_home_home_component__WEBPACK_IMPORTED_MODULE_2__["HomeComponent"],
        canActivate: [_services_login_guard_service__WEBPACK_IMPORTED_MODULE_15__["LoginGuardService"]]
    },
    {
        path: 'dashboard',
        component: _components_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_3__["DashboardComponent"],
        canActivate: [_services_login_guard_service__WEBPACK_IMPORTED_MODULE_15__["LoginGuardService"]]
    },
    {
        path: 'settings',
        component: _components_settings_settings_component__WEBPACK_IMPORTED_MODULE_4__["SettingsComponent"],
        canActivate: [_services_login_guard_service__WEBPACK_IMPORTED_MODULE_15__["LoginGuardService"]]
    },
    {
        path: 'forgetPassword',
        component: _components_forget_password_forget_password_component__WEBPACK_IMPORTED_MODULE_5__["ForgetPasswordComponent"]
    },
    {
        path: 'adminPanel',
        component: _components_admin_panel_admin_panel_component__WEBPACK_IMPORTED_MODULE_6__["AdminPanelComponent"],
        canActivate: [_services_login_guard_service__WEBPACK_IMPORTED_MODULE_15__["LoginGuardService"]]
    },
    {
        path: 'createAssignment',
        component: _components_create_assignment_create_assignment_component__WEBPACK_IMPORTED_MODULE_7__["CreateAssignmentComponent"],
        canActivate: [_services_login_guard_service__WEBPACK_IMPORTED_MODULE_15__["LoginGuardService"]]
    },
    {
        path: 'uploadImages',
        component: _components_upload_images_upload_images_component__WEBPACK_IMPORTED_MODULE_8__["UploadImagesComponent"],
        canActivate: [_services_login_guard_service__WEBPACK_IMPORTED_MODULE_15__["LoginGuardService"]]
    },
    {
        path: 'assignmentReview/:id',
        component: _components_assignment_review_assignment_review_component__WEBPACK_IMPORTED_MODULE_9__["AssignmentReviewComponent"],
        canActivate: [_services_login_guard_service__WEBPACK_IMPORTED_MODULE_15__["LoginGuardService"]]
    },
    {
        path: 'annotationModification/:taskId',
        component: _components_assignment_review_annotation_modification_annotation_modification_component__WEBPACK_IMPORTED_MODULE_10__["AnnotationModificationComponent"],
        canActivate: [_services_login_guard_service__WEBPACK_IMPORTED_MODULE_15__["LoginGuardService"]]
    },
    {
        path: 'selectImages',
        component: _components_select_images_select_images_component__WEBPACK_IMPORTED_MODULE_11__["SelectImagesComponent"],
        canActivate: [_services_login_guard_service__WEBPACK_IMPORTED_MODULE_15__["LoginGuardService"]]
    },
    {
        path: 'fileManager',
        component: _components_file_manager_file_manager_component__WEBPACK_IMPORTED_MODULE_12__["FileManagerComponent"],
        canActivate: [_services_login_guard_service__WEBPACK_IMPORTED_MODULE_15__["LoginGuardService"]]
    },
    {
        path: 'selectFile/:id',
        component: _components_file_manager_select_file_component__WEBPACK_IMPORTED_MODULE_13__["SelectFileComponent"],
        canActivate: [_services_login_guard_service__WEBPACK_IMPORTED_MODULE_15__["LoginGuardService"]]
    },
    {
        path: 'segment/:assignmentItemId',
        component: _components_segment_panel_segment_panel_component__WEBPACK_IMPORTED_MODULE_14__["SegmentPanelComponent"],
        canActivate: [_services_login_guard_service__WEBPACK_IMPORTED_MODULE_15__["LoginGuardService"]]
    },
    {
        path: 'adminDashboard',
        component: _components_admin_dashboard_admin_dashboard_component__WEBPACK_IMPORTED_MODULE_16__["AdminDashboardComponent"],
        canActivate: [_services_login_guard_service__WEBPACK_IMPORTED_MODULE_15__["LoginGuardService"]]
    }
];
var routing = _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forRoot(appRoutes);


/***/ }),

/***/ "./src/app/components/admin-dashboard/admin-dashboard.component.css":
/*!**************************************************************************!*\
  !*** ./src/app/components/admin-dashboard/admin-dashboard.component.css ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "img:hover {\n  background-color: slategray;\n  cursor: pointer;\n}\n"

/***/ }),

/***/ "./src/app/components/admin-dashboard/admin-dashboard.component.html":
/*!***************************************************************************!*\
  !*** ./src/app/components/admin-dashboard/admin-dashboard.component.html ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div *ngIf=\"!loading\" background-color=\"black\">\n  <app-navbar></app-navbar>\n\n  <!-- Container for sidebar(s) + page content -->\n  <ng-sidebar-container style=\"height: 800px;\">\n    <!-- A sidebar -->\n    <ng-sidebar [(opened)]=\"_opened\">\n      <app-side-panel></app-side-panel>\n    </ng-sidebar>\n\n    <!-- Page content -->\n    <div ng-sidebar-content>\n      <div class=\"main\" style=\"margin:auto; margin-top: 50px; width: 60%;\">\n        <div class=\"page-header text-center rounded bg-dark text-white\" style=\"padding-top: 10px; padding-bottom: 10px;\">\n          <h2>Admin Panel Dashboard</h2>\n        </div>\n        <hr>\n        <div class=\"row text-center\">\n          <div class=\"col-4\" >\n            <img class=\"img-thumbnail\" style=\"width: 200px;\" src=\"../../../assets/images/admin-panel.png\" alt=\"Admin\" routerLink=\"/adminPanel\">\n            <br><br>\n            <h4>Admin Panel</h4>\n          </div>\n          <div class=\"col-4\" >\n            <img class=\"img-thumbnail\" style=\"width: 200px;\" src=\"../../../assets/images/file-manager.png\" alt=\"File Manager\" routerLink=\"/fileManager\">\n            <br><br>\n            <h4>File Manager</h4>\n          </div>\n          <div class=\"col-4\" >\n            <!--<img class=\"img-thumbnail\" style=\"width: 200px;\" src=\"../../../assets/images/admin-panel.png\" alt=\"Admin\">-->\n            <!--<br><br>-->\n            <!--<h4>TBD</h4>-->\n          </div>\n        </div>\n      </div>\n    </div>\n  </ng-sidebar-container>\n\n</div>\n<div *ngIf=\"loading\" class=\"text-center\" style=\"margin:150px 200px 0 200px\">\n  <i class=\"fa fa-spinner fa-5x faa-spin animated\"></i>\n</div>\n"

/***/ }),

/***/ "./src/app/components/admin-dashboard/admin-dashboard.component.ts":
/*!*************************************************************************!*\
  !*** ./src/app/components/admin-dashboard/admin-dashboard.component.ts ***!
  \*************************************************************************/
/*! exports provided: AdminDashboardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdminDashboardComponent", function() { return AdminDashboardComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _app_const__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../app-const */ "./src/app/app-const.ts");
/* harmony import */ var _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/helper-service/helper.service */ "./src/app/services/helper-service/helper.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var AdminDashboardComponent = /** @class */ (function () {
    function AdminDashboardComponent(helperService) {
        this.helperService = helperService;
        this.serverPath = _app_const__WEBPACK_IMPORTED_MODULE_1__["AppConst"].serverPath;
        this._opened = false;
    }
    AdminDashboardComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.helperService.sideMenuStatus$.subscribe(function (open) {
            _this._opened = open;
        });
    };
    AdminDashboardComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-admin-dashboard',
            template: __webpack_require__(/*! ./admin-dashboard.component.html */ "./src/app/components/admin-dashboard/admin-dashboard.component.html"),
            styles: [__webpack_require__(/*! ./admin-dashboard.component.css */ "./src/app/components/admin-dashboard/admin-dashboard.component.css")]
        }),
        __metadata("design:paramtypes", [_services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_2__["HelperService"]])
    ], AdminDashboardComponent);
    return AdminDashboardComponent;
}());



/***/ }),

/***/ "./src/app/components/admin-panel/admin-panel.component.css":
/*!******************************************************************!*\
  !*** ./src/app/components/admin-panel/admin-panel.component.css ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".ngx-datatable.bootstrap:not(.cell-selection) .datatable-body-row:hover, .ngx-\ndatatable.material:not(.cell-selection) .datatable-body-row:hover .datatable-\nrow-group {\n  cursor: pointer;\n}\n\n\n\n"

/***/ }),

/***/ "./src/app/components/admin-panel/admin-panel.component.html":
/*!*******************************************************************!*\
  !*** ./src/app/components/admin-panel/admin-panel.component.html ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div *ngIf=\"!loading\" background-color=\"black\">\n  <app-navbar></app-navbar>\n\n  <!-- Container for sidebar(s) + page content -->\n  <ng-sidebar-container style=\"height: 800px;\">\n    <!-- A sidebar -->\n    <ng-sidebar [(opened)]=\"_opened\">\n      <app-side-panel></app-side-panel>\n    </ng-sidebar>\n\n    <!-- Page content -->\n    <div ng-sidebar-content>\n      <div class=\"main\" style=\"margin:auto; margin-top: 50px; width: 90%\">\n        <nav class=\"navbar navbar-expand-lg navbar-light bg-secondary justify-content-between\">\n          <a class=\"navbar-brand\" style=\"color: white;\">Admin Panel</a>\n        </nav>\n        <br>\n\n        <div class=\"row\">\n          <div class=\"col-10\" style=\"border:1px solid black;\">\n            <div style=\"margin-top: 20px; margin-bottom: 20px;\">\n\n              <ngb-tabset>\n                <ngb-tab>\n                  <ng-template ngbTabTitle><span style=\"color:black;\">Assignment</span></ng-template>\n                  <ng-template ngbTabContent>\n                    <br>\n                    <h5>All Assignment List</h5>\n                    <br>\n                    <ngx-datatable style=\"height: 300px;\" class='material' [rows]='assignmentList' [columns]='columns' [columnMode]=\"'force'\"\n                                   [headerHeight]=\"50\" [rowHeight]=\"50\" [rowClass]=\"getRowClass\" [scrollbarV]=\"true\">\n\n                      <ngx-datatable-column name=\"Name\">\n                        <ng-template let-column=\"column\" let-sort=\"sortFn\" ngx-datatable-header-template>\n                          <span (click)=\"sort()\">{{column.name}}</span>\n                        </ng-template>\n                        <ng-template let-row=\"row\" let-value=\"value\" ngx-datatable-cell-template>\n                          <strong (click)=\"test(row)\">{{value}}</strong>\n                        </ng-template>\n                      </ngx-datatable-column>\n\n                      <ngx-datatable-column name=\"creationDate\">\n                        <ng-template let-column=\"column\" let-sort=\"sortFn\" ngx-datatable-header-template>\n                          <span (click)=\"sort()\">{{column.name}}</span>\n                        </ng-template>\n                        <ng-template let-value=\"value\" ngx-datatable-cell-template>\n                          <span>{{value}}</span>\n                        </ng-template>\n                      </ngx-datatable-column>\n\n                      <ngx-datatable-column name=\"modifiedDate\">\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\n                          {{column.name}}\n                        </ng-template>\n                        <ng-template let-value=\"value\" ngx-datatable-cell-template>\n                          <span>{{value}}</span>\n                        </ng-template>\n                      </ngx-datatable-column>\n\n                      <ngx-datatable-column name=\"labeler1\">\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\n                          {{column.name}}\n                        </ng-template>\n                        <ng-template let-value=\"value\" ngx-datatable-cell-template>\n                          <span>{{value}}</span>\n                        </ng-template>\n                      </ngx-datatable-column>\n\n                      <ngx-datatable-column name=\"labeler2\">\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\n                          {{column.name}}\n                        </ng-template>\n                        <ng-template let-value=\"value\" ngx-datatable-cell-template>\n                          <span>{{value}}</span>\n                        </ng-template>\n                      </ngx-datatable-column>\n\n                      <ngx-datatable-column name=\"status\">\n                        <ng-template let-column=\"column\" let-sort=\"sortFn\" ngx-datatable-header-template>\n                          <span (click)=\"sort()\">{{column.name}}</span>\n                        </ng-template>\n                        <ng-template let-value=\"value\" ngx-datatable-cell-template>\n                          <span>{{value}}</span>\n                        </ng-template>\n                      </ngx-datatable-column>\n\n                      <ngx-datatable-column name=\"Actions\" sortable=\"false\" prop=\"action\">\n                        <ng-template let-column=\"column\" let-sort=\"sortFn\" ngx-datatable-header-template>\n                          {{column.name}}\n                        </ng-template>\n                        <ng-template let-row=\"row\" let-value=\"value\" ngx-datatable-cell-template>\n                          <button class=\"btn btn-dark btn-sm\" style=\"cursor: pointer;\" (click)=\"removeAssignment(row)\">\n                            <i class=\"fa fa-trash\" aria-hidden=\"true\"></i>\n                          </button>\n                        </ng-template>\n                      </ngx-datatable-column>\n                    </ngx-datatable>\n                    <br>\n                    <a class=\"btn btn-outline-dark btn-sm \" routerLink=\"/createAssignment\" routerLinkActive=\"active\">Create</a>\n                  </ng-template>\n                </ngb-tab>\n\n                <ngb-tab>\n                  <ng-template ngbTabTitle><span style=\"color:black;\">Review</span></ng-template>\n                  <ng-template ngbTabContent>\n                    <br>\n                    <h5>Assignments Under Review</h5>\n                    <br>\n                    <ngx-datatable style=\"height: 300px;\" class='material' [rows]='onReviewAssignmentList' [columns]='columns'\n                                   [columnMode]=\"'force'\" [headerHeight]=\"50\" [rowHeight]=\"50\" [rowClass]=\"getRowClass\" [scrollbarV]=\"true\" >\n                      <ngx-datatable-column name=\"Name\" prop=\"name\">\n                        <ng-template let-column=\"column\" let-sort=\"sortFn\" ngx-datatable-header-template>\n                          <span  (click)=\"sort()\">{{column.name}}</span>\n                        </ng-template>\n                        <ng-template let-row=\"row\" let-value=\"value\" ngx-datatable-cell-template>\n                          <strong (click)=\"onSelectReviewAssignment(row)\" style=\"cursor: pointer; color: blue;\">{{value}}</strong>\n                        </ng-template>\n                      </ngx-datatable-column>\n\n                      <ngx-datatable-column name=\"creationDate\">\n                        <ng-template let-column=\"column\" let-sort=\"sortFn\" ngx-datatable-header-template>\n                          <span (click)=\"sort()\">{{column.name}}</span>\n                        </ng-template>\n                        <ng-template let-value=\"value\" ngx-datatable-cell-template>\n                          <span>{{value}}</span>\n                        </ng-template>\n                      </ngx-datatable-column>\n\n                      <ngx-datatable-column name=\"modifiedDate\">\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\n                          {{column.name}}\n                        </ng-template>\n                        <ng-template let-value=\"value\" ngx-datatable-cell-template>\n                          <span>{{value}}</span>\n                        </ng-template>\n                      </ngx-datatable-column>\n\n                      <ngx-datatable-column name=\"labeler1\">\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\n                          {{column.name}}\n                        </ng-template>\n                        <ng-template let-value=\"value\" ngx-datatable-cell-template>\n                          <span>{{value}}</span>\n                        </ng-template>\n                      </ngx-datatable-column>\n\n                      <ngx-datatable-column name=\"labeler2\">\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\n                          {{column.name}}\n                        </ng-template>\n                        <ng-template let-value=\"value\" ngx-datatable-cell-template>\n                          <span>{{value}}</span>\n                        </ng-template>\n                      </ngx-datatable-column>\n\n                      <ngx-datatable-column name=\"status\">\n                        <ng-template let-column=\"column\" let-sort=\"sortFn\" ngx-datatable-header-template>\n                          <span (click)=\"sort()\">{{column.name}}</span>\n                        </ng-template>\n                        <ng-template let-value=\"value\" ngx-datatable-cell-template>\n                          <span>{{value}}</span>\n                        </ng-template>\n                      </ngx-datatable-column>\n\n                      <ngx-datatable-column name=\"reviews\">\n                        <ng-template let-column=\"column\" let-sort=\"sortFn\" ngx-datatable-header-template>\n                          <span (click)=\"sort()\">{{column.name}}</span>\n                        </ng-template>\n                        <ng-template let-value=\"value\" ngx-datatable-cell-template>\n                          <span>{{value}}</span>\n                        </ng-template>\n                      </ngx-datatable-column>\n\n                      <ngx-datatable-column name=\"action\" sortable=\"false\" prop=\"action\">\n                        <ng-template let-column=\"column\" let-sort=\"sortFn\" ngx-datatable-header-template>\n                          {{column.name}}\n                        </ng-template>\n                        <ng-template let-row=\"row\" let-value=\"value\" ngx-datatable-cell-template>\n                          <button class=\"btn btn-dark btn-sm\" style=\"cursor: pointer;\" (click)=\"removeAssignment(row)\">\n                            <i class=\"fa fa-trash\" aria-hidden=\"true\"></i>\n                          </button>\n                        </ng-template>\n                      </ngx-datatable-column>\n                    </ngx-datatable>\n                  </ng-template>\n                </ngb-tab>\n              </ngb-tabset>\n            </div>\n          </div>\n          <div id=\"right-panel\" class=\"col-2\" style=\"border:1px solid black;\">\n            <perfect-scrollbar id=\"scroll-bar\" style=\"max-height:1000px;margin-top:10px;margin-bottom: 10px;\" [config]=\"config\">\n              <h5>Labeler List</h5>\n              <br>\n              <div class=\"text-center\">\n                <div *ngFor=\"let user of userList; let i=index;\" class=\"row\">\n                  <div class=\"col-4\">\n                    <i class=\"fa fa-user\"></i>\n                  </div>\n                  <div class=\"col-8\">\n                    <p>{{user.lastName}}, {{user.firstName}}</p>\n                  </div>\n                </div>\n              </div>\n            </perfect-scrollbar>\n          </div>\n        </div>\n      </div>\n    </div>\n  </ng-sidebar-container>\n\n</div>\n<div *ngIf=\"loading\" class=\"text-center\" style=\"margin:150px 200px 0 200px\">\n  <i class=\"fa fa-spinner fa-5x faa-spin animated\"></i>\n</div>\n"

/***/ }),

/***/ "./src/app/components/admin-panel/admin-panel.component.ts":
/*!*****************************************************************!*\
  !*** ./src/app/components/admin-panel/admin-panel.component.ts ***!
  \*****************************************************************/
/*! exports provided: AdminPanelComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdminPanelComponent", function() { return AdminPanelComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _app_const__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../app-const */ "./src/app/app-const.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/helper-service/helper.service */ "./src/app/services/helper-service/helper.service.ts");
/* harmony import */ var _services_user_service_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/user-service/user.service */ "./src/app/services/user-service/user.service.ts");
/* harmony import */ var _services_assignment_service_assignment_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/assignment-service/assignment.service */ "./src/app/services/assignment-service/assignment.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var AdminPanelComponent = /** @class */ (function () {
    function AdminPanelComponent(helperService, assignmentService, userService, router) {
        this.helperService = helperService;
        this.assignmentService = assignmentService;
        this.userService = userService;
        this.router = router;
        this.assignmentList = [];
        this.onReviewAssignmentList = [];
        this.userList = [];
        this.taskNumberList = [];
        this.finishedTaskNumberList = [];
        this.finishedTaskNumberIndex = 0;
        this.rows1 = [];
        this.rows2 = [];
        this.columns = [
            // { name: 'Number', prop: 'number' },
            { name: 'Name', prop: 'name' },
            { name: 'Creation Date', prop: 'creationDate' },
            { name: 'Modified Date', prop: 'modifiedDate' },
            { name: 'Labeler1', prop: 'labeler1' },
            { name: 'Labeler2', prop: 'labeler2' },
            // { name: 'Labeler3', prop: 'labeler3' },
            // { name: 'Labeler4', prop: 'labeler4' },
            { name: 'Status', prop: 'status' },
            { name: 'Reviews', prop: 'reviews' },
            { name: 'Action', prop: 'action' }
        ];
        this.serverPath = _app_const__WEBPACK_IMPORTED_MODULE_1__["AppConst"].serverPath;
        this._opened = false;
        this.selected = [];
    }
    AdminPanelComponent.prototype._toggleSidebar = function () {
        this._opened = !this._opened;
    };
    AdminPanelComponent.prototype.getRouterOutletState = function (outlet) {
        return outlet.isActivated ? outlet.activatedRoute : '';
    };
    AdminPanelComponent.prototype.test = function (row) {
        console.log(row);
    };
    AdminPanelComponent.prototype.removeAssignment = function (assignment) {
        var _this = this;
        console.log(assignment);
        console.log(assignment.id);
        this.assignmentService.removeAssignmentByAssignmentId(assignment.id).subscribe(function (res) {
            var index = _this.onReviewAssignmentList.indexOf(assignment);
            if (index > -1) {
                _this.onReviewAssignmentList.splice(index, 1);
            }
            else {
                index = _this.assignmentList.indexOf(assignment);
                if (index > -1) {
                    _this.assignmentList.splice(index, 1);
                }
            }
        }, function (error) {
            console.log(error);
        });
    };
    AdminPanelComponent.prototype.onGetAllAssignments = function () {
        var _this = this;
        this.assignmentService.getAllAssignments().subscribe(function (res) {
            _this.assignmentList = res.json();
            console.log(_this.assignmentList);
            for (var index = 0; index < _this.assignmentList.length; index++) {
                var assignment = _this.assignmentList[index];
                if (assignment.status != 3) {
                    _this.rows1.push({
                        'id': assignment['id'],
                        'number': assignment['number'],
                        'name': assignment['name'],
                        'creationDate': assignment['creationDate'],
                        'latestDate': assignment['latestDate'],
                        'modifiedDate': assignment['modifiedDate'],
                        'labeler1': assignment['userAssignmentList'][0] ? assignment['userAssignmentList'][0]['user']['lastName'] + ', ' + assignment['userAssignmentList'][0]['user']['firstName'] : 'N/A',
                        'labeler2': assignment['userAssignmentList'][1] ? assignment['userAssignmentList'][1]['user']['lastName'] + ', ' + assignment['userAssignmentList'][1]['user']['firstName'] : 'N/A',
                        'labeler3': assignment['userAssignmentList'][2] ? assignment['userAssignmentList'][2]['user']['lastName'] + ', ' + assignment['userAssignmentList'][2]['user']['firstName'] : 'N/A',
                        'labeler4': assignment['userAssignmentList'][3] ? assignment['userAssignmentList'][3]['user']['lastName'] + ', ' + assignment['userAssignmentList'][3]['user']['firstName'] : 'N/A',
                        'status': assignment['status'],
                        'Action': 'action'
                    });
                }
                else {
                    // let itemList = assignment.assignmentItemList;
                    // let taskNumber = itemList.length;
                    // let finishedTaskNumber = 0;
                    // for(let i in itemList){
                    //   if(itemList[i].status == 3){
                    //     finishedTaskNumber += 1;
                    //   }
                    // }
                    // this.taskNumberList.push(taskNumber);
                    // this.finishedTaskNumberList.push(finishedTaskNumber);
                    // this.assignmentService.getAssignmentItemListByAssignment(assignment['id']).subscribe(
                    //   list => {
                    //     let itemList = list.json();
                    //     let taskNumber = itemList.length;
                    //     let finishedTaskNumber = 0;
                    //     for (let i in itemList) {
                    //       if (itemList[i].status == 3) {
                    //         finishedTaskNumber += 1;
                    //       }
                    //     }
                    //     this.taskNumberList.push(taskNumber);
                    //     this.finishedTaskNumberList.push(finishedTaskNumber);
                    //     this.finishedTaskNumberIndex += 1;
                    //     console.log(this.rows2);
                    //       this.onReviewAssignmentList = Object.assign( this.rows2);
                    //   },
                    //   error => {
                    //     console.log(error);
                    //   }
                    // );
                    _this.rows2.push({
                        'id': assignment['id'],
                        'number': assignment['number'],
                        'name': assignment['name'],
                        'creationDate': assignment['creationDate'],
                        'latestDate': assignment['latestDate'],
                        'modifiedDate': assignment['modifiedDate'],
                        'labeler1': assignment['userAssignmentList'][0] ? assignment['userAssignmentList'][0]['user']['lastName'] + ', ' + assignment['userAssignmentList'][0]['user']['firstName'] : 'N/A',
                        'labeler2': assignment['userAssignmentList'][1] ? assignment['userAssignmentList'][1]['user']['lastName'] + ', ' + assignment['userAssignmentList'][1]['user']['firstName'] : 'N/A',
                        'labeler3': assignment['userAssignmentList'][2] ? assignment['userAssignmentList'][2]['user']['lastName'] + ', ' + assignment['userAssignmentList'][2]['user']['firstName'] : 'N/A',
                        'labeler4': assignment['userAssignmentList'][3] ? assignment['userAssignmentList'][3]['user']['lastName'] + ', ' + assignment['userAssignmentList'][3]['user']['firstName'] : 'N/A',
                        'status': assignment['status'],
                        'reviews': assignment['finishedAssignmentItem'] + " / " + assignment['totalAssignmentItem']
                    });
                }
            }
            _this.assignmentList = _this.rows1;
            _this.onReviewAssignmentList = _this.rows2;
        }, function (error) {
            console.log(error);
        });
    };
    AdminPanelComponent.prototype.onSelectReviewAssignment = function (assignment) {
        console.log(assignment);
        var id = assignment.id;
        this.router.navigate(['/assignmentReview', id]);
    };
    AdminPanelComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.onGetAllAssignments();
        this.helperService.sideMenuStatus$.subscribe(function (open) {
            _this._opened = open;
        });
        this.userService.getUserList().subscribe(function (res) {
            var userList = res.json();
            for (var i in userList) {
                if (userList[i].authorities[0].authority == "ROLE_USER") {
                    _this.userList.push(userList[i]);
                }
            }
        }, function (error) {
            console.log(error);
        });
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('sampleT'),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"])
    ], AdminPanelComponent.prototype, "sampleT", void 0);
    AdminPanelComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-admin-panel',
            template: __webpack_require__(/*! ./admin-panel.component.html */ "./src/app/components/admin-panel/admin-panel.component.html"),
            styles: [__webpack_require__(/*! ./admin-panel.component.css */ "./src/app/components/admin-panel/admin-panel.component.css")]
        }),
        __metadata("design:paramtypes", [_services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_3__["HelperService"],
            _services_assignment_service_assignment_service__WEBPACK_IMPORTED_MODULE_5__["AssignmentService"],
            _services_user_service_user_service__WEBPACK_IMPORTED_MODULE_4__["UserService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], AdminPanelComponent);
    return AdminPanelComponent;
}());



/***/ }),

/***/ "./src/app/components/annotation-panel/annotation-area/annotation-area.component.css":
/*!*******************************************************************************************!*\
  !*** ./src/app/components/annotation-panel/annotation-area/annotation-area.component.css ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".box {\n  border: 1px solid gray;\n}\n"

/***/ }),

/***/ "./src/app/components/annotation-panel/annotation-area/annotation-area.component.html":
/*!********************************************************************************************!*\
  !*** ./src/app/components/annotation-panel/annotation-area/annotation-area.component.html ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div style=\"margin-top:5px;\">\n  <div class=\"row\">\n    <div class=\"col-2\"></div>\n    <div class=\"col-3\">\n      <button class=\"btn btn-dark btn-block\" (click)=\"saveImageAnnotation()\">Submit All Changes</button>\n    </div>\n    <div class=\"col-5\">\n      <div class=\"btn-group pull-right\">\n        <button class=\"btn\" (click)=\"selectRect()\" >\n          <i class=\"fa fa-square-o\"></i>\n        </button>&nbsp;\n        <button class=\"btn\" (click)=\"selectDot()\" autofocus=\"autofocus\">\n          <i class=\"fa fa-plus\"></i>\n        </button>&nbsp;\n        <button class=\"btn\" (click)=\"selectEraser()\">\n          <i class=\"fa fa-eraser\"></i>\n        </button>&nbsp;\n        <button class=\"btn\" (click)=\"selectMouse()\">\n          <i class=\"fa fa-mouse-pointer\"></i>\n        </button>&nbsp;\n        <button class=\"btn\" (click)=\"deleteAllDots()\">\n          <i class=\"fa fa-ban\"></i>\n        </button>&nbsp;&nbsp;&nbsp;\n        <button class=\"btn\" (click)=\"onZoomIn()\">\n          <i class=\"fa fa-search-plus\"></i>\n        </button>&nbsp;\n        <button class=\"btn\" (click)=\"onZoomOut()\">\n          <i class=\"fa fa-search-minus\"></i>\n        </button>&nbsp;\n        <button class=\"btn\" (click)=\"onResetImage()\">\n          <i class=\"fa fa-refresh\"></i>\n        </button>&nbsp;\n        <button class=\"btn\" (click)=\"onDragTool()\">\n          <i class=\"fa fa-hand-stop-o\"></i>\n        </button>&nbsp;\n      </div>\n    </div>\n    <div class=\"col-2\"></div>\n  </div>\n</div>\n<div id=\"stage-div\" style=\"  margin:auto; margin-top:20px; \">\n  <ko-stage #stage [config]=\"configStage\" id=\"canvas\" (mousedown)=\"drawingOn()\" (mouseup)=\"drawingOff()\" class=\"border\">\n    <ko-layer #imageLayer id=\"image-layer\">\n      <ko-image #image [config]=\"imageConfig\"></ko-image>\n    </ko-layer>\n    <ko-layer #rectLayer>\n      <ko-rect #rect *ngFor=\"let rectItem of rectConfigList; let i = index; let l = last\" [config]=\"rectItem\"\n               (click)=\"onClickRect($event)\"></ko-rect>\n    </ko-layer>\n    <ko-layer #dotLayer>\n      <ko-circle #dot *ngFor=\"let dotItem of dotConfigList; let i = index; let l = last\" [config]=\"dotItem\"\n                 (mouseover)=\"onMouseOverDot($event)\"\n                 (click)=\"onClickDot($event)\"></ko-circle>\n    </ko-layer>\n  </ko-stage>\n</div>\n<br>\n<div *ngIf=\"displaySavedSuccess\" class=\"alert alert-success\">Annotation saved successfully.</div>\n<div *ngIf=\"savingFailed\" class=\"alert alert-danger\">Failed to save annotation. Please try again later.</div>\n\n\n\n<div class=\"row\">\n  <div class=\"col-6\">\n    <div class=\"form-check form-check-inline\">\n      <input class=\"form-check-input\" type=\"radio\" name=\"status\" id=\"inlineRadio1\" [value]=\"0\" [(ngModel)]=\"status\">\n      <label class=\"form-check-label\" for=\"inlineRadio1\">Normal</label>\n    </div>\n    <div class=\"form-check form-check-inline\">\n      <input class=\"form-check-input\" type=\"radio\" name=\"status\" id=\"inlineRadio2\" [value]=\"1\" [(ngModel)]=\"status\">\n      <label class=\"form-check-label\" for=\"inlineRadio2\">Abnormal</label>\n    </div>\n    <div class=\"form-check form-check-inline\">\n      <input class=\"form-check-input\" type=\"radio\" name=\"status\" id=\"inlineRadio2\" [value]=\"2\" [(ngModel)]=\"status\"\n             checked=\"checked\">\n      <label class=\"form-check-label\" for=\"inlineRadio2\">N/A</label>\n    </div>\n    <p>Image Type:\n      <span [ngSwitch]=\"currentTask?.taskType\">\n        <span *ngSwitchCase=\"0\">\n          <b>Dot</b>\n        </span>\n        <span *ngSwitchCase=\"1\">\n          <b>Rect</b>\n        </span>\n      </span>\n    </p>\n  </div>\n  <div class=\"col-6\">\n    <p>X:\n      <span id=\"mouseX\"></span>, Y:\n      <span id=\"mouseY\"></span>\n    </p>\n    <p>Image Size:\n      <span id='image-width'></span>px,\n      <span id='image-height'></span>px</p>\n  </div>\n</div>\n<!-- <p>X : {{mouseX}}, Y : {{mouseY}}</p> -->\n\n\n<span id=\"scaleX\" hidden></span>\n<span id=\"scaleY\" hidden></span>\n<span id=\"defaultHeight\" hidden></span>\n"

/***/ }),

/***/ "./src/app/components/annotation-panel/annotation-area/annotation-area.component.ts":
/*!******************************************************************************************!*\
  !*** ./src/app/components/annotation-panel/annotation-area/annotation-area.component.ts ***!
  \******************************************************************************************/
/*! exports provided: AnnotationAreaComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AnnotationAreaComponent", function() { return AnnotationAreaComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _app_const__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../app-const */ "./src/app/app-const.ts");
/* harmony import */ var _services_image_service_image_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../services/image-service/image.service */ "./src/app/services/image-service/image.service.ts");
/* harmony import */ var _services_task_service_task_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../services/task-service/task.service */ "./src/app/services/task-service/task.service.ts");
/* harmony import */ var _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../services/helper-service/helper.service */ "./src/app/services/helper-service/helper.service.ts");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var angular2_hotkeys__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! angular2-hotkeys */ "./node_modules/angular2-hotkeys/index.js");
/* harmony import */ var angular2_hotkeys__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(angular2_hotkeys__WEBPACK_IMPORTED_MODULE_7__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};








var AnnotationAreaComponent = /** @class */ (function () {
    function AnnotationAreaComponent(imageService, taskService, helperService, _hotkeysService) {
        var _this = this;
        this.imageService = imageService;
        this.taskService = taskService;
        this.helperService = helperService;
        this._hotkeysService = _hotkeysService;
        this.serverPath = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath;
        this.rectIndex = 0;
        this.dotIndex = 0;
        this.mouse = {};
        this.isDrawing = false;
        this.rectConfigList = [];
        this.effectiveDrawing = false;
        this.rectAnnotationList = [];
        this.status = 2;
        this.savingSuccess = false;
        this.savingFailed = false;
        this.dotConfigList = [];
        this.dotAnnotationList = [];
        this.currentTool = 'mouse';
        this.that = this;
        this.imageSelected = false;
        this.imageModified = false;
        this.imageSaved = false;
        this.dotDescriptionList = [];
        this.rectDescriptionList = [];
        this.dotTagList = [];
        this.displaySavedSuccess = false;
        this.dotSn = 0;
        this.zoomFactor = 1;
        this._hotkeysService.add(new angular2_hotkeys__WEBPACK_IMPORTED_MODULE_7__["Hotkey"]('s', function (event) {
            _this.saveImageAnnotation();
            return false; // Prevent bubbling
        }));
    }
    AnnotationAreaComponent.prototype.onZoomIn = function () {
        if (this.zoomFactor < 3) {
            this.zoomFactor += 0.2;
            this.onSoftLoadImage();
        }
    };
    AnnotationAreaComponent.prototype.onZoomOut = function () {
        if (this.zoomFactor > 1) {
            this.zoomFactor -= 0.2;
            this.onSoftLoadImage();
        }
    };
    AnnotationAreaComponent.prototype.onResetImage = function () {
        if (this.zoomFactor != 1 || this.stage.getStage().x() != 0 || this.stage.getStage().y() != 0) {
            this.zoomFactor = 1;
            this.stage.getStage().x(0);
            this.stage.getStage().y(0);
            this.onSoftLoadImage();
        }
    };
    AnnotationAreaComponent.prototype.onDragTool = function () {
        this.currentTool = 'drag';
        jquery__WEBPACK_IMPORTED_MODULE_6__('#stage-div').css('cursor', 'grab');
        this.stage.getStage().draggable(true);
        this.stage.getStage().draw();
    };
    /*  display shapes for different select tool  */
    AnnotationAreaComponent.prototype.selectRect = function () {
        this.stage.getStage().draggable(false);
        this.stage.getStage().draw();
        this.currentTool = 'rect';
        console.log(this.currentTool);
        jquery__WEBPACK_IMPORTED_MODULE_6__('#stage-div').css('cursor', 'url(assets/images/cursor-rect.png), auto');
    };
    AnnotationAreaComponent.prototype.selectDot = function () {
        this.stage.getStage().draggable(false);
        this.stage.getStage().draw();
        this.currentTool = 'dot';
        console.log(this.currentTool);
        jquery__WEBPACK_IMPORTED_MODULE_6__('#stage-div').css('cursor', 'crosshair');
        this.configStage.draggable = false;
    };
    AnnotationAreaComponent.prototype.selectEraser = function () {
        this.currentTool = 'eraser';
        console.log(this.currentTool);
        jquery__WEBPACK_IMPORTED_MODULE_6__('#stage-div').css('cursor', 'url(assets/images/cursor-circle.png) 10 10, auto');
    };
    AnnotationAreaComponent.prototype.selectMouse = function () {
        this.currentTool = 'mouse';
        console.log(this.currentTool);
        jquery__WEBPACK_IMPORTED_MODULE_6__('#stage-div').css('cursor', 'default');
    };
    /* clicking behavior  */
    AnnotationAreaComponent.prototype.onClickRect = function (rect) {
        if (this.previousShape != null) {
            this.previousShape.getStage().stroke('red');
            if (this.previousShape.getStage().name().startsWith('dot')) {
                this.previousShape.getStage().stroke('yellow');
            }
            this.stage.getStage().draw();
        }
        var index = rect.getStage().name().substring(4);
        /* 4 means */
        if (this.currentTool == 'eraser') {
            this.imageService.currentDescription = {};
            this.rectAnnotationList[index] = [];
            rect.getStage().width(0);
            rect.getStage().height(0);
            this.rectLayer.getStage().draw();
        }
        else {
            this.previousShape = rect;
            rect.getStage().stroke('blue');
            this.stage.getStage().draw();
            this.imageService.currentDescription = {
                'description': this.rectDescriptionList[index],
                'index': index,
                'type': 'rect'
            };
        }
    };
    AnnotationAreaComponent.prototype.onClickDot = function (dot) {
        if (this.previousShape != null) {
            this.previousShape.getStage().stroke('red');
            if (this.previousShape.getStage().name().startsWith('dot')) {
                this.previousShape.getStage().stroke('transparent');
            }
            this.stage.getStage().draw();
        }
        var index = dot.getStage().name().substring(3);
        /* 3 means */
        if (this.currentTool == 'eraser') {
            this.imageService.currentDescription = {};
            this.dotAnnotationList[index] = [];
            dot.getStage().radius(0);
            this.stage.getStage().draw();
        }
        else {
            this.previousShape = dot;
            console.log(this.dotAnnotationList);
            dot.getStage().stroke('blue');
            this.stage.getStage().draw();
            this.imageService.currentDescription = {
                'description': this.dotDescriptionList[index],
                'index': index,
                'type': 'dot'
            };
            this.helperService.tag = {
                'tag': this.dotTagList[index],
                'index': index,
                'type': 'dot'
            };
        }
    };
    AnnotationAreaComponent.prototype.onMouseOverDot = function (dot) {
        var that = this;
        dot.getStage().on('dragend', function () {
            console.log('drag end: ' + dot.getStage().name());
            var x = Number(jquery__WEBPACK_IMPORTED_MODULE_6__('#mouseX').text());
            var y = Number(jquery__WEBPACK_IMPORTED_MODULE_6__('#mouseY').text());
            var scaleX = Number(jquery__WEBPACK_IMPORTED_MODULE_6__('#scaleX').text());
            var scaleY = Number(jquery__WEBPACK_IMPORTED_MODULE_6__('#scaleY').text());
            var index = dot.getStage().name().substring(3);
            var sn = that.dotAnnotationList[index][2];
            that.dotAnnotationList[index] = [(x).toFixed(0) + '', (y).toFixed(0) + '', sn + ''];
        });
    };
    AnnotationAreaComponent.prototype.drawingOn = function () {
        var _this = this;
        this.imageSaved = false;
        var mousex = Number(jquery__WEBPACK_IMPORTED_MODULE_6__('#mouseX').text()) / this.zoomFactor;
        var mousey = Number(jquery__WEBPACK_IMPORTED_MODULE_6__('#mouseY').text()) / this.zoomFactor;
        var scaleX = Number(jquery__WEBPACK_IMPORTED_MODULE_6__('#scaleX').text());
        var scaleY = Number(jquery__WEBPACK_IMPORTED_MODULE_6__('#scaleY').text());
        if (this.currentTool == 'rect') {
            this.currentRect = this.rectList.toArray()[this.rectIndex].getStage();
            // this.startX = this.mouseX;
            // this.startY = this.mouseY;
            this.startX = mousex;
            this.startY = mousey;
            this.currentRect.x(this.startX * scaleX);
            this.currentRect.y(this.startY * scaleY);
            this.timer = Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["interval"])(10).subscribe(function (x) {
                _this.dragging();
                //   this.layer.getStage().batchDraw();
                _this.currentRect.getStage().draw();
                //   console.log("test");
            });
        }
    };
    AnnotationAreaComponent.prototype.dragging = function () {
        var mousex = Number(jquery__WEBPACK_IMPORTED_MODULE_6__('#mouseX').text()) / this.zoomFactor;
        var mousey = Number(jquery__WEBPACK_IMPORTED_MODULE_6__('#mouseY').text()) / this.zoomFactor;
        var scaleX = Number(jquery__WEBPACK_IMPORTED_MODULE_6__('#scaleX').text());
        var scaleY = Number(jquery__WEBPACK_IMPORTED_MODULE_6__('#scaleY').text());
        this.currentRect.width((mousex - this.startX) * scaleX * this.zoomFactor);
        this.currentRect.height((mousey - this.startY) * scaleY * this.zoomFactor);
    };
    AnnotationAreaComponent.prototype.drawingOff = function () {
        var mousex = Number(jquery__WEBPACK_IMPORTED_MODULE_6__('#mouseX').text());
        var mousey = Number(jquery__WEBPACK_IMPORTED_MODULE_6__('#mouseY').text());
        var scaleX = Number(jquery__WEBPACK_IMPORTED_MODULE_6__('#scaleX').text());
        var scaleY = Number(jquery__WEBPACK_IMPORTED_MODULE_6__('#scaleY').text());
        var originX = this.stage.getStage().x() / scaleX;
        var originY = this.stage.getStage().y() / scaleY;
        if (this.currentTool == 'rect') {
            this.timer.unsubscribe();
            this.endX = mousex;
            this.endY = mousey;
            this.currentRect.name('rect' + this.rectIndex);
            this.redrawShape();
            this.currentRect.getStage().draw();
            if (this.effectiveDrawing) {
                this.imageModified = true;
                this.imageService.setCurrentImageSaved(false);
                this.rectIndex += 1;
            }
        }
        if (this.currentTool == 'dot') {
            this.currentDot = this.dotList.toArray()[this.dotIndex].getStage();
            var x = mousex;
            var y = mousey;
            this.currentDot.x((x - originX) * scaleX);
            this.currentDot.y((y - originY) * scaleY);
            this.currentDot.radius(2);
            this.currentDot.draggable(true);
            this.currentDot.name('dot' + this.dotIndex);
            this.currentDot.getStage().draw();
            this.imageModified = true;
            this.imageService.setCurrentImageSaved(false);
            this.dotSn += 1;
            this.dotAnnotationList[this.dotIndex] = [((x - originX) / this.zoomFactor).toFixed(0) + '', ((y - originY) / this.zoomFactor).toFixed(0) + '', this.dotSn + ''];
            // this.bufferDotAnnotationList[this.dotIndex] = [(x / this.zoomFactor).toFixed(0) + '', (y / this.zoomFactor).toFixed(0) + '', this.dotSn + ''];
            this.dotTagList[this.dotIndex] = 'default';
            this.helperService.tag = { tag: 'default' };
            this.dotIndex += 1;
        }
    };
    AnnotationAreaComponent.prototype.deleteAllDots = function () {
        this.imageService.setCurrentImageSaved(false);
        console.log(this.dotAnnotationList);
        for (var i = 0; i < this.dotAnnotationList.length; i++) {
            var dot = this.dotList.toArray()[i].getStage();
            dot.x(0);
            dot.y(0);
            dot.radius(0);
            dot.stroke('transparent');
            dot.draw();
        }
        this.previousShape = null;
        this.dotAnnotationList = [];
        this.dotIndex = 0;
        this.stage.getStage().draw();
        this.dotSn = 0;
    };
    /* what does this function do?? */
    AnnotationAreaComponent.prototype.redrawShape = function () {
        var scaleX = Number(jquery__WEBPACK_IMPORTED_MODULE_6__('#scaleX').text());
        var scaleY = Number(jquery__WEBPACK_IMPORTED_MODULE_6__('#scaleY').text());
        this.currentRect.x(this.startX * scaleX);
        this.currentRect.y(this.startY * scaleY);
        var w = this.endX - this.startX;
        var h = this.endY - this.startY;
        this.currentRect.width(w * scaleX);
        this.currentRect.height(h * scaleY);
        if (w <= 5 || h <= 5) {
            this.effectiveDrawing = false;
        }
        else {
            this.effectiveDrawing = true;
            // record annotation values for rect
            // this.pakList[this.index] = {"x":this.startX, "y":this.startY, "w":w, "h":h };
            this.rectAnnotationList[this.rectIndex] = [this.startX.toFixed(0) + '', this.startY.toFixed(0) + '', (w).toFixed(0) + '', (h).toFixed(0) + ''];
        }
    };
    AnnotationAreaComponent.prototype.getImage = function (name) {
        var _this = this;
        this.imageService.getImage(name).subscribe(function (res) {
            console.log(res.json()['fileName']);
            _this.imageName = res.json()['fileName'];
        }, function (error) {
            console.log(error);
        });
    };
    AnnotationAreaComponent.prototype.print = function () {
        this.currentRect = this.rectList.toArray()[this.rectIndex].getStage();
        this.currentRect.getStage().draw();
    };
    AnnotationAreaComponent.prototype.saveImageAnnotation = function () {
        var _this = this;
        if (this.currentTask != null) {
            this.onResetImage();
            var that = this;
            this.imageService.currentDescription = {};
            this.imageSaved = true;
            this.imageService.setCurrentImageSaved(true);
            this.imageService.saveImageAnnotation(this.rectAnnotationList, this.dotAnnotationList, this.currentTask, this.status, this.dotDescriptionList, this.rectDescriptionList, this.dotTagList).subscribe(function (res) {
                _this.savingSuccess = true;
                // this.displaySavedSuccess = true;
                // setTimeout(function () {
                //   that.displaySavedSuccess = false;
                // }.bind(this), 3000);
            }, function (err) {
                _this.savingFailed = true;
            });
        }
    };
    AnnotationAreaComponent.prototype.onSoftLoadImage = function () {
        //prepare references for functional callback usage
        var stageRef = this.stage;
        var imageLayerRef = this.imageLayer;
        var imageRef = this.image;
        var imageObjRef = this.imageObj;
        var annotationWidthRef = this.annotationWidth;
        var imageConfigRef = {};
        var configStageRef = {};
        var that = this;
        var mouseRef = this.mouse;
        var mousex = Number(jquery__WEBPACK_IMPORTED_MODULE_6__('#mouseX').text());
        var mousey = Number(jquery__WEBPACK_IMPORTED_MODULE_6__('#mouseY').text());
        var scaleX = Number(jquery__WEBPACK_IMPORTED_MODULE_6__('#scaleX').text());
        var scaleY = Number(jquery__WEBPACK_IMPORTED_MODULE_6__('#scaleY').text());
        this.imageConfig = imageConfigRef;
        this.configStage = configStageRef;
        var url = this.serverPath + '/image/getImage/' + this.currentTask.imageItem.folderPath;
        var image = new Image();
        image.onload = function () {
            var w = image.width;
            var h = image.height;
            jquery__WEBPACK_IMPORTED_MODULE_6__('#image-width').text(w);
            jquery__WEBPACK_IMPORTED_MODULE_6__('#image-height').text(h);
            var stageHeight = Number(jquery__WEBPACK_IMPORTED_MODULE_6__('#defaultHeight').text());
            if (stageHeight == 0) {
                stageHeight = document.getElementById('stage-div').offsetHeight;
                jquery__WEBPACK_IMPORTED_MODULE_6__('#defaultHeight').text(stageHeight);
            }
            var scaleY = stageHeight / h;
            var stageWidth = w / h * stageHeight;
            if ((w / h * stageHeight) > annotationWidthRef - 50) {
                stageWidth = annotationWidthRef - 50;
                stageHeight = stageWidth * h / w;
                scaleY = stageHeight / h;
            }
            else {
                stageWidth = w / h * stageHeight;
            }
            var scaleX = stageWidth / w;
            jquery__WEBPACK_IMPORTED_MODULE_6__('#scaleX').text(scaleX);
            jquery__WEBPACK_IMPORTED_MODULE_6__('#scaleY').text(scaleY);
            that.scaleX = scaleX;
            that.scaleY = scaleY;
            console.log('scale: ' + that.scaleX + ', ' + that.scaleY);
            for (var i = 0; i < that.dotIndex; i++) {
                var dot = that.dotList.toArray()[i].getStage();
                var x = Number(that.dotAnnotationList[i][0]);
                var y = Number(that.dotAnnotationList[i][1]);
                dot.x(x * scaleX * that.zoomFactor);
                dot.y(y * scaleY * that.zoomFactor);
                dot.getStage().draw();
            }
            imageRef.getStage().height(stageHeight * that.zoomFactor);
            imageRef.getStage().width(stageWidth * that.zoomFactor);
            imageLayerRef.getStage().draw();
            stageRef.getStage().width(stageWidth);
            stageRef.getStage().height(stageHeight);
            stageRef.getStage().draw();
            jquery__WEBPACK_IMPORTED_MODULE_6__('#stage-div').width(stageWidth);
            jquery__WEBPACK_IMPORTED_MODULE_6__('#stage-div').height(stageHeight);
            jquery__WEBPACK_IMPORTED_MODULE_6__('#stage-div').mousemove(function (event) {
                var mousex = (event.offsetX / scaleX).toFixed(0);
                var mousey = (event.offsetY / scaleY).toFixed(0);
                jquery__WEBPACK_IMPORTED_MODULE_6__('#mouseX').text(mousex);
                jquery__WEBPACK_IMPORTED_MODULE_6__('#mouseY').text(mousey);
                mouseRef = { 'x': mousex, 'y': mousey };
            });
        };
        this.imageObj.src = url;
        image.src = url;
    };
    AnnotationAreaComponent.prototype.onLoadImage = function () {
        this.imageSaved = false;
        this.imageModified = false;
        this.imageService.setCurrentImageSaved(true);
        // clear up data
        for (var i = 0; i < 100; i++) {
            this.rectConfigList[i].next({
                x: 0,
                y: 0,
                width: 0,
                height: 0,
                fill: 'transparent',
                stroke: 'red',
                strokeWidth: 2
            });
        }
        for (var i = 0; i < 100; i++) {
            this.dotConfigList[i].next({
                x: 0,
                y: 0,
                radius: 0,
                fill: '#00FF00',
                stroke: 'transparent',
                strokeWidth: 5,
            });
        }
        this.rectAnnotationList = [];
        this.dotAnnotationList = [];
        this.dotDescriptionList = [];
        this.dotTagList = [];
        this.rectDescriptionList = [];
        this.rectIndex = 0;
        this.dotIndex = 0;
        this.savingSuccess = false;
        this.currentTool = 'mouse';
        jquery__WEBPACK_IMPORTED_MODULE_6__('#stage-div').css('cursor', 'default');
        this.selectDot();
        // get current selected image
        this.currentTask = this.imageService.getCurrentTask();
        this.imageService.taskStatus = {
            'id': this.currentTask['id'],
            'status': this.currentTask['taskStatus']
        };
        console.log(this.currentTask);
        this.taskService.onTaskDescription = {
            'taskDescription': this.currentTask.description
        };
        // prepare references for functional callback usage
        var stageRef = this.stage;
        var imageLayerRef = this.imageLayer;
        var imageRef = this.image;
        var imageObjRef = this.imageObj;
        var annotationWidthRef = this.annotationWidth;
        var imageConfigRef = {};
        var configStageRef = {};
        var that = this;
        var mouseRef = this.mouse;
        this.imageConfig = imageConfigRef;
        this.configStage = configStageRef;
        var url = this.serverPath + '/image/getImage/' + this.currentTask.imageItem.folderPath;
        this.imageObj.src = url;
        var image = new Image();
        image.src = url;
        image.onload = function () {
            var w = image.width;
            var h = image.height;
            jquery__WEBPACK_IMPORTED_MODULE_6__('#image-width').text(w);
            jquery__WEBPACK_IMPORTED_MODULE_6__('#image-height').text(h);
            var stageHeight = Number(jquery__WEBPACK_IMPORTED_MODULE_6__('#defaultHeight').text());
            if (stageHeight == 0) {
                stageHeight = document.getElementById('stage-div').offsetHeight;
                jquery__WEBPACK_IMPORTED_MODULE_6__('#defaultHeight').text(stageHeight);
            }
            var scaleY = stageHeight / h;
            var stageWidth = w / h * stageHeight;
            if ((w / h * stageHeight) > annotationWidthRef - 50) {
                stageWidth = annotationWidthRef - 50;
                stageHeight = stageWidth * h / w;
                scaleY = stageHeight / h;
            }
            else {
                stageWidth = w / h * stageHeight;
            }
            var scaleX = stageWidth / w;
            jquery__WEBPACK_IMPORTED_MODULE_6__('#scaleX').text(scaleX);
            jquery__WEBPACK_IMPORTED_MODULE_6__('#scaleY').text(scaleY);
            that.scaleX = scaleX;
            that.scaleY = scaleY;
            console.log('scale: ' + that.scaleX + ', ' + that.scaleY);
            imageRef.getStage().height(stageHeight * that.zoomFactor);
            imageRef.getStage().width(stageWidth * that.zoomFactor);
            imageLayerRef.getStage().draw();
            stageRef.getStage().width(stageWidth);
            stageRef.getStage().height(stageHeight);
            stageRef.getStage().draw();
            jquery__WEBPACK_IMPORTED_MODULE_6__('#stage-div').width(stageWidth);
            jquery__WEBPACK_IMPORTED_MODULE_6__('#stage-div').height(stageHeight);
            that.getAnnotation(scaleX * that.zoomFactor, scaleY * that.zoomFactor);
            jquery__WEBPACK_IMPORTED_MODULE_6__('#stage-div').mousemove(function (event) {
                var mousex = (event.offsetX / scaleX).toFixed(0);
                var mousey = (event.offsetY / scaleY).toFixed(0);
                jquery__WEBPACK_IMPORTED_MODULE_6__('#mouseX').text(mousex);
                jquery__WEBPACK_IMPORTED_MODULE_6__('#mouseY').text(mousey);
                mouseRef = { 'x': mousex, 'y': mousey };
            });
        };
    };
    AnnotationAreaComponent.prototype.getAnnotation = function (scaleX, scaleY) {
        var _this = this;
        // get annotation for current image
        this.imageService.getAnnotationByTask(this.currentTask.id).subscribe(function (res) {
            var currentAnnotationMapper = res.json();
            var currentDotList = currentAnnotationMapper['dotList'];
            var currentRectList = currentAnnotationMapper['rectList'];
            var currentState = currentAnnotationMapper['state'];
            _this.dotSn = 0;
            for (var i = 0; i < currentDotList.length; i++) {
                _this.dotConfigList[i].next({
                    x: currentDotList[i]['offsetX'] * scaleX,
                    y: currentDotList[i]['offsetY'] * scaleY,
                    radius: 2,
                    fill: '#00FF00',
                    stroke: 'transparent',
                    strokeWidth: 5,
                    // strokeEnabled: false,
                    name: 'dot' + i,
                    draggable: true
                });
                _this.dotAnnotationList[_this.dotIndex] = [currentDotList[i]['offsetX'] + '', currentDotList[i]['offsetY'] + '', currentDotList[i]['sn'] + ''];
                _this.dotDescriptionList[i] = currentDotList[i]['description'];
                _this.dotTagList[i] = currentDotList[i]['tag'];
                _this.dotIndex += 1;
                if (Number(currentDotList[i]['sn']) > _this.dotSn) {
                    _this.dotSn = Number(currentDotList[i]['sn']);
                }
            }
            for (var i = 0; i < currentRectList.length; i++) {
                _this.rectConfigList[i].next({
                    x: currentRectList[i]['offsetX'] * scaleX,
                    y: currentRectList[i]['offsetY'] * scaleY,
                    width: currentRectList[i]['offsetWidth'] * scaleX,
                    height: currentRectList[i]['offsetHeight'] * scaleY,
                    fill: 'transparent',
                    stroke: 'red',
                    strokeWidth: 2,
                    name: 'rect' + i
                });
                _this.rectAnnotationList[_this.rectIndex] = [currentRectList[i]['offsetX'] + '', currentRectList[i]['offsetY'] + '', currentRectList[i]['offsetWidth'] + '', currentRectList[i]['offsetHeight'] + ''];
                _this.rectDescriptionList[i] = currentRectList[i]['description'];
                _this.rectIndex += 1;
            }
            console.log(_this.dotAnnotationList);
            if (currentState != null) {
                _this.status = currentState.status;
            }
            _this.bufferDotAnnotationList = _this.dotAnnotationList.slice();
        }, function (error) {
            console.log(error);
        });
    };
    AnnotationAreaComponent.prototype.canvasInit = function () {
        this.imageConfig = Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])({
            x: 0,
            y: 0,
            image: this.imageObj,
            // draggable: true,
            width: this.imageWidth,
            height: this.imageHeight
        });
        this.configStage = Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])({
            container: 'canvas',
            x: 0,
            y: 0,
            width: this.imageWidth,
            height: this.imageHeight,
            draggable: false
        });
    };
    AnnotationAreaComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.imageService.newDescriptionObject$.subscribe(function (object) {
            var description = object['description'];
            var labelIndex = object['index'];
            var labelType = object['type'];
            if (labelType == 'rect') {
                _this.rectDescriptionList[labelIndex] = description;
            }
            else if (labelType == 'dot') {
                _this.dotDescriptionList[labelIndex] = description;
            }
        });
        this.taskService.newTaskDescription$.subscribe(function (object) {
            var taskDescription = object['taskDescription'];
            _this.currentTask['description'] = taskDescription;
        });
        this.helperService.tag$.subscribe(function (object) {
            var tag = object['tag'];
            var labelIndex = object['index'];
            var labelType = object['type'];
            console.log(tag, labelIndex, labelType);
            if (labelType == 'dot') {
                _this.dotTagList[labelIndex] = tag;
            }
        });
        this.helperService.onSwitchImage$.subscribe(function (task) {
            _this.onResetImage();
            _this.saveImageAnnotation();
        });
        for (var i = 0; i < 100; i++) {
            this.rectConfigList.push(new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"]({
                x: 0,
                y: 0,
                width: 0,
                height: 0,
                fill: 'transparent',
                stroke: 'red',
                strokeWidth: 2
            }));
        }
        for (var i = 0; i < 100; i++) {
            this.dotConfigList.push(new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"]({
                x: 0,
                y: 0,
                radius: 0,
                fill: '#00FF00',
                stroke: 'transparent',
                strokeWidth: 5,
                // strokeEnabled: false,
                draggable: true,
            }));
        }
        this.imageObj = new Image();
        this.imageObj.src = 'assets/images/getstarted.jpg';
        this.imageObj.onload = function () {
        };
        this.imageWidth = 750;
        this.imageHeight = 650;
        jquery__WEBPACK_IMPORTED_MODULE_6__('#stage-div').width(this.imageWidth);
        jquery__WEBPACK_IMPORTED_MODULE_6__('#stage-div').height(this.imageHeight);
        this.imageObj.onload = this.canvasInit();
        console.log(this.imageObj);
        this.imageSaved = false;
        this.imageModified = false;
        this.imageService.setCurrentImageSaved(true);
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('rectLayer'),
        __metadata("design:type", Object)
    ], AnnotationAreaComponent.prototype, "rectLayer", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('stage'),
        __metadata("design:type", Object)
    ], AnnotationAreaComponent.prototype, "stage", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChildren"])('rect'),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["QueryList"])
    ], AnnotationAreaComponent.prototype, "rectList", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChildren"])('dotLayer'),
        __metadata("design:type", Object)
    ], AnnotationAreaComponent.prototype, "dotLayer", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChildren"])('dot'),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["QueryList"])
    ], AnnotationAreaComponent.prototype, "dotList", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('image'),
        __metadata("design:type", Object)
    ], AnnotationAreaComponent.prototype, "image", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('imageLayer'),
        __metadata("design:type", Object)
    ], AnnotationAreaComponent.prototype, "imageLayer", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])('currentTask'),
        __metadata("design:type", Object)
    ], AnnotationAreaComponent.prototype, "selectedTask", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])('width'),
        __metadata("design:type", Object)
    ], AnnotationAreaComponent.prototype, "annotationWidth", void 0);
    AnnotationAreaComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-annotation-area',
            template: __webpack_require__(/*! ./annotation-area.component.html */ "./src/app/components/annotation-panel/annotation-area/annotation-area.component.html"),
            styles: [__webpack_require__(/*! ./annotation-area.component.css */ "./src/app/components/annotation-panel/annotation-area/annotation-area.component.css")]
        }),
        __metadata("design:paramtypes", [_services_image_service_image_service__WEBPACK_IMPORTED_MODULE_3__["ImageService"], _services_task_service_task_service__WEBPACK_IMPORTED_MODULE_4__["TaskService"], _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_5__["HelperService"], angular2_hotkeys__WEBPACK_IMPORTED_MODULE_7__["HotkeysService"]])
    ], AnnotationAreaComponent);
    return AnnotationAreaComponent;
}());



/***/ }),

/***/ "./src/app/components/annotation-panel/annotation-menu/annotation-menu.component.css":
/*!*******************************************************************************************!*\
  !*** ./src/app/components/annotation-panel/annotation-menu/annotation-menu.component.css ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/annotation-panel/annotation-menu/annotation-menu.component.html":
/*!********************************************************************************************!*\
  !*** ./src/app/components/annotation-panel/annotation-menu/annotation-menu.component.html ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"btn-toolbar\">\n  \n  \n</div>"

/***/ }),

/***/ "./src/app/components/annotation-panel/annotation-menu/annotation-menu.component.ts":
/*!******************************************************************************************!*\
  !*** ./src/app/components/annotation-panel/annotation-menu/annotation-menu.component.ts ***!
  \******************************************************************************************/
/*! exports provided: AnnotationMenuComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AnnotationMenuComponent", function() { return AnnotationMenuComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var AnnotationMenuComponent = /** @class */ (function () {
    function AnnotationMenuComponent() {
        this.currentTool = "rect";
    }
    AnnotationMenuComponent.prototype.selectRect = function () {
        this.currentTool = "rect";
    };
    AnnotationMenuComponent.prototype.selectDot = function () {
        this.currentTool = "dot";
    };
    AnnotationMenuComponent.prototype.ngOnInit = function () {
    };
    AnnotationMenuComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-annotation-menu',
            template: __webpack_require__(/*! ./annotation-menu.component.html */ "./src/app/components/annotation-panel/annotation-menu/annotation-menu.component.html"),
            styles: [__webpack_require__(/*! ./annotation-menu.component.css */ "./src/app/components/annotation-panel/annotation-menu/annotation-menu.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], AnnotationMenuComponent);
    return AnnotationMenuComponent;
}());



/***/ }),

/***/ "./src/app/components/annotation-panel/annotation-panel.component.css":
/*!****************************************************************************!*\
  !*** ./src/app/components/annotation-panel/annotation-panel.component.css ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/annotation-panel/annotation-panel.component.html":
/*!*****************************************************************************!*\
  !*** ./src/app/components/annotation-panel/annotation-panel.component.html ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-annotation-menu></app-annotation-menu>\n<div class=\"row\">\n  <div class=\"col-8\" style=\"border:1px solid black;\" id=\"annotation-window\">\n    <app-annotation-area #annotationArea [currentTask]=\"task\" [width]=\"width\"></app-annotation-area>\n  </div>\n  <div id=\"image-panel\" class=\"col-4\">\n    <app-image-list (myEvent)=\"annotationArea.onLoadImage()\" [thisAssignmentItemId]=\"assignmentItemId\"></app-image-list>\n  </div>\n</div>\n\n\n\n"

/***/ }),

/***/ "./src/app/components/annotation-panel/annotation-panel.component.ts":
/*!***************************************************************************!*\
  !*** ./src/app/components/annotation-panel/annotation-panel.component.ts ***!
  \***************************************************************************/
/*! exports provided: AnnotationPanelComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AnnotationPanelComponent", function() { return AnnotationPanelComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var AnnotationPanelComponent = /** @class */ (function () {
    function AnnotationPanelComponent() {
        this.imageList = [];
    }
    AnnotationPanelComponent.prototype.ngOnInit = function () {
        this.width = document.getElementById('annotation-window').offsetWidth;
        console.log('assignmentItemId is: ' + this.assignmentItemId);
        this.thisAssignmentItemId = this.assignmentItemId;
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])('imageUrl'),
        __metadata("design:type", String)
    ], AnnotationPanelComponent.prototype, "imageUrl", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])('taskList'),
        __metadata("design:type", Object)
    ], AnnotationPanelComponent.prototype, "taskList", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])('assignmentItemId'),
        __metadata("design:type", Object)
    ], AnnotationPanelComponent.prototype, "assignmentItemId", void 0);
    AnnotationPanelComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-annotation-panel',
            template: __webpack_require__(/*! ./annotation-panel.component.html */ "./src/app/components/annotation-panel/annotation-panel.component.html"),
            styles: [__webpack_require__(/*! ./annotation-panel.component.css */ "./src/app/components/annotation-panel/annotation-panel.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], AnnotationPanelComponent);
    return AnnotationPanelComponent;
}());



/***/ }),

/***/ "./src/app/components/annotation-panel/image-list/image-list.component.css":
/*!*********************************************************************************!*\
  !*** ./src/app/components/annotation-panel/image-list/image-list.component.css ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".item {\n    position:relative;\n    padding-top:20px;\n    display:inline-block;\n}\n/*.notify-badge{*/\n/*position: absolute;*/\n/*left:5px;*/\n/*top:5px;*/\n/*text-align: center;*/\n/*border-radius: 30px 30px 30px 30px;*/\n/*color:white;*/\n/*padding:5px 10px;*/\n/*font-size:8px;*/\n/*}*/\n.notify-badge {\n  position:relative;\n  bottom: -30px;\n  right: -10px;\n  margin: 0 0 0 0;\n}\n.selected {\n  border: 3px solid hotpink;\n}\n"

/***/ }),

/***/ "./src/app/components/annotation-panel/image-list/image-list.component.html":
/*!**********************************************************************************!*\
  !*** ./src/app/components/annotation-panel/image-list/image-list.component.html ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<form class=\"form-inline\" style=\"margin-top: 20px;\">\n  <div class=\"input-group\" style=\"width: 200px;\">\n    <div class=\"input-group-prepend\">\n      <div class=\"input-group-text\">Items</div>\n    </div>\n    <input type=\"number\" class=\"form-control\" id=\"itemsPerPage\" name=\"itemsPerPage\" min=\"0\"\n           [(ngModel)]=\"config.itemsPerPage\">\n  </div>\n  &nbsp;&nbsp;\n  <div class=\"input-group\" style=\"width: 200px;\">\n    <div class=\"input-group-prepend\">\n      <div class=\"input-group-text\">Page</div>\n    </div>\n    <input type=\"number\" class=\"form-control\" id=\"currentPage\" name=\"currentPage\" min=\"0\"\n           [(ngModel)]=\"config.currentPage\">\n  </div>\n</form>\n<hr>\n<div *ngIf=\"!busy\">\n  <span>Selected: {{currentTask?.imageItem.fileName}}</span>\n  <ul class=\"list-inline\" style=\"margin-bottom: 10px;\">\n    <li style=\"width:120px;\" class=\"list-inline-item\"\n        *ngFor=\"let task of taskList | stringFilter: filter | paginate: config; let i=index; trackBy: trackByFn\">\n      <span *ngIf=\"task.taskStatus==0\" class=\"badge badge-primary notify-badge\">New</span>\n      <span *ngIf=\"task.taskStatus==2\" class=\"badge badge-success notify-badge\">Done</span>\n      <span *ngIf=\"task.taskStatus==1\" class=\"badge badge-warning notify-badge\">Changed</span>\n      <img src=\"{{serverPath}}/image/getImage/{{task.imageItem.folderPath}}\"\n           class=\"img-thumbnail\" [ngClass]=\"task == currentTask? 'selected' : ''\" style=\"cursor: pointer;\" alt=\"Image Thumbnail\" (click)=\"onSelectImage(task)\">\n      <div class=\"text-center\" style=\"color: black; font-size: 10pt\">{{task.imageItem.fileName |\n        slice:0:task.imageItem.fileName.length-4}}\n      </div>\n    </li>\n  </ul>\n  <pagination-controls  style=\"font-size: medium;\" [id]=\"config.id\"\n                       [maxSize]=\"maxSize\"\n                       [directionLinks]=\"directionLinks\"\n                       [autoHide]=\"autoHide\"\n                       [responsive]=\"responsive\"\n                       [previousLabel]=\"labels.previousLabel\"\n                       [nextLabel]=\"labels.nextLabel\"\n                       [screenReaderPaginationLabel]=\"labels.screenReaderPaginationLabel\"\n                       [screenReaderPageLabel]=\"labels.screenReaderPageLabel\"\n                       [screenReaderCurrentLabel]=\"labels.screenReaderCurrentLabel\"\n                       (pageChange)=\"onPageChange($event)\"></pagination-controls>\n\n</div>\n\n<div *ngIf=\"busy\" class=\"text-center\" style=\"margin: 100px 0px 0 0px\">\n  <i class=\"fa fa-spinner fa-3x faa-spin animated\"></i>\n</div>\n\n\n<!-- Button trigger modal -->\n<!--<button id=\"modal-button\" type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#exampleModal\"-->\n        <!--&gt;</button>-->\n\n<!-- Modal -->\n<!--<div class=\"modal fade\" id=\"exampleModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"exampleModalLabel\"-->\n     <!--aria-hidden=\"true\">-->\n  <!--<div class=\"modal-dialog\" role=\"document\">-->\n    <!--<div class=\"modal-content\">-->\n      <!--<div class=\"modal-header\">-->\n        <!--<h5 class=\"modal-title\" id=\"exampleModalLabel\">Warning!</h5>-->\n        <!--<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">-->\n          <!--<span aria-hidden=\"true\">&times;</span>-->\n        <!--</button>-->\n      <!--</div>-->\n      <!--<div class=\"modal-body\">-->\n        <!--Are you sure you want to switch to another image? All changes on the current image will be lost.-->\n      <!--</div>-->\n      <!--<div class=\"modal-footer\">-->\n        <!--<button type=\"button\" class=\"btn btn-primary btn-sm\" data-dismiss=\"modal\" (click)=\"onCancelChangeImage()\">Cancel</button>-->\n        <!--<button type=\"button\" class=\"btn btn-danger btn-sm\" (click)=\"confirmSwitching()\" data-dismiss=\"modal\">Don't-->\n          <!--care-->\n        <!--</button>-->\n      <!--</div>-->\n    <!--</div>-->\n  <!--</div>-->\n<!--</div>-->\n\n<ngx-smart-modal #myModal identifier=\"myModal\">\n  <h4>Are you sure you want to switch to another image? All changes on the current image will be lost.</h4>\n\n  <button class=\"btn btn-sm btn-outline-dark pointer\" (click)=\"onCancelChangeImage()\">Cancel</button>\n\n  <button class=\"btn btn-sm btn-outline-dark pointer pull-right\" (click)=\"confirmSwitching()\">Just Switch</button>\n\n</ngx-smart-modal>\n\n<simple-notifications [options]=\"options\"></simple-notifications>\n"

/***/ }),

/***/ "./src/app/components/annotation-panel/image-list/image-list.component.ts":
/*!********************************************************************************!*\
  !*** ./src/app/components/annotation-panel/image-list/image-list.component.ts ***!
  \********************************************************************************/
/*! exports provided: ImageListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImageListComponent", function() { return ImageListComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _app_const__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../app-const */ "./src/app/app-const.ts");
/* harmony import */ var _services_image_service_image_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../services/image-service/image.service */ "./src/app/services/image-service/image.service.ts");
/* harmony import */ var _services_assignment_service_assignment_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../services/assignment-service/assignment.service */ "./src/app/services/assignment-service/assignment.service.ts");
/* harmony import */ var _services_task_service_task_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../services/task-service/task.service */ "./src/app/services/task-service/task.service.ts");
/* harmony import */ var _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../services/helper-service/helper.service */ "./src/app/services/helper-service/helper.service.ts");
/* harmony import */ var ngx_perfect_scrollbar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-perfect-scrollbar */ "./node_modules/ngx-perfect-scrollbar/dist/ngx-perfect-scrollbar.es5.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var angular2_hotkeys__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! angular2-hotkeys */ "./node_modules/angular2-hotkeys/index.js");
/* harmony import */ var angular2_hotkeys__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(angular2_hotkeys__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var ngx_smart_modal__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ngx-smart-modal */ "./node_modules/ngx-smart-modal/esm5/ngx-smart-modal.js");
/* harmony import */ var angular2_notifications__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! angular2-notifications */ "./node_modules/angular2-notifications/angular2-notifications.umd.js");
/* harmony import */ var angular2_notifications__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(angular2_notifications__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};












var ImageListComponent = /** @class */ (function () {
    function ImageListComponent(_hotkeysService, cdr, imageService, taskService, assignmentService, helperService, ngxSmartModalService, notificationService, formBuilder) {
        var _this = this;
        this._hotkeysService = _hotkeysService;
        this.cdr = cdr;
        this.imageService = imageService;
        this.taskService = taskService;
        this.assignmentService = assignmentService;
        this.helperService = helperService;
        this.ngxSmartModalService = ngxSmartModalService;
        this.notificationService = notificationService;
        this.formBuilder = formBuilder;
        this.myEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.filter = '';
        this.maxSize = 6;
        this.directionLinks = true;
        this.autoHide = true;
        this.responsive = true;
        this.config = {
            id: 'advanced',
            itemsPerPage: 12,
            currentPage: 1
        };
        this.p = 1;
        this.labels = {
            previousLabel: 'Previous',
            nextLabel: 'Next',
            screenReaderPaginationLabel: 'Pagination',
            screenReaderPageLabel: 'page',
            screenReaderCurrentLabel: "You're on page"
        };
        this.imageUrlList = [];
        this.serverPath = _app_const__WEBPACK_IMPORTED_MODULE_1__["AppConst"].serverPath;
        this.imageList = [];
        this.taskList = [];
        this.busy = false;
        this.taskIndex = 0;
        this.options = {
            position: ['top', 'right'],
            maxStack: 1
        };
        this._hotkeysService.add(new angular2_hotkeys__WEBPACK_IMPORTED_MODULE_8__["Hotkey"]('f', function (event) {
            var i = _this.taskList.indexOf(_this.currentTask);
            if (i < _this.taskList.length - 1) {
                i++;
            }
            _this.onSelectImage(_this.taskList[i]);
            return false; // Prevent bubbling
        }));
        this._hotkeysService.add(new angular2_hotkeys__WEBPACK_IMPORTED_MODULE_8__["Hotkey"]('a', function (event) {
            var i = _this.taskList.indexOf(_this.currentTask);
            if (i > 0) {
                i--;
            }
            _this.onSelectImage(_this.taskList[i]);
            return false; // Prevent bubbling
        }));
    }
    ImageListComponent.prototype.ngOnAfterViewInit = function () {
        jquery__WEBPACK_IMPORTED_MODULE_7__('#scroll-bar').css('max-width', '100px');
    };
    // Notification creation
    ImageListComponent.prototype.create = function (title, type, message) {
        this.notificationService.create(title, message, type, {
            timeOut: 3000,
            showProgressBar: false,
            pauseOnHover: true
        });
    };
    ImageListComponent.prototype.onCancelChangeImage = function () {
        this.ngxSmartModalService.getModal('myModal').close();
    };
    ImageListComponent.prototype.onSelectImage = function (task) {
        console.log('image clicked');
        this.previousTask = this.currentTask;
        this.currentTask = task;
        if (this.previousTask != null && this.previousTask != undefined) {
            this.helperService.onSwitchImage = this.previousTask;
        }
        if (this.taskList.indexOf(this.currentTask) == 0) {
            this.create('First Image', 'info', '');
        }
        if (this.taskList.indexOf(this.currentTask) == (this.taskList.length - 1)) {
            this.create('Last Image', 'info', '');
        }
        var currentImageSaved = this.imageService.getCurrentImageSaved();
        this.currentTask = task;
        this.switchImage(task);
        this.checkPage();
        // if (currentImageSaved) {
        // this.currentTask = task;
        // this.switchImage(task);
        // this.checkPage();
        // } else {
        // this.currentTask = task;
        // $('#modal-button').click();
        // this.ngxSmartModalService.getModal('myModal').open();
        // }
    };
    ImageListComponent.prototype.checkPage = function () {
        var size = this.taskList.length;
        var items = this.config.itemsPerPage;
        var totalPages = size / items;
        var i = this.taskList.indexOf(this.currentTask);
        var currentPage = Math.ceil((i + 1) / items);
        if (this.config.currentPage != currentPage) {
            this.config.currentPage = currentPage;
        }
    };
    ImageListComponent.prototype.confirmSwitching = function () {
        this.ngxSmartModalService.getModal('myModal').close();
        this.switchImage(this.currentTask);
    };
    ImageListComponent.prototype.switchImage = function (task) {
        this.imageService.setCurrentTask(task);
        this.myEvent.emit(null);
    };
    ImageListComponent.prototype.onPageChange = function (number) {
        console.log('change to page', number);
        this.config.currentPage = number;
    };
    ImageListComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.currentTaskType = this.taskService.onTaskType;
        this.taskService.currentTaskStatus$.subscribe(function (taskId) {
            _this.taskService.getTaskById(taskId).subscribe(function (res) {
                var updatedTask = res.json();
                for (var i = 0; i < _this.taskList.length; i++) {
                    if (_this.taskList[i].id === updatedTask.id) {
                        _this.taskList[i].taskStatus = updatedTask.taskStatus;
                        break;
                    }
                }
                // this.scroll1.directiveRef.update();
            }, function (error) {
                console.log(error);
            });
        });
        this.taskService.previousTaskStatus$.subscribe(function (taskId) {
            _this.taskService.getTaskById(taskId).subscribe(function (res) {
                var updatedPreviousTask = res.json();
                for (var i = 0; i < _this.taskList.length; i++) {
                    if (_this.taskList[i].id === updatedPreviousTask.id) {
                        _this.taskList[i].taskStatus = updatedPreviousTask.taskStatus;
                        break;
                    }
                }
            }, function (error) {
                console.log(error);
            });
        });
        console.log('this assignmentItemId is: ' + this.assignmentItemId);
        this.assignmentService.getAssigmentByAssignmentItemId(this.assignmentItemId).subscribe(function (res) {
            _this.currentAssignment = res.json();
            _this.tagList = _this.currentAssignment.tagList;
            _this.helperService.tagList = _this.tagList;
            console.log(_this.tagList);
            _this.imageService.patientObject$.subscribe(function (patient) {
                _this.busy = true;
                _this.currentPatient = patient;
                _this.taskService.getTaskListByAssignmentAndPatientAndUser(_this.currentAssignment.id, _this.currentPatient.id).subscribe(function (res) {
                    _this.taskList = res.json();
                    // this.currentTask = this.taskList[0];
                    // this.onSelectImage(this.currentTask);
                    _this.busy = false;
                }, function (error) {
                    console.log(error);
                    _this.busy = false;
                });
            });
        }, function (error) {
            console.log(error);
        });
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])('height'),
        __metadata("design:type", Object)
    ], ImageListComponent.prototype, "height", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])('thisAssignmentItemId'),
        __metadata("design:type", Object)
    ], ImageListComponent.prototype, "assignmentItemId", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", Object)
    ], ImageListComponent.prototype, "myEvent", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('scroll1'),
        __metadata("design:type", ngx_perfect_scrollbar__WEBPACK_IMPORTED_MODULE_6__["PerfectScrollbarComponent"])
    ], ImageListComponent.prototype, "scroll1", void 0);
    ImageListComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-image-list',
            template: __webpack_require__(/*! ./image-list.component.html */ "./src/app/components/annotation-panel/image-list/image-list.component.html"),
            styles: [__webpack_require__(/*! ./image-list.component.css */ "./src/app/components/annotation-panel/image-list/image-list.component.css")]
        }),
        __metadata("design:paramtypes", [angular2_hotkeys__WEBPACK_IMPORTED_MODULE_8__["HotkeysService"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["ChangeDetectorRef"], _services_image_service_image_service__WEBPACK_IMPORTED_MODULE_2__["ImageService"], _services_task_service_task_service__WEBPACK_IMPORTED_MODULE_4__["TaskService"], _services_assignment_service_assignment_service__WEBPACK_IMPORTED_MODULE_3__["AssignmentService"], _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_5__["HelperService"], ngx_smart_modal__WEBPACK_IMPORTED_MODULE_9__["NgxSmartModalService"], angular2_notifications__WEBPACK_IMPORTED_MODULE_10__["NotificationsService"], _angular_forms__WEBPACK_IMPORTED_MODULE_11__["FormBuilder"]])
    ], ImageListComponent);
    return ImageListComponent;
}());



/***/ }),

/***/ "./src/app/components/assignment-review/annotation-modification/annotation-modification.component.css":
/*!************************************************************************************************************!*\
  !*** ./src/app/components/assignment-review/annotation-modification/annotation-modification.component.css ***!
  \************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/assignment-review/annotation-modification/annotation-modification.component.html":
/*!*************************************************************************************************************!*\
  !*** ./src/app/components/assignment-review/annotation-modification/annotation-modification.component.html ***!
  \*************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-navbar></app-navbar>\n\n<!-- Container for sidebar(s) + page content -->\n<ng-sidebar-container style=\"height: 800px;\">\n  <!-- A sidebar -->\n  <ng-sidebar [(opened)]=\"_opened\">\n    <app-side-panel></app-side-panel>\n  </ng-sidebar>\n\n  <!-- Page content -->\n  <div ng-sidebar-content>\n    <div class=\"container\">\n      <br>\n      <a (click)=\"goBack()\" style=\"color: blue;cursor: pointer\">\n        <<- Go Back</a>\n\n      <div style=\"margin-top:5px;\">\n        <div class=\"row\">\n          <div class=\"col-2\"></div>\n          <div class=\"col-5\">\n            <button class=\"btn btn-outline-dark btn-block\" (click)=\"saveImageAnnotation()\">Submit All Changes</button>\n          </div>\n          <div class=\"col-3\">\n            <div class=\"btn-group pull-right\">\n              <button class=\"btn\" (click)=\"selectRect()\" autofocus=\"autofocus\">\n                <i class=\"fa fa-square-o\"></i>\n              </button> &nbsp;\n              <button class=\"btn\" (click)=\"selectDot()\">\n                <i class=\"fa fa-plus\"></i>\n              </button>&nbsp;\n              <button class=\"btn\" (click)=\"selectEraser()\">\n                <i class=\"fa fa-eraser\"></i>\n              </button>&nbsp;\n              <button class=\"btn\" (click)=\"selectMouse()\">\n                <i class=\"fa fa-mouse-pointer\"></i>\n              </button>&nbsp;\n              <button class=\"btn\" (click)=\"deleteAllDots()\">\n                <i class=\"fa fa-ban\"></i>\n              </button>&nbsp;\n            </div>\n          </div>\n          <div class=\"col-2\"></div>\n        </div>\n      </div>\n      <div id=\"stage-div\" style=\"  margin:auto;margin-top:20px;\">\n        <ko-stage #stage [config]=\"configStage\" id=\"canvas\" (mousedown)=\"drawingOn()\" (mouseup)=\"drawingOff()\">\n          <ko-layer #imageLayer id=\"image-layer\">\n            <ko-image #image [config]=\"imageConfig\"></ko-image>\n          </ko-layer>\n          <ko-layer #rectLayer>\n            <ko-rect #rect *ngFor=\"let rectItem of rectConfigList; let i = index; let l = last\" [config]=\"rectItem\"\n                     (click)=\"onClickRect($event)\"></ko-rect>\n          </ko-layer>\n          <ko-layer #dotLayer>\n            <ko-circle #dot *ngFor=\"let dotItem of dotConfigList; let i = index; let l = last\" [config]=\"dotItem\"\n                       (click)=\"onClickDot($event)\" (mouseover)=\"onMouseOverDot($event)\"></ko-circle>\n          </ko-layer>\n        </ko-stage>\n      </div>\n      <br>\n      <div *ngIf=\"displaySavedSuccess\" class=\"alert alert-success\">Annotation saved successfully.</div>\n      <div *ngIf=\"savingFailed\" class=\"alert alert-danger\">Failed to save annotation. Please try again later.</div>\n      <div class=\"form-check form-check-inline\">\n        <input class=\"form-check-input\" type=\"radio\" name=\"status\" id=\"inlineRadio1\" [value]=\"0\" [(ngModel)]=\"status\">\n        <label class=\"form-check-label\" for=\"inlineRadio1\">Normal</label>\n      </div>\n      <div class=\"form-check form-check-inline\">\n        <input class=\"form-check-input\" type=\"radio\" name=\"status\" id=\"inlineRadio2\" [value]=\"1\" [(ngModel)]=\"status\">\n        <label class=\"form-check-label\" for=\"inlineRadio2\">Abnormal</label>\n      </div>\n      <div class=\"form-check form-check-inline\">\n        <input class=\"form-check-input\" type=\"radio\" name=\"status\" id=\"inlineRadio2\" [value]=\"2\" [(ngModel)]=\"status\"\n               checked=\"checked\">\n        <label class=\"form-check-label\" for=\"inlineRadio2\">N/A</label>\n      </div>\n\n      <hr>\n      <div class=\"row\">\n        <div class=\"col-5\">\n          <h6>Tags</h6>\n          <a *ngFor=\"let tag of tagList\" class=\"badge badge-pill badge-light\" style=\"cursor: pointer;\"\n             (click)=\"selectTag(tag)\">{{tag}}</a>\n          <br>\n          <br>\n          <div class=\"form-group\">\n            <input class=\"form-control\" [(ngModel)]=\"currentTag\" name=\"tag\" value=\"currentTag\" disabled>\n          </div>\n        </div>\n        <div class=\"col-2\"></div>\n        <div class=\"col-5\">\n          <p>Image Type:\n            <span [ngSwitch]=\"currentTask?.taskType\">\n                  <span *ngSwitchCase=\"0\">\n                    <b>Dot</b>\n                  </span>\n                  <span *ngSwitchCase=\"1\">\n                    <b>Rect</b>\n                  </span>\n                </span>\n          </p>\n          <p>X:\n            <span id=\"mouseX\"></span>, Y:\n            <span id=\"mouseY\"></span>\n          </p>\n          <p>Image Size:\n            <span id='image-width'></span>px,\n            <span id='image-height'></span>px\n          </p>\n        </div>\n      </div>\n\n\n      <span id=\"scaleX\" hidden></span>\n      <span id=\"scaleY\" hidden></span>\n      <span id=\"defaultHeight\" hidden></span>\n\n    </div>\n\n  </div>\n</ng-sidebar-container>\n"

/***/ }),

/***/ "./src/app/components/assignment-review/annotation-modification/annotation-modification.component.ts":
/*!***********************************************************************************************************!*\
  !*** ./src/app/components/assignment-review/annotation-modification/annotation-modification.component.ts ***!
  \***********************************************************************************************************/
/*! exports provided: AnnotationModificationComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AnnotationModificationComponent", function() { return AnnotationModificationComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _app_const__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../app-const */ "./src/app/app-const.ts");
/* harmony import */ var _services_image_service_image_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../services/image-service/image.service */ "./src/app/services/image-service/image.service.ts");
/* harmony import */ var _services_task_service_task_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../services/task-service/task.service */ "./src/app/services/task-service/task.service.ts");
/* harmony import */ var _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../services/helper-service/helper.service */ "./src/app/services/helper-service/helper.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _services_assignment_service_assignment_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../services/assignment-service/assignment.service */ "./src/app/services/assignment-service/assignment.service.ts");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_9__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};










var AnnotationModificationComponent = /** @class */ (function () {
    function AnnotationModificationComponent(imageService, taskService, helperService, router, route, _location, assignmentService) {
        var _this = this;
        this.imageService = imageService;
        this.taskService = taskService;
        this.helperService = helperService;
        this.router = router;
        this.route = route;
        this._location = _location;
        this.assignmentService = assignmentService;
        this._opened = false;
        this.serverPath = _app_const__WEBPACK_IMPORTED_MODULE_3__["AppConst"].serverPath;
        this.rectIndex = 0;
        this.dotIndex = 0;
        this.mouse = {};
        this.isDrawing = false;
        this.rectConfigList = [];
        this.effectiveDrawing = false;
        this.rectAnnotationList = [];
        this.status = 2;
        this.savingSuccess = false;
        this.savingFailed = false;
        this.dotConfigList = [];
        this.dotAnnotationList = [];
        this.currentTool = 'mouse';
        this.that = this;
        this.imageSelected = false;
        this.imageModified = false;
        this.imageSaved = false;
        this.dotDescriptionList = [];
        this.rectDescriptionList = [];
        this.displaySavedSuccess = false;
        this.dotTagList = [];
        this.tagList = [];
        this.dotSn = 0;
        this.route.params.forEach(function (params) {
            _this.currentTaskId = Number.parseInt(params['taskId']);
            _this.taskService.getTaskById(_this.currentTaskId).subscribe(function (res) {
                console.log(res.json());
                _this.currentTask = res.json();
                _this.route
                    .queryParams
                    .subscribe(function (params) {
                    // Defaults to 0 if no query param provided.
                    _this.assignmentId = +params['assignmentId'];
                    _this.patientId = params['patientId'];
                    console.log('patient id: ' + _this.patientId);
                    _this.helperService.setModifiedImageInfo(_this.assignmentId, _this.patientId, _this.currentTask.imageItem);
                    _this.assignmentService.getAssignmentByAssignmentId(_this.assignmentId).subscribe(function (res) {
                        var assignment = res.json();
                        _this.tagList = assignment.tagList;
                    }, function (error) {
                        console.log(error);
                    });
                });
                _this.onLoadImage();
            }, function (error) {
                console.log(error);
            });
        });
    }
    /*  display shapes for different select tool  */
    AnnotationModificationComponent.prototype.selectRect = function () {
        this.currentTool = 'rect';
        console.log(this.currentTool);
        jquery__WEBPACK_IMPORTED_MODULE_9__('#stage-div').css('cursor', 'url(assets/images/cursor-rect.png), auto');
    };
    AnnotationModificationComponent.prototype.selectDot = function () {
        this.currentTool = 'dot';
        console.log(this.currentTool);
        jquery__WEBPACK_IMPORTED_MODULE_9__('#stage-div').css('cursor', 'crosshair');
    };
    AnnotationModificationComponent.prototype.selectEraser = function () {
        this.currentTool = 'eraser';
        console.log(this.currentTool);
        jquery__WEBPACK_IMPORTED_MODULE_9__('#stage-div').css('cursor', 'url(assets/images/cursor-circle.png) 10 10, auto');
    };
    AnnotationModificationComponent.prototype.selectMouse = function () {
        this.currentTool = 'mouse';
        console.log(this.currentTool);
        jquery__WEBPACK_IMPORTED_MODULE_9__('#stage-div').css('cursor', 'default');
    };
    /* clicking behavior  */
    AnnotationModificationComponent.prototype.onClickRect = function (rect) {
        if (this.previousShape != null) {
            this.previousShape.getStage().stroke('red');
            this.stage.getStage().draw();
        }
        var index = rect.getStage().name().substring(4);
        /* 4 means */
        if (this.currentTool == 'eraser') {
            this.imageService.currentDescription = {};
            this.rectAnnotationList[index] = [];
            rect.getStage().width(0);
            rect.getStage().height(0);
            this.rectLayer.getStage().draw();
        }
        else {
            this.previousShape = rect;
            rect.getStage().stroke('blue');
            this.stage.getStage().draw();
            this.imageService.currentDescription = {
                'description': this.rectDescriptionList[index],
                'index': index,
                'type': 'rect'
            };
        }
    };
    AnnotationModificationComponent.prototype.onClickDot = function (dot) {
        if (this.previousShape != null) {
            this.previousShape.getStage().stroke('red');
            if (this.previousShape.getStage().name().startsWith('dot')) {
                this.previousShape.getStage().stroke('transparent');
            }
            this.stage.getStage().draw();
        }
        var index = dot.getStage().name().substring(3);
        /* 3 means */
        this.dotIndex = index;
        if (this.currentTool == 'eraser') {
            this.imageService.currentDescription = {};
            this.dotAnnotationList[index] = [];
            dot.getStage().radius(0);
            this.stage.getStage().draw();
        }
        else {
            this.previousShape = dot;
            dot.getStage().stroke('blue');
            this.stage.getStage().draw();
            this.currentTag = this.dotTagList[index];
        }
    };
    AnnotationModificationComponent.prototype.selectTag = function (tag) {
        this.currentTag = tag;
        console.log('dot index: ' + this.dotIndex);
        this.dotTagList[this.dotIndex] = tag;
    };
    AnnotationModificationComponent.prototype.drawingOn = function () {
        var _this = this;
        this.imageSaved = false;
        var mousex = Number(jquery__WEBPACK_IMPORTED_MODULE_9__('#mouseX').text());
        var mousey = Number(jquery__WEBPACK_IMPORTED_MODULE_9__('#mouseY').text());
        var scaleX = Number(jquery__WEBPACK_IMPORTED_MODULE_9__('#scaleX').text());
        var scaleY = Number(jquery__WEBPACK_IMPORTED_MODULE_9__('#scaleY').text());
        if (this.currentTool == 'rect') {
            this.currentRect = this.rectList.toArray()[this.rectIndex].getStage();
            // this.startX = this.mouseX;
            // this.startY = this.mouseY;
            this.startX = mousex;
            this.startY = mousey;
            this.currentRect.x(this.startX * scaleX);
            this.currentRect.y(this.startY * scaleY);
            this.timer = Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["interval"])(10).subscribe(function (x) {
                _this.dragging();
                //   this.layer.getStage().batchDraw();
                _this.currentRect.getStage().draw();
                //   console.log("test");
            });
        }
    };
    AnnotationModificationComponent.prototype.dragging = function () {
        var mousex = Number(jquery__WEBPACK_IMPORTED_MODULE_9__('#mouseX').text());
        var mousey = Number(jquery__WEBPACK_IMPORTED_MODULE_9__('#mouseY').text());
        var scaleX = Number(jquery__WEBPACK_IMPORTED_MODULE_9__('#scaleX').text());
        var scaleY = Number(jquery__WEBPACK_IMPORTED_MODULE_9__('#scaleY').text());
        this.currentRect.width((mousex - this.startX) * scaleX);
        this.currentRect.height((mousey - this.startY) * scaleY);
    };
    AnnotationModificationComponent.prototype.drawingOff = function () {
        var mousex = Number(jquery__WEBPACK_IMPORTED_MODULE_9__('#mouseX').text());
        var mousey = Number(jquery__WEBPACK_IMPORTED_MODULE_9__('#mouseY').text());
        var scaleX = Number(jquery__WEBPACK_IMPORTED_MODULE_9__('#scaleX').text());
        var scaleY = Number(jquery__WEBPACK_IMPORTED_MODULE_9__('#scaleY').text());
        if (this.currentTool == 'rect') {
            this.timer.unsubscribe();
            this.endX = mousex;
            this.endY = mousey;
            this.currentRect.name('rect' + this.rectIndex);
            this.redrawShape();
            this.currentRect.getStage().draw();
            if (this.effectiveDrawing) {
                this.imageModified = true;
                this.imageService.setCurrentImageSaved(false);
                this.rectIndex += 1;
            }
        }
        if (this.currentTool == 'dot') {
            this.currentDot = this.dotList.toArray()[this.dotIndex].getStage();
            var x = mousex;
            var y = mousey;
            this.currentDot.x(x * scaleX);
            this.currentDot.y(y * scaleY);
            this.currentDot.radius(2);
            this.currentDot.draggable(true);
            this.currentDot.name('dot' + this.dotIndex);
            this.currentDot.getStage().draw();
            this.imageModified = true;
            this.imageService.setCurrentImageSaved(false);
            this.dotSn += 1;
            this.dotAnnotationList[this.dotIndex] = [(x).toFixed(0) + '', (y).toFixed(0) + '', this.dotSn + ''];
            this.dotTagList[this.dotIndex] = 'default';
            this.helperService.tag = { tag: 'default' };
            this.dotIndex += 1;
        }
    };
    /* what does this function do?? */
    AnnotationModificationComponent.prototype.redrawShape = function () {
        var scaleX = Number(jquery__WEBPACK_IMPORTED_MODULE_9__('#scaleX').text());
        var scaleY = Number(jquery__WEBPACK_IMPORTED_MODULE_9__('#scaleY').text());
        this.currentRect.x(this.startX * scaleX);
        this.currentRect.y(this.startY * scaleY);
        var w = this.endX - this.startX;
        var h = this.endY - this.startY;
        this.currentRect.width(w * scaleX);
        this.currentRect.height(h * scaleY);
        if (w <= 5 || h <= 5) {
            this.effectiveDrawing = false;
        }
        else {
            this.effectiveDrawing = true;
            //record annotation values for rect
            // this.pakList[this.index] = {"x":this.startX, "y":this.startY, "w":w, "h":h };
            this.rectAnnotationList[this.rectIndex] = [this.startX.toFixed(0) + '', this.startY.toFixed(0) + '', (w).toFixed(0) + '', (h).toFixed(0) + ''];
        }
    };
    AnnotationModificationComponent.prototype.getImage = function (name) {
        var _this = this;
        this.imageService.getImage(name).subscribe(function (res) {
            console.log(res.json()['fileName']);
            _this.imageName = res.json()['fileName'];
        }, function (error) {
            console.log(error);
        });
    };
    AnnotationModificationComponent.prototype.print = function () {
        this.currentRect = this.rectList.toArray()[this.rectIndex].getStage();
        this.currentRect.getStage().draw();
    };
    AnnotationModificationComponent.prototype.saveImageAnnotation = function () {
        var _this = this;
        var that = this;
        this.imageService.currentDescription = {};
        this.imageSaved = true;
        this.imageService.setCurrentImageSaved(true);
        this.imageService.saveImageAnnotation(this.rectAnnotationList, this.dotAnnotationList, this.currentTask, this.status, this.dotDescriptionList, this.rectDescriptionList, this.dotTagList).subscribe(function (res) {
            var taskId = res.json();
            _this.taskService.getTaskById(taskId).subscribe(function (res) {
                _this.currentTask = res.json();
                _this.savingSuccess = true;
                _this.displaySavedSuccess = true;
                setTimeout(function () {
                    that.displaySavedSuccess = false;
                }.bind(_this), 3000);
            }, function (error) {
                console.log(error);
            });
        }, function (err) {
            _this.savingFailed = true;
        });
    };
    AnnotationModificationComponent.prototype.onLoadImage = function () {
        this.imageSaved = false;
        this.imageModified = false;
        this.imageService.setCurrentImageSaved(true);
        //clear up data
        for (var i = 0; i < 100; i++) {
            this.rectConfigList[i].next({
                x: 0,
                y: 0,
                width: 0,
                height: 0,
                fill: 'transparent',
                stroke: 'red',
                strokeWidth: 2
            });
        }
        for (var i = 0; i < 100; i++) {
            this.dotConfigList[i].next({
                x: 0,
                y: 0,
                radius: 0,
                fill: '#00FF00',
                stroke: 'transparent',
                strokeWidth: 5,
            });
        }
        this.rectAnnotationList = [];
        this.dotAnnotationList = [];
        this.dotDescriptionList = [];
        this.rectDescriptionList = [];
        this.rectIndex = 0;
        this.dotIndex = 0;
        this.savingSuccess = false;
        this.currentTool = 'mouse';
        jquery__WEBPACK_IMPORTED_MODULE_9__('#stage-div').css('cursor', 'default');
        console.log(this.currentTask);
        console.log(this.annotationWidth);
        //prepare references for functional callback usage
        var stageRef = this.stage;
        var imageLayerRef = this.imageLayer;
        var imageRef = this.image;
        var imageObjRef = this.imageObj;
        var annotationWidthRef = this.annotationWidth;
        var imageConfigRef = {};
        var configStageRef = {};
        var that = this;
        var mouseRef = this.mouse;
        var url = this.serverPath + '/image/getImage/' + this.currentTask.imageItem.folderPath;
        this.imageObj.src = url;
        var image = new Image();
        image.src = url;
        image.onload = function () {
            var w = image.width;
            var h = image.height;
            jquery__WEBPACK_IMPORTED_MODULE_9__('#image-width').text(w);
            jquery__WEBPACK_IMPORTED_MODULE_9__('#image-height').text(h);
            var stageHeight = Number(jquery__WEBPACK_IMPORTED_MODULE_9__('#defaultHeight').text());
            if (stageHeight == 0) {
                stageHeight = document.getElementById('stage-div').offsetHeight;
                jquery__WEBPACK_IMPORTED_MODULE_9__('#defaultHeight').text(stageHeight);
            }
            var scaleY = stageHeight / h;
            var stageWidth = w / h * stageHeight;
            if ((w / h * stageHeight) > annotationWidthRef - 50) {
                stageWidth = annotationWidthRef - 50;
                stageHeight = stageWidth * h / w;
                scaleY = stageHeight / h;
            }
            else {
                stageWidth = w / h * stageHeight;
            }
            var scaleX = stageWidth / w;
            jquery__WEBPACK_IMPORTED_MODULE_9__('#scaleX').text(scaleX);
            jquery__WEBPACK_IMPORTED_MODULE_9__('#scaleY').text(scaleY);
            that.scaleX = scaleX;
            that.scaleY = scaleY;
            imageRef.getStage().height(stageHeight);
            imageRef.getStage().width(stageWidth);
            imageLayerRef.getStage().draw();
            stageRef.getStage().width(stageWidth);
            stageRef.getStage().height(stageHeight);
            stageRef.getStage().draw();
            jquery__WEBPACK_IMPORTED_MODULE_9__('#stage-div').width(stageWidth);
            jquery__WEBPACK_IMPORTED_MODULE_9__('#stage-div').height(stageHeight);
            that.getAnnotation(scaleX, scaleY);
            jquery__WEBPACK_IMPORTED_MODULE_9__('#stage-div').mousemove(function (event) {
                var mousex = (event.offsetX / scaleX).toFixed(0);
                var mousey = (event.offsetY / scaleY).toFixed(0);
                jquery__WEBPACK_IMPORTED_MODULE_9__('#mouseX').text(mousex);
                jquery__WEBPACK_IMPORTED_MODULE_9__('#mouseY').text(mousey);
                mouseRef = { 'x': mousex, 'y': mousey };
            });
        };
    };
    AnnotationModificationComponent.prototype.getAnnotation = function (scaleX, scaleY) {
        var _this = this;
        //get annotation for current image
        this.imageService.getAnnotationByTask(this.currentTaskId).subscribe(
        // this.imageService.getAnnotationByTask(550).subscribe(
        function (res) {
            var currentAnnotationMapper = res.json();
            var currentDotList = currentAnnotationMapper['dotList'];
            var currentRectList = currentAnnotationMapper['rectList'];
            var currentState = currentAnnotationMapper['state'];
            for (var i = 0; i < currentDotList.length; i++) {
                _this.dotConfigList[i].next({
                    x: currentDotList[i]['offsetX'] * scaleX,
                    y: currentDotList[i]['offsetY'] * scaleY,
                    radius: 2,
                    fill: '#00FF00',
                    stroke: 'transparent',
                    strokeWidth: 5,
                    // strokeEnabled: false
                    name: 'dot' + i,
                    draggable: true
                });
                _this.dotAnnotationList[_this.dotIndex] = [currentDotList[i]['offsetX'] + '', currentDotList[i]['offsetY'] + '', currentDotList[i]['sn'] + ''];
                _this.dotDescriptionList[i] = currentDotList[i]['description'];
                _this.dotTagList[i] = currentDotList[i]['tag'];
                _this.dotIndex += 1;
                if (Number(currentDotList[i]['sn']) > _this.dotSn) {
                    _this.dotSn = Number(currentDotList[i]['sn']);
                }
            }
            for (var i = 0; i < currentRectList.length; i++) {
                _this.rectConfigList[i].next({
                    x: currentRectList[i]['offsetX'] * scaleX,
                    y: currentRectList[i]['offsetY'] * scaleY,
                    width: currentRectList[i]['offsetWidth'] * scaleX,
                    height: currentRectList[i]['offsetHeight'] * scaleY,
                    fill: 'transparent',
                    stroke: 'red',
                    strokeWidth: 2,
                    name: 'rect' + i
                });
                _this.rectAnnotationList[_this.rectIndex] = [currentRectList[i]['offsetX'] + '', currentRectList[i]['offsetY'] + '', currentRectList[i]['offsetWidth'] + '', currentRectList[i]['offsetHeight'] + ''];
                _this.rectDescriptionList[i] = currentRectList[i]['description'];
                _this.rectIndex += 1;
            }
            console.log(_this.dotDescriptionList);
            console.log(_this.rectDescriptionList);
            if (currentState != null) {
                _this.status = currentState.status;
            }
        }, function (error) {
            console.log(error);
        });
    };
    AnnotationModificationComponent.prototype.deleteAllDots = function () {
        this.imageService.setCurrentImageSaved(false);
        console.log(this.dotAnnotationList);
        for (var i = 0; i < this.dotAnnotationList.length; i++) {
            var dot = this.dotList.toArray()[i].getStage();
            dot.x(0);
            dot.y(0);
            dot.radius(0);
            dot.stroke('transparent');
            dot.draw();
        }
        this.previousShape = null;
        this.dotAnnotationList = [];
        this.dotIndex = 0;
        this.stage.getStage().draw();
        this.dotSn = 0;
    };
    AnnotationModificationComponent.prototype.canvasInit = function () {
        this.imageConfig = Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])({
            x: 0,
            y: 0,
            image: this.imageObj,
            width: this.imageWidth,
            height: this.imageHeight
        });
        this.configStage = Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])({
            container: 'canvas',
            x: 0,
            y: 0,
            width: this.imageWidth,
            height: this.imageHeight
        });
    };
    AnnotationModificationComponent.prototype.goBack = function () {
        // console.log(this.currentTask);
        // let url = 'http://' + window.location.host + '/#/assignmentReview/' + this.assignmentId;
        // console.log(url);
        // window.location.href = url;
        // window.location.reload();
        this.helperService.clickAdminPanel = true;
        var that = this;
        setTimeout(function () {
            window.location.href = 'http://' + window.location.host + '/#/assignmentReview/' + that.assignmentId + '?selectPatientAndImage=true';
        }, 100);
        // window.location.reload();
        // this.router.navigate(['/adminPanel/']);
        // this.router.navigate(['/assignmentReview/' + this.assignmentId], {queryParams: {'selectPatientAndImage' : true}});
    };
    AnnotationModificationComponent.prototype.onMouseOverDot = function (dot) {
        var that = this;
        dot.getStage().on('dragend', function () {
            console.log('drag end: ' + dot.getStage().name());
            var x = Number(jquery__WEBPACK_IMPORTED_MODULE_9__('#mouseX').text());
            var y = Number(jquery__WEBPACK_IMPORTED_MODULE_9__('#mouseY').text());
            var scaleX = Number(jquery__WEBPACK_IMPORTED_MODULE_9__('#scaleX').text());
            var scaleY = Number(jquery__WEBPACK_IMPORTED_MODULE_9__('#scaleY').text());
            var index = dot.getStage().name().substring(3);
            var sn = that.dotAnnotationList[index][2];
            that.dotAnnotationList[index] = [(x).toFixed(0) + '', (y).toFixed(0) + '', sn + ''];
        });
    };
    AnnotationModificationComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.imageService.newDescriptionObject$.subscribe(function (object) {
            var description = object['description'];
            var labelIndex = object['index'];
            var labelType = object['type'];
            console.log(description, labelIndex, labelType);
            if (labelType == 'rect') {
                _this.rectDescriptionList[labelIndex] = description;
            }
            else if (labelType == 'dot') {
                _this.dotDescriptionList[labelIndex] = description;
            }
        });
        for (var i = 0; i < 100; i++) {
            this.rectConfigList.push(new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]({
                x: 0,
                y: 0,
                width: 0,
                height: 0,
                fill: 'transparent',
                stroke: 'red',
                strokeWidth: 2,
            }));
        }
        for (var i = 0; i < 100; i++) {
            this.dotConfigList.push(new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]({
                x: 0,
                y: 0,
                radius: 0,
                fill: '#00FF00',
                stroke: 'transparent',
                strokeWidth: 5,
                // strokeEnabled: false
                draggable: true
            }));
        }
        this.imageObj = new Image();
        this.imageObj.src = 'assets/images/getstarted.jpg';
        this.imageObj.onload = function () {
        };
        this.imageWidth = 750;
        this.imageHeight = 650;
        jquery__WEBPACK_IMPORTED_MODULE_9__('#stage-div').width(this.imageWidth);
        jquery__WEBPACK_IMPORTED_MODULE_9__('#stage-div').height(this.imageHeight);
        this.imageObj.onload = this.canvasInit();
        console.log(this.imageObj);
        this.imageSaved = false;
        this.imageModified = false;
        this.imageService.setCurrentImageSaved(true);
        this.helperService.sideMenuStatus$.subscribe(function (open) {
            _this._opened = open;
        });
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('rectLayer'),
        __metadata("design:type", Object)
    ], AnnotationModificationComponent.prototype, "rectLayer", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('stage'),
        __metadata("design:type", Object)
    ], AnnotationModificationComponent.prototype, "stage", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChildren"])('rect'),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["QueryList"])
    ], AnnotationModificationComponent.prototype, "rectList", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChildren"])('dotLayer'),
        __metadata("design:type", Object)
    ], AnnotationModificationComponent.prototype, "dotLayer", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChildren"])('dot'),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["QueryList"])
    ], AnnotationModificationComponent.prototype, "dotList", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('image'),
        __metadata("design:type", Object)
    ], AnnotationModificationComponent.prototype, "image", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('imageLayer'),
        __metadata("design:type", Object)
    ], AnnotationModificationComponent.prototype, "imageLayer", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])('width'),
        __metadata("design:type", Object)
    ], AnnotationModificationComponent.prototype, "annotationWidth", void 0);
    AnnotationModificationComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-annotation-modification',
            template: __webpack_require__(/*! ./annotation-modification.component.html */ "./src/app/components/assignment-review/annotation-modification/annotation-modification.component.html"),
            styles: [__webpack_require__(/*! ./annotation-modification.component.css */ "./src/app/components/assignment-review/annotation-modification/annotation-modification.component.css")]
        }),
        __metadata("design:paramtypes", [_services_image_service_image_service__WEBPACK_IMPORTED_MODULE_4__["ImageService"], _services_task_service_task_service__WEBPACK_IMPORTED_MODULE_5__["TaskService"], _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_6__["HelperService"], _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"], _angular_common__WEBPACK_IMPORTED_MODULE_7__["Location"], _services_assignment_service_assignment_service__WEBPACK_IMPORTED_MODULE_8__["AssignmentService"]])
    ], AnnotationModificationComponent);
    return AnnotationModificationComponent;
}());



/***/ }),

/***/ "./src/app/components/assignment-review/assignment-review.component.css":
/*!******************************************************************************!*\
  !*** ./src/app/components/assignment-review/assignment-review.component.css ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".main{\n    width:95%;\n    margin: auto;\n}\n\n.selected {\n  border: 3px solid hotpink;\n}\n\n.box {\n    border: 1px solid black;\n}\n\n.image-review{\n    margin:auto;\n}\n\n.item {\n    position:relative;\n    padding-top:20px;\n    display:inline-block;\n}\n\n.notify-badge {\n  position:relative;\n  bottom: -30px;\n  right: -10px;\n  margin: 0 0 0 0;\n}\n\n/*input[type=radio]{*/\n\n/*transform:scale(3);*/\n\n/*}*/\n\n.checkbox label:after,\n.radio label:after {\n  content: '';\n  display: table;\n  clear: both;\n}\n\n.checkbox .cr,\n.radio .cr {\n  position: relative;\n  display: inline-block;\n  border: 1px solid #a9a9a9;\n  border-radius: .25em;\n  width: 1.3em;\n  height: 1.3em;\n  float: left;\n  margin-right: .5em;\n}\n\n.radio .cr {\n  border-radius: 50%;\n}\n\n.checkbox .cr .cr-icon,\n.radio .cr .cr-icon {\n  position: absolute;\n  font-size: .8em;\n  line-height: 0;\n  top: 50%;\n  left: 20%;\n}\n\n.radio .cr .cr-icon {\n  margin-left: 0.04em;\n}\n\n.checkbox label input[type=\"checkbox\"],\n.radio label input[type=\"radio\"] {\n  display: none;\n}\n\n.checkbox label input[type=\"checkbox\"] + .cr > .cr-icon,\n.radio label input[type=\"radio\"] + .cr > .cr-icon {\n  -webkit-transform: scale(3) rotateZ(-20deg);\n          transform: scale(3) rotateZ(-20deg);\n  opacity: 0;\n  transition: all .3s ease-in;\n}\n\n.checkbox label input[type=\"checkbox\"]:checked + .cr > .cr-icon,\n.radio label input[type=\"radio\"]:checked + .cr > .cr-icon {\n  -webkit-transform: scale(1) rotateZ(0deg);\n          transform: scale(1) rotateZ(0deg);\n  opacity: 1;\n}\n\n.checkbox label input[type=\"checkbox\"]:disabled + .cr,\n.radio label input[type=\"radio\"]:disabled + .cr {\n  opacity: .5;\n}\n"

/***/ }),

/***/ "./src/app/components/assignment-review/assignment-review.component.html":
/*!*******************************************************************************!*\
  !*** ./src/app/components/assignment-review/assignment-review.component.html ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div>\n  <app-navbar></app-navbar>\n\n  <!-- Container for sidebar(s) + page content -->\n  <ng-sidebar-container style=\"height: 800px;\">\n    <!-- A sidebar -->\n    <ng-sidebar [(opened)]=\"_opened\">\n      <app-side-panel></app-side-panel>\n    </ng-sidebar>\n\n    <!-- Page content -->\n    <div ng-sidebar-content>\n      <div class=\"main\" style=\"margin-top: 50px; \">\n        <simple-notifications></simple-notifications>\n        <div class=\"row\" style=\"min-height: 700px;\">\n          <div class=\"col-9\">\n            <div class=\"row\">\n              <div class=\"col-6 text-center\">\n                <div class=\"image-review d-flex justify-content-center\" style=\"display: flex;align-items: center;\">\n                  <div class=\"d-flex justify-content-center\"\n                       style=\"width:675px; height:525px;display: flex;align-items: center;\">\n                    <ko-stage #stage1 [config]=\"configStage1\" id=\"canvas1\">\n                      <ko-layer #imageLayer1 id=\"image-layer1\">\n                        <ko-image #image1 [config]=\"imageConfig1\"></ko-image>\n                      </ko-layer>\n                      <ko-layer #rectLayer1>\n                        <ko-rect #rect1 *ngFor=\"let rectItem of rectConfigList1; let i = index; let l = last\"\n                                 [config]=\"rectItem\"></ko-rect>\n                      </ko-layer>\n                      <ko-layer #dotLayer1>\n                        <ko-circle #dot1 *ngFor=\"let dotItem of dotConfigList1; let i = index; let l = last\"\n                                   [config]=\"dotItem\"></ko-circle>\n                      </ko-layer>\n                    </ko-stage>\n                  </div>\n                </div>\n\n                <div *ngIf=\"showImageOne\" >\n                  <span class=\"form-check form-check-inline\" style=\"margin-top: 60px; margin-bottom: 30px;\">\n                    <input class=\"form-check-input\" type=\"radio\" name=\"status\" id=\"inlineRadio1\" value=\"1\"\n                           [(ngModel)]=\"selectedImage\" (ngModelChange)=\"onSelectCorrectImage($event)\">\n                    <label style=\" margin-left: 15px;\" class=\"form-check-label\" for=\"inlineRadio1\">\n                      <span class=\"btn btn-outline-dark btn-block\">Correct</span>\n                    </label>\n                  </span>\n                  <span>\n                    <button class=\"btn btn-outline-dark btn-block \" (click)=\"onModifyImage1()\">Modify</button>\n                  </span>\n                </div>\n\n              </div>\n              <div class=\"col-6 text-center\">\n                <div class=\"image-review d-flex justify-content-center\" style=\"display: flex;align-items: center;\">\n                  <div class=\"d-flex justify-content-center\"\n                       style=\"width:650px; height:525px;display: flex;align-items: center;\">\n                    <ko-stage #stage2 [config]=\"configStage2\" id=\"canvas2\">\n                      <ko-layer #imageLayer2 id=\"image-layer2\">\n                        <ko-image #image2 [config]=\"imageConfig2\"></ko-image>\n                      </ko-layer>\n                      <ko-layer #rectLayer2>\n                        <ko-rect #rect2 *ngFor=\"let rectItem of rectConfigList2; let i = index; let l = last\"\n                                 [config]=\"rectItem\"></ko-rect>\n                      </ko-layer>\n                      <ko-layer #dotLayer2>\n                        <ko-circle #dot2 *ngFor=\"let dotItem of dotConfigList2; let i = index; let l = last\"\n                                   [config]=\"dotItem\"></ko-circle>\n                      </ko-layer>\n                    </ko-stage>\n                  </div>\n                </div>\n\n                <div *ngIf=\"showImageTwo\">\n                  <span class=\"form-check form-check-inline\" style=\"margin-top: 60px; margin-bottom: 30px;\">\n                    <input class=\"form-check-input\" type=\"radio\" name=\"status\" id=\"inlineRadio2\" value=\"2\"\n                           [(ngModel)]=\"selectedImage\" (ngModelChange)=\"onSelectCorrectImage($event)\">\n                    <label style=\"margin-left: 15px;\" class=\"form-check-label\" for=\"inlineRadio2\">\n                      <span class=\"btn btn-outline-dark btn-block\">Correct</span>\n                    </label>\n                  </span>\n                  <span>\n                    <button class=\"btn btn-outline-dark btn-block \" (click)=\"onModifyImage2()\">Modify</button>\n                  </span>\n                </div>\n\n              </div>\n            </div>\n            <br>\n            <br>\n\n            <ngb-alert *ngIf=\"imagePicked\" type=\"info\">Image picked.</ngb-alert>\n            <ngb-alert *ngIf=\"assignmentCompleted\" type=\"info\">Assignment submitted.</ngb-alert>\n          </div>\n\n\n          <div class=\"col-3 box\">\n            <div style=\"margin-top: 10px;\">\n              <button class=\"btn btn-dark btn-block\" (click)=\"onCompleteAssignment()\" style=\"margin-top: 10px; \">\n                Complete Review\n              </button>\n              <br>\n              <hr>\n              <h5>Patient</h5>\n              <select class=\"form-control\" name=\"currentPatient\" [(ngModel)]=\"currentPatient\"\n                      (change)=\"setCurrentPatient()\">\n                <option value=\"null\" disabled>Select a patient</option>\n                <option *ngFor=\"let patient of patientList\" [ngValue]=\"patient\">{{patient.name}}</option>\n              </select>\n            </div>\n            <hr>\n            <form class=\"form-inline\" style=\"margin-top: 20px;\">\n              <div class=\"input-group\" style=\"width: 170px;\">\n                <div class=\"input-group-prepend\">\n                  <div class=\"input-group-text\">Items</div>\n                </div>\n                <input type=\"number\" class=\"form-control\" id=\"itemsPerPage\" name=\"itemsPerPage\" min=\"0\"\n                       [(ngModel)]=\"config.itemsPerPage\">\n              </div>\n              &nbsp;&nbsp;\n              <div class=\"input-group\" style=\"width: 170px;\">\n                <div class=\"input-group-prepend\">\n                  <div class=\"input-group-text\">Page</div>\n                </div>\n                <input type=\"number\" class=\"form-control\" id=\"currentPage\" name=\"currentPage\" min=\"0\"\n                       [(ngModel)]=\"config.currentPage\">\n              </div>\n            </form>\n            <hr>\n            <div id=\"image-list\" *ngIf=\"!busy\">\n              <ul  class=\"list-inline\" style=\"margin-bottom: 10px;\">\n                <li #scroll1 style=\"width:120px;\" class=\"list-inline-item\"\n                    *ngFor=\"let image of imageList | stringFilter: filter | paginate: config; let i=index; trackBy: trackByFn\">\n                  <span *ngIf=\"image.selectedTaskId != null\" class=\"badge badge-info notify-badge\">Selected</span>\n                  <div>\n                    <img src=\"{{serverPath}}/image/getImage/{{image.folderPath}}\" class=\"img-fluid\"\n                         style=\"cursor: pointer; width: auto; height: 120px;\" [ngClass]=\"image == currentImage? 'selected' : ''\"\n                         alt=\"Image Thumbnail\" (click)=\"onSelectImage(image)\">\n                  </div>\n                  <span class=\"text-center\"\n                        style=\"font-size: 10pt\">{{image.fileName | slice:0:image.fileName.length-4}}</span>\n                </li>\n              </ul>\n              <pagination-controls style=\"font-size: medium;\" [id]=\"config.id\"\n                                   [maxSize]=\"maxSize\"\n                                   [directionLinks]=\"directionLinks\"\n                                   [autoHide]=\"autoHide\"\n                                   [responsive]=\"responsive\"\n                                   [previousLabel]=\"labels.previousLabel\"\n                                   [nextLabel]=\"labels.nextLabel\"\n                                   [screenReaderPaginationLabel]=\"labels.screenReaderPaginationLabel\"\n                                   [screenReaderPageLabel]=\"labels.screenReaderPageLabel\"\n                                   [screenReaderCurrentLabel]=\"labels.screenReaderCurrentLabel\"\n                                   (pageChange)=\"onPageChange($event)\"></pagination-controls>\n\n\n\n\n            </div>\n\n            <div *ngIf=\"busy\" class=\"text-center\" style=\"margin: 100px 0px 0 0px\">\n              <i class=\"fa fa-spinner fa-3x faa-spin animated\"></i>\n            </div>\n          </div>\n\n        </div>\n\n      </div>\n    </div>\n  </ng-sidebar-container>\n</div>\n"

/***/ }),

/***/ "./src/app/components/assignment-review/assignment-review.component.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/components/assignment-review/assignment-review.component.ts ***!
  \*****************************************************************************/
/*! exports provided: AssignmentReviewComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AssignmentReviewComponent", function() { return AssignmentReviewComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _app_const__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../app-const */ "./src/app/app-const.ts");
/* harmony import */ var _services_image_service_image_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/image-service/image.service */ "./src/app/services/image-service/image.service.ts");
/* harmony import */ var _services_task_service_task_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/task-service/task.service */ "./src/app/services/task-service/task.service.ts");
/* harmony import */ var _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../services/helper-service/helper.service */ "./src/app/services/helper-service/helper.service.ts");
/* harmony import */ var _services_assignment_service_assignment_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../services/assignment-service/assignment.service */ "./src/app/services/assignment-service/assignment.service.ts");
/* harmony import */ var _services_patient_service_patient_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../services/patient-service/patient.service */ "./src/app/services/patient-service/patient.service.ts");
/* harmony import */ var angular2_notifications__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! angular2-notifications */ "./node_modules/angular2-notifications/angular2-notifications.umd.js");
/* harmony import */ var angular2_notifications__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(angular2_notifications__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var ngx_perfect_scrollbar__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ngx-perfect-scrollbar */ "./node_modules/ngx-perfect-scrollbar/dist/ngx-perfect-scrollbar.es5.js");
/* harmony import */ var angular2_hotkeys__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! angular2-hotkeys */ "./node_modules/angular2-hotkeys/index.js");
/* harmony import */ var angular2_hotkeys__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(angular2_hotkeys__WEBPACK_IMPORTED_MODULE_11__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};












var AssignmentReviewComponent = /** @class */ (function () {
    function AssignmentReviewComponent(imageService, taskService, assignmentService, helperService, patientService, router, route, notificationService, _hotkeysService) {
        var _this = this;
        this.imageService = imageService;
        this.taskService = taskService;
        this.assignmentService = assignmentService;
        this.helperService = helperService;
        this.patientService = patientService;
        this.router = router;
        this.route = route;
        this.notificationService = notificationService;
        this._hotkeysService = _hotkeysService;
        this.filter = '';
        this.maxSize = 6;
        this.directionLinks = true;
        this.autoHide = true;
        this.responsive = true;
        this.config = {
            id: 'advanced',
            itemsPerPage: 9,
            currentPage: 1
        };
        this.p = 1;
        this.labels = {
            previousLabel: 'Previous',
            nextLabel: 'Next',
            screenReaderPaginationLabel: 'Pagination',
            screenReaderPageLabel: 'page',
            screenReaderCurrentLabel: "You're on page"
        };
        this.serverPath = _app_const__WEBPACK_IMPORTED_MODULE_3__["AppConst"].serverPath;
        this._opened = false;
        this.imageList = [];
        this.loggedIn = false;
        this.assignmentCompleted = false;
        this.rectIndex = 0;
        this.dotIndex = 0;
        this.rectConfigList1 = [];
        this.rectAnnotationList1 = [];
        this.rectConfigList2 = [];
        this.rectAnnotationList2 = [];
        this.rectConfigList3 = [];
        this.rectAnnotationList3 = [];
        this.rectConfigList4 = [];
        this.rectAnnotationList4 = [];
        this.status = 2;
        this.dotConfigList1 = [];
        this.dotAnnotationList1 = [];
        this.dotConfigList2 = [];
        this.dotAnnotationList2 = [];
        this.dotConfigList3 = [];
        this.dotAnnotationList3 = [];
        this.dotConfigList4 = [];
        this.dotAnnotationList4 = [];
        this.that = this;
        this.dotDescriptionList1 = [];
        this.rectDescriptionList1 = [];
        this.dotDescriptionList2 = [];
        this.rectDescriptionList2 = [];
        this.dotDescriptionList3 = [];
        this.rectDescriptionList3 = [];
        this.dotDescriptionList4 = [];
        this.rectDescriptionList4 = [];
        this.taskList = [];
        this.imagePicked = false;
        this.patientList = [];
        this.assignmentImageList = [];
        this.imageNotCompleted = false;
        this.showImageOne = false;
        this.showImageTwo = false;
        this.route.params.forEach(function (params) {
            _this.assignmentId = Number.parseInt(params['id']);
        });
        this.route
            .queryParams
            .subscribe(function (params) {
            // Defaults to 0 if no query param provided.
            var selectPatientAndImage = params['selectPatientAndImage'];
            console.log(selectPatientAndImage);
            if (selectPatientAndImage) {
                var modifiedImageInfo = _this.helperService.getModifiedImageInfo();
                console.log(modifiedImageInfo);
                var patientId = modifiedImageInfo.patientId;
                var currentimage = modifiedImageInfo.currentImage;
                _this.patientId = patientId;
                console.log(patientId);
                _this.currentImage = currentimage;
                _this.imageService.getPickedImageListByAssignmentAndPatient(_this.assignmentId, _this.patientId).subscribe(function (res) {
                    _this.imageList = res.json();
                    _this.onSelectImage(_this.currentImage);
                    console.log(_this.imageList);
                    console.log(_this.currentImage);
                    var size = _this.imageList.length;
                    var items = _this.config.itemsPerPage;
                    var totalPages = size / items;
                    var i;
                    for (i = 0; i < _this.imageList.length; i++) {
                        if (_this.imageList[i].id == _this.currentImage.id) {
                            _this.currentImage = _this.imageList[i];
                            break;
                        }
                    }
                    var currentPage = Math.ceil((i + 1) / items);
                    if (_this.config.currentPage != currentPage) {
                        _this.config.currentPage = currentPage;
                    }
                }, function (error) {
                    console.log(error);
                });
                _this.imageIndex = _this.helperService.tempImageIndex;
                _this.config.itemsPerPage = _this.helperService.tempItemsPerPage;
            }
        });
        this._hotkeysService.add(new angular2_hotkeys__WEBPACK_IMPORTED_MODULE_11__["Hotkey"]('f', function (event) {
            var i = _this.imageList.indexOf(_this.currentImage);
            if (i < _this.imageList.length - 1) {
                i++;
            }
            _this.onSelectImage(_this.imageList[i]);
            return false; // Prevent bubbling
        }));
        this._hotkeysService.add(new angular2_hotkeys__WEBPACK_IMPORTED_MODULE_11__["Hotkey"]('a', function (event) {
            var i = _this.imageList.indexOf(_this.currentImage);
            if (i > 0) {
                i--;
            }
            _this.onSelectImage(_this.imageList[i]);
            return false; // Prevent bubbling
        }));
    }
    AssignmentReviewComponent.prototype._toggleSidebar = function () {
        this._opened = !this._opened;
    };
    AssignmentReviewComponent.prototype.onPageChange = function (number) {
        console.log('change to page', number);
        this.config.currentPage = number;
    };
    AssignmentReviewComponent.prototype.create = function (content) {
        var title = 'Oops. Not yet.';
        var type = 'warn';
        this.notificationService.create(title, content, type, {
            timeOut: 15000,
            showProgressBar: true,
            pauseOnHover: true,
            position: ['top', 'left']
        });
    };
    AssignmentReviewComponent.prototype.onCompleteAssignment = function () {
        var _this = this;
        this.imageNotCompleted = false;
        this.nonCompoleteImageName = null;
        this.nonCompletePatientName = null;
        this.assignmentImageList = [];
        this.imageService.getPickedImagesByAssignment(this.assignmentId).subscribe(function (res) {
            _this.assignmentImageList = res.json();
            console.log(_this.assignmentImageList);
            for (var i = 0; i < _this.assignmentImageList.length; i++) {
                var image = _this.assignmentImageList[i];
                if (image.selectedTaskId == null) {
                    var patient = image.patient;
                    _this.imageNotCompleted = true;
                    _this.nonCompoleteImageName = image.fileName.substring(0, image.fileName.length - 4);
                    _this.nonCompletePatientName = patient.name;
                    var content = 'There is image NOT reviewed. Patient: \'' + patient.name + '\' => Image: \'' + _this.nonCompoleteImageName + '\'';
                    _this.create(content);
                    return;
                }
            }
            _this.assignmentService.completeAssignment(_this.assignmentId).subscribe(function (res) {
                _this.assignmentCompleted = true;
                console.log(res.json());
            }, function (error) {
                console.log(error);
            });
        }, function (error) {
            console.log(error);
        });
    };
    AssignmentReviewComponent.prototype.onSelectCorrectImage = function (i) {
        var _this = this;
        console.log(i);
        this.imageService.setCorrectImageTask(this.currentImage.id, this.taskList[i - 1].id).subscribe(function (res) {
            console.log(res.json());
            var image = res.json();
            for (var i_1 = 0; i_1 < _this.imageList.length; i_1++) {
                if (_this.imageList[i_1].id == image.id) {
                    _this.imageList[i_1] = image;
                    break;
                }
            }
            // this.scroll1.directiveRef.update();
            _this.imageList = _this.imageList.slice();
            _this.imagePicked = true;
            var that = _this;
            setTimeout(function () {
                that.imagePicked = false;
            }.bind(_this), 3000);
            _this.onSelectImage(image);
            document.getElementById('inlineRadio1').blur();
            document.getElementById('inlineRadio2').blur();
        }, function (error) {
            console.log(error);
        });
    };
    AssignmentReviewComponent.prototype.canvasInit = function () {
        this.imageConfig1 = Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])({
            x: 0,
            y: 0,
            image: this.imageObj1,
            width: this.imageWidth1,
            height: this.imageHeight1
        });
        this.configStage1 = Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])({
            container: 'canvas',
            x: 0,
            y: 0,
            width: this.imageWidth1,
            height: this.imageHeight1
        });
        this.imageConfig2 = Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])({
            x: 0,
            y: 0,
            image: this.imageObj2,
            width: this.imageWidth2,
            height: this.imageHeight2
        });
        this.configStage2 = Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])({
            container: 'canvas',
            x: 0,
            y: 0,
            width: this.imageWidth2,
            height: this.imageHeight2
        });
        this.imageConfig3 = Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])({
            x: 0,
            y: 0,
            image: this.imageObj3,
            width: this.imageWidth3,
            height: this.imageHeight3
        });
        this.configStage3 = Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])({
            container: 'canvas',
            x: 0,
            y: 0,
            width: this.imageWidth3,
            height: this.imageHeight3
        });
        this.imageConfig4 = Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])({
            x: 0,
            y: 0,
            image: this.imageObj4,
            width: this.imageWidth4,
            height: this.imageHeight4
        });
        this.configStage4 = Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])({
            container: 'canvas',
            x: 0,
            y: 0,
            width: this.imageWidth4,
            height: this.imageHeight4
        });
    };
    AssignmentReviewComponent.prototype.getTaskListByAssignmentAndImage = function (assignmentId, imageId) {
        var _this = this;
        this.taskService.getTaskByAssignmentAndImage(assignmentId, imageId).subscribe(function (res) {
            console.log(res.json());
            _this.taskList = res.json();
            if (_this.taskList[0] != null) {
                _this.showImageOne = true;
            }
            else {
                _this.showImageOne = false;
            }
            if (_this.taskList[1] != null) {
                _this.showImageTwo = true;
            }
            else {
                _this.showImageTwo = false;
            }
            console.log(_this.currentImage.selectedTaskId);
            for (var i in _this.taskList) {
                console.log(i);
                if (_this.taskList[i].id == _this.currentImage.selectedTaskId) {
                    _this.selectedImage = (Number(i) + 1) + '';
                    console.log('selected image index is: ' + _this.selectedImage);
                    break;
                }
                else {
                    _this.selectedImage = null;
                }
            }
            _this.onLoadImage();
        }, function (error) {
        });
    };
    AssignmentReviewComponent.prototype.setCurrentPatient = function () {
        var _this = this;
        this.imageService.getPickedImageListByAssignmentAndPatient(this.assignmentId, this.currentPatient.id).subscribe(function (res) {
            _this.imageList = res.json();
        }, function (error) {
            console.log(error);
        });
    };
    AssignmentReviewComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.helperService.sideMenuStatus$.subscribe(function (open) {
            _this._opened = open;
        });
        this.patientService.getPatientsByAssignment(this.assignmentId).subscribe(function (res) {
            _this.patientList = res.json();
            var i;
            for (i in _this.patientList) {
                if (_this.patientList[i].id == _this.patientId) {
                    _this.currentPatient = _this.patientList[i];
                    break;
                }
            }
        }, function (error) {
            console.log(error);
        });
        this.imageObj1 = new Image();
        // this.imageObj1.src = "assets/images/getstarted.jpg";
        this.imageWidth1 = 650;
        this.imageHeight1 = 555;
        this.imageObj2 = new Image();
        // this.imageObj2.src = "assets/images/getstarted.jpg";
        this.imageWidth2 = 650;
        this.imageHeight2 = 555;
        this.imageObj3 = new Image();
        // this.imageObj3.src = "assets/images/getstarted.jpg";
        this.imageWidth3 = 370;
        this.imageHeight3 = 300;
        this.imageObj4 = new Image();
        // this.imageObj4.src = "assets/images/getstarted.jpg";
        this.imageWidth4 = 370;
        this.imageHeight4 = 300;
        this.imageConfig1 = Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])({
            x: 0,
            y: 0,
            image: this.imageObj1,
            width: this.imageWidth1,
            height: this.imageHeight1
        });
        this.configStage1 = Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])({
            container: 'canvas',
            x: 0,
            y: 0,
            width: this.imageWidth1,
            height: this.imageHeight1
        });
        this.imageConfig2 = Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])({
            x: 0,
            y: 0,
            image: this.imageObj2,
            width: this.imageWidth2,
            height: this.imageHeight2
        });
        this.configStage2 = Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])({
            container: 'canvas',
            x: 0,
            y: 0,
            width: this.imageWidth2,
            height: this.imageHeight2
        });
        this.imageConfig3 = Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])({
            x: 0,
            y: 0,
            image: this.imageObj3,
            width: this.imageWidth3,
            height: this.imageHeight3
        });
        this.configStage3 = Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])({
            container: 'canvas',
            x: 0,
            y: 0,
            width: this.imageWidth3,
            height: this.imageHeight3
        });
        this.imageConfig4 = Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])({
            x: 0,
            y: 0,
            image: this.imageObj4,
            width: this.imageWidth4,
            height: this.imageHeight4
        });
        this.configStage4 = Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])({
            container: 'canvas',
            x: 0,
            y: 0,
            width: this.imageWidth4,
            height: this.imageHeight4
        });
        for (var i = 0; i < 100; i++) {
            this.rectConfigList1.push(new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"]({
                x: 0,
                y: 0,
                width: 0,
                height: 0,
                fill: 'transparent',
                stroke: 'red',
                strokeWidth: 2
            }));
            this.rectConfigList2.push(new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"]({
                x: 0,
                y: 0,
                width: 0,
                height: 0,
                fill: 'transparent',
                stroke: 'red',
                strokeWidth: 2
            }));
            this.rectConfigList3.push(new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"]({
                x: 0,
                y: 0,
                width: 0,
                height: 0,
                fill: 'transparent',
                stroke: 'red',
                strokeWidth: 2
            }));
            this.rectConfigList4.push(new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"]({
                x: 0,
                y: 0,
                width: 0,
                height: 0,
                fill: 'transparent',
                stroke: 'red',
                strokeWidth: 2
            }));
        }
        for (var i = 0; i < 100; i++) {
            this.dotConfigList1.push(new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"]({
                x: 0,
                y: 0,
                radius: 0,
                fill: '#00FF00',
                stroke: 'yellow',
                strokeWidth: 2,
                strokeEnabled: false
            }));
            this.dotConfigList2.push(new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"]({
                x: 0,
                y: 0,
                radius: 0,
                fill: '#00FF00',
                stroke: 'yellow',
                strokeWidth: 2,
                strokeEnabled: false
            }));
            this.dotConfigList3.push(new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"]({
                x: 0,
                y: 0,
                radius: 0,
                fill: '#00FF00',
                stroke: 'yellow',
                strokeWidth: 2,
                strokeEnabled: false
            }));
            this.dotConfigList4.push(new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"]({
                x: 0,
                y: 0,
                radius: 0,
                fill: '#00FF00',
                stroke: 'yellow',
                strokeWidth: 2,
                strokeEnabled: false
            }));
        }
        // this.assignmentService.getImageListByAssignment(this.assignmentId).subscribe(
        //   res => {
        //     console.log(res.json());
        //     this.imageList = res.json();
        //   },
        //   error => {
        //     console.log(error);
        //   }
        // );
    };
    AssignmentReviewComponent.prototype.onModifyImage1 = function () {
        console.log(this.taskList[0]);
        var taskId = this.taskList[0].id;
        this.router.navigate(['/annotationModification/' + taskId], { queryParams: { assignmentId: this.assignmentId, patientId: this.currentPatient.id } });
    };
    AssignmentReviewComponent.prototype.onModifyImage2 = function () {
        var taskId = this.taskList[1].id;
        this.router.navigate(['/annotationModification/' + taskId], { queryParams: { assignmentId: this.assignmentId, patientId: this.currentPatient.id } });
    };
    AssignmentReviewComponent.prototype.onModifyImage3 = function () {
        var taskId = this.taskList[2].id;
        this.router.navigate(['/annotationModification/' + taskId], { queryParams: { assignmentId: this.assignmentId } });
    };
    AssignmentReviewComponent.prototype.onModifyImage4 = function () {
        var taskId = this.taskList[3].id;
        this.router.navigate(['/annotationModification/' + taskId], { queryParams: { assignmentId: this.assignmentId } });
    };
    AssignmentReviewComponent.prototype.onSelectImage = function (image) {
        this.currentImage = image;
        this.helperService.tempImageIndex = this.imageList.indexOf(image);
        this.helperService.tempItemsPerPage = this.config.itemsPerPage;
        this.helperService.tempCurrentPage = this.config.currentPage;
        this.getTaskListByAssignmentAndImage(this.assignmentId, image.id);
        this.checkPage();
    };
    AssignmentReviewComponent.prototype.checkPage = function () {
        var size = this.imageList.length;
        var items = this.config.itemsPerPage;
        var totalPages = size / items;
        var i = this.imageList.indexOf(this.currentImage);
        var currentPage = Math.ceil((i + 1) / items);
        if (this.config.currentPage != currentPage) {
            this.config.currentPage = currentPage;
        }
    };
    AssignmentReviewComponent.prototype.onLoadImage = function () {
        //clear up data
        for (var i = 0; i < 100; i++) {
            this.rectConfigList1[i].next({
                x: 0,
                y: 0,
                width: 0,
                height: 0,
                fill: 'transparent',
                stroke: 'red',
                strokeWidth: 2
            });
            this.rectConfigList2[i].next({
                x: 0,
                y: 0,
                width: 0,
                height: 0,
                fill: 'transparent',
                stroke: 'red',
                strokeWidth: 2
            });
            this.rectConfigList3[i].next({
                x: 0,
                y: 0,
                width: 0,
                height: 0,
                fill: 'transparent',
                stroke: 'red',
                strokeWidth: 2
            });
            this.rectConfigList4[i].next({
                x: 0,
                y: 0,
                width: 0,
                height: 0,
                fill: 'transparent',
                stroke: 'red',
                strokeWidth: 2
            });
        }
        for (var i = 0; i < 100; i++) {
            this.dotConfigList1[i].next({
                x: 0,
                y: 0,
                radius: 0,
                fill: '#00FF00',
                stroke: 'yellow',
                strokeWidth: 2,
                strokeEnabled: false
            });
            this.dotConfigList2[i].next({
                x: 0,
                y: 0,
                radius: 0,
                fill: '#00FF00',
                stroke: 'yellow',
                strokeWidth: 2,
                strokeEnabled: false
            });
            this.dotConfigList3[i].next({
                x: 0,
                y: 0,
                radius: 0,
                fill: '#00FF00',
                stroke: 'yellow',
                strokeWidth: 2,
                strokeEnabled: false
            });
            this.dotConfigList4[i].next({
                x: 0,
                y: 0,
                radius: 0,
                fill: '#00FF00',
                stroke: 'yellow',
                strokeWidth: 2,
                strokeEnabled: false
            });
        }
        this.rectAnnotationList1 = [];
        this.dotAnnotationList1 = [];
        this.dotDescriptionList1 = [];
        this.rectDescriptionList1 = [];
        this.rectAnnotationList2 = [];
        this.dotAnnotationList2 = [];
        this.dotDescriptionList2 = [];
        this.rectDescriptionList2 = [];
        this.rectAnnotationList3 = [];
        this.dotAnnotationList3 = [];
        this.dotDescriptionList3 = [];
        this.rectDescriptionList3 = [];
        this.rectAnnotationList4 = [];
        this.dotAnnotationList4 = [];
        this.dotDescriptionList4 = [];
        this.rectDescriptionList4 = [];
        this.rectIndex = 0;
        this.dotIndex = 0;
        //prepare references for functional callback usage
        var stageRef1 = this.stage1;
        var imageLayerRef1 = this.imageLayer1;
        var imageRef1 = this.image1;
        var imageObjRef1 = this.imageObj1;
        var annotationWidthRef1 = 650;
        var imageConfigRef1 = {};
        var configStageRef1 = {};
        var stageRef2 = this.stage2;
        var imageLayerRef2 = this.imageLayer2;
        var imageRef2 = this.image2;
        var imageObjRef2 = this.imageObj2;
        var annotationWidthRef2 = 650;
        var imageConfigRef2 = {};
        var configStageRef2 = {};
        // let stageRef3 = this.stage3;
        // let imageLayerRef3 = this.imageLayer3;
        // let imageRef3 = this.image3;
        // let imageObjRef3 = this.imageObj3;
        // let annotationWidthRef3 = 450;
        // let imageConfigRef3 = {};
        // let configStageRef3 = {};
        // let stageRef4 = this.stage4;
        // let imageLayerRef4 = this.imageLayer4;
        // let imageRef4 = this.image4;
        // let imageObjRef4 = this.imageObj4;
        // let annotationWidthRef4 = 450;
        // let imageConfigRef4 = {};
        // let configStageRef4 = {};
        var that = this;
        this.imageConfig1 = imageConfigRef1;
        this.configStage1 = configStageRef1;
        this.imageConfig2 = imageConfigRef2;
        this.configStage2 = configStageRef2;
        // this.imageConfig3 = imageConfigRef3;
        // this.configStage3 = configStageRef3;
        // this.imageConfig4 = imageConfigRef4;
        // this.configStage4 = configStageRef4;
        console.log(this.taskList);
        var url = this.serverPath + '/image/getImage/' + this.taskList[0].imageItem.folderPath;
        if (that.taskList[0] != null) {
            this.imageObj1.src = url;
        }
        if (that.taskList[1] != null) {
            this.imageObj2.src = url;
        }
        if (that.taskList[2] != null) {
            this.imageObj3.src = url;
        }
        if (that.taskList[3] != null) {
            this.imageObj4.src = url;
        }
        var image1 = new Image();
        image1.src = url;
        image1.onload = function () {
            var w = image1.width;
            var h = image1.height;
            console.log(w, h);
            var stageHeight = 600;
            var scaleY = stageHeight / h;
            var stageWidth = w / h * stageHeight;
            if (stageWidth > annotationWidthRef1) {
                stageWidth = annotationWidthRef1;
                stageHeight = stageWidth * h / w;
                scaleY = stageHeight / h;
            }
            else {
                stageWidth = w / h * stageHeight;
            }
            var scaleX = stageWidth / w;
            that.scaleX = scaleX;
            that.scaleY = scaleY;
            imageRef1.getStage().height(stageHeight);
            imageRef1.getStage().width(stageWidth);
            imageLayerRef1.getStage().draw();
            stageRef1.getStage().width(stageWidth);
            stageRef1.getStage().height(stageHeight);
            stageRef1.getStage().draw();
            imageRef2.getStage().height(stageHeight);
            imageRef2.getStage().width(stageWidth);
            imageLayerRef2.getStage().draw();
            stageRef2.getStage().width(stageWidth);
            stageRef2.getStage().height(stageHeight);
            stageRef2.getStage().draw();
            // imageRef3.getStage().height(stageHeight);
            // imageRef3.getStage().width(stageWidth);
            // imageLayerRef3.getStage().draw();
            // stageRef3.getStage().width(stageWidth);
            // stageRef3.getStage().height(stageHeight);
            // stageRef3.getStage().draw();
            // imageRef4.getStage().height(stageHeight);
            // imageRef4.getStage().width(stageWidth);
            // imageLayerRef4.getStage().draw();
            // stageRef4.getStage().width(stageWidth);
            // stageRef4.getStage().height(stageHeight);
            // stageRef4.getStage().draw();
            if (that.taskList[0] != null) {
                that.getAnnotation1(scaleX, scaleY);
            }
            if (that.taskList[1] != null) {
                that.getAnnotation2(scaleX, scaleY);
            }
            if (that.taskList[2] != null) {
                that.getAnnotation3(scaleX, scaleY);
            }
            if (that.taskList[3] != null) {
                that.getAnnotation4(scaleX, scaleY);
            }
        };
    };
    AssignmentReviewComponent.prototype.getAnnotation1 = function (scaleX, scaleY) {
        var _this = this;
        //get annotation for current image
        this.imageService.getAnnotationByTask(this.taskList[0].id).subscribe(function (res) {
            var currentAnnotationMapper = res.json();
            var currentDotList = currentAnnotationMapper['dotList'];
            var currentRectList = currentAnnotationMapper['rectList'];
            var currentState = currentAnnotationMapper['state'];
            for (var i = 0; i < currentDotList.length; i++) {
                _this.dotConfigList1[i].next({
                    x: currentDotList[i]['offsetX'] * scaleX,
                    y: currentDotList[i]['offsetY'] * scaleY,
                    radius: 2,
                    fill: '#00FF00',
                    stroke: 'yellow',
                    strokeWidth: 2,
                    strokeEnabled: false,
                    name: 'dot' + i
                });
                _this.dotAnnotationList1[_this.dotIndex] = [currentDotList[i]['offsetX'] + '', currentDotList[i]['offsetY'] + ''];
                _this.dotDescriptionList1[i] = currentDotList[i]['description'];
                _this.dotIndex += 1;
            }
            for (var i = 0; i < currentRectList.length; i++) {
                _this.rectConfigList1[i].next({
                    x: currentRectList[i]['offsetX'] * scaleX,
                    y: currentRectList[i]['offsetY'] * scaleY,
                    width: currentRectList[i]['offsetWidth'] * scaleX,
                    height: currentRectList[i]['offsetHeight'] * scaleY,
                    fill: 'transparent',
                    stroke: 'red',
                    strokeWidth: 2,
                    name: 'rect' + i
                });
                _this.rectAnnotationList1[_this.rectIndex] = [currentRectList[i]['offsetX'] + '', currentRectList[i]['offsetY'] + '', currentRectList[i]['offsetWidth'] + '', currentRectList[i]['offsetHeight'] + ''];
                _this.rectDescriptionList1[i] = currentRectList[i]['description'];
                _this.rectIndex += 1;
            }
            if (currentState != null) {
                _this.status = currentState.status;
            }
        }, function (error) {
            console.log(error);
        });
    };
    AssignmentReviewComponent.prototype.getAnnotation2 = function (scaleX, scaleY) {
        var _this = this;
        this.dotIndex = 0;
        this.rectIndex = 0;
        //get annotation for current image
        this.imageService.getAnnotationByTask(this.taskList[1].id).subscribe(function (res) {
            var currentAnnotationMapper = res.json();
            var currentDotList = currentAnnotationMapper['dotList'];
            var currentRectList = currentAnnotationMapper['rectList'];
            var currentState = currentAnnotationMapper['state'];
            for (var i = 0; i < currentDotList.length; i++) {
                _this.dotConfigList2[i].next({
                    x: currentDotList[i]['offsetX'] * scaleX,
                    y: currentDotList[i]['offsetY'] * scaleY,
                    radius: 2,
                    fill: '#00FF00',
                    stroke: 'yellow',
                    strokeWidth: 2,
                    strokeEnabled: false,
                    name: 'dot' + i
                });
                _this.dotAnnotationList2[_this.dotIndex] = [currentDotList[i]['offsetX'] + '', currentDotList[i]['offsetY'] + ''];
                _this.dotDescriptionList2[i] = currentDotList[i]['description'];
                _this.dotIndex += 1;
            }
            for (var i = 0; i < currentRectList.length; i++) {
                _this.rectConfigList2[i].next({
                    x: currentRectList[i]['offsetX'] * scaleX,
                    y: currentRectList[i]['offsetY'] * scaleY,
                    width: currentRectList[i]['offsetWidth'] * scaleX,
                    height: currentRectList[i]['offsetHeight'] * scaleY,
                    fill: 'transparent',
                    stroke: 'red',
                    strokeWidth: 2,
                    name: 'rect' + i
                });
                _this.rectAnnotationList2[_this.rectIndex] = [currentRectList[i]['offsetX'] + '', currentRectList[i]['offsetY'] + '', currentRectList[i]['offsetWidth'] + '', currentRectList[i]['offsetHeight'] + ''];
                _this.rectDescriptionList2[i] = currentRectList[i]['description'];
                _this.rectIndex += 1;
            }
            if (currentState != null) {
                _this.status = currentState.status;
            }
        }, function (error) {
            console.log(error);
        });
    };
    AssignmentReviewComponent.prototype.getAnnotation3 = function (scaleX, scaleY) {
        var _this = this;
        this.dotIndex = 0;
        this.rectIndex = 0;
        //get annotation for current image
        this.imageService.getAnnotationByTask(this.taskList[2].id).subscribe(function (res) {
            var currentAnnotationMapper = res.json();
            var currentDotList = currentAnnotationMapper['dotList'];
            var currentRectList = currentAnnotationMapper['rectList'];
            var currentState = currentAnnotationMapper['state'];
            for (var i = 0; i < currentDotList.length; i++) {
                _this.dotConfigList3[i].next({
                    x: currentDotList[i]['offsetX'] * scaleX,
                    y: currentDotList[i]['offsetY'] * scaleY,
                    radius: 2,
                    fill: '#00FF00',
                    stroke: 'yellow',
                    strokeEnabled: false,
                    strokeWidth: 2,
                    name: 'dot' + i
                });
                _this.dotAnnotationList3[_this.dotIndex] = [currentDotList[i]['offsetX'] + '', currentDotList[i]['offsetY'] + ''];
                _this.dotDescriptionList3[i] = currentDotList[i]['description'];
                _this.dotIndex += 1;
            }
            for (var i = 0; i < currentRectList.length; i++) {
                _this.rectConfigList3[i].next({
                    x: currentRectList[i]['offsetX'] * scaleX,
                    y: currentRectList[i]['offsetY'] * scaleY,
                    width: currentRectList[i]['offsetWidth'] * scaleX,
                    height: currentRectList[i]['offsetHeight'] * scaleY,
                    fill: 'transparent',
                    stroke: 'red',
                    strokeWidth: 2,
                    name: 'rect' + i
                });
                _this.rectAnnotationList3[_this.rectIndex] = [currentRectList[i]['offsetX'] + '', currentRectList[i]['offsetY'] + '', currentRectList[i]['offsetWidth'] + '', currentRectList[i]['offsetHeight'] + ''];
                _this.rectDescriptionList3[i] = currentRectList[i]['description'];
                _this.rectIndex += 1;
            }
            if (currentState != null) {
                _this.status = currentState.status;
            }
        }, function (error) {
            console.log(error);
        });
    };
    AssignmentReviewComponent.prototype.getAnnotation4 = function (scaleX, scaleY) {
        var _this = this;
        this.dotIndex = 0;
        this.rectIndex = 0;
        //get annotation for current image
        this.imageService.getAnnotationByTask(this.taskList[3].id).subscribe(function (res) {
            var currentAnnotationMapper = res.json();
            var currentDotList = currentAnnotationMapper['dotList'];
            var currentRectList = currentAnnotationMapper['rectList'];
            var currentState = currentAnnotationMapper['state'];
            for (var i = 0; i < currentDotList.length; i++) {
                _this.dotConfigList4[i].next({
                    x: currentDotList[i]['offsetX'] * scaleX,
                    y: currentDotList[i]['offsetY'] * scaleY,
                    radius: 2,
                    fill: '#00FF00',
                    stroke: 'yellow',
                    strokeWidth: 2,
                    strokeEnabled: false,
                    name: 'dot' + i
                });
                _this.dotAnnotationList4[_this.dotIndex] = [currentDotList[i]['offsetX'] + '', currentDotList[i]['offsetY'] + ''];
                _this.dotDescriptionList4[i] = currentDotList[i]['description'];
                _this.dotIndex += 1;
            }
            for (var i = 0; i < currentRectList.length; i++) {
                _this.rectConfigList4[i].next({
                    x: currentRectList[i]['offsetX'] * scaleX,
                    y: currentRectList[i]['offsetY'] * scaleY,
                    width: currentRectList[i]['offsetWidth'] * scaleX,
                    height: currentRectList[i]['offsetHeight'] * scaleY,
                    fill: 'transparent',
                    stroke: 'red',
                    strokeWidth: 2,
                    name: 'rect' + i
                });
                _this.rectAnnotationList4[_this.rectIndex] = [currentRectList[i]['offsetX'] + '', currentRectList[i]['offsetY'] + '', currentRectList[i]['offsetWidth'] + '', currentRectList[i]['offsetHeight'] + ''];
                _this.rectDescriptionList4[i] = currentRectList[i]['description'];
                _this.rectIndex += 1;
            }
            if (currentState != null) {
                _this.status = currentState.status;
            }
        }, function (error) {
            console.log(error);
        });
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('stage1'),
        __metadata("design:type", Object)
    ], AssignmentReviewComponent.prototype, "stage1", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('image1'),
        __metadata("design:type", Object)
    ], AssignmentReviewComponent.prototype, "image1", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('imageLayer1'),
        __metadata("design:type", Object)
    ], AssignmentReviewComponent.prototype, "imageLayer1", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('stage2'),
        __metadata("design:type", Object)
    ], AssignmentReviewComponent.prototype, "stage2", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('image2'),
        __metadata("design:type", Object)
    ], AssignmentReviewComponent.prototype, "image2", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('imageLayer2'),
        __metadata("design:type", Object)
    ], AssignmentReviewComponent.prototype, "imageLayer2", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('stage3'),
        __metadata("design:type", Object)
    ], AssignmentReviewComponent.prototype, "stage3", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('image3'),
        __metadata("design:type", Object)
    ], AssignmentReviewComponent.prototype, "image3", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('imageLayer3'),
        __metadata("design:type", Object)
    ], AssignmentReviewComponent.prototype, "imageLayer3", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('stage4'),
        __metadata("design:type", Object)
    ], AssignmentReviewComponent.prototype, "stage4", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('image4'),
        __metadata("design:type", Object)
    ], AssignmentReviewComponent.prototype, "image4", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('imageLayer4'),
        __metadata("design:type", Object)
    ], AssignmentReviewComponent.prototype, "imageLayer4", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('scroll1'),
        __metadata("design:type", ngx_perfect_scrollbar__WEBPACK_IMPORTED_MODULE_10__["PerfectScrollbarComponent"])
    ], AssignmentReviewComponent.prototype, "scroll1", void 0);
    AssignmentReviewComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-assignment-review',
            template: __webpack_require__(/*! ./assignment-review.component.html */ "./src/app/components/assignment-review/assignment-review.component.html"),
            styles: [__webpack_require__(/*! ./assignment-review.component.css */ "./src/app/components/assignment-review/assignment-review.component.css")]
        }),
        __metadata("design:paramtypes", [_services_image_service_image_service__WEBPACK_IMPORTED_MODULE_4__["ImageService"],
            _services_task_service_task_service__WEBPACK_IMPORTED_MODULE_5__["TaskService"],
            _services_assignment_service_assignment_service__WEBPACK_IMPORTED_MODULE_7__["AssignmentService"],
            _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_6__["HelperService"],
            _services_patient_service_patient_service__WEBPACK_IMPORTED_MODULE_8__["PatientService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
            angular2_notifications__WEBPACK_IMPORTED_MODULE_9__["NotificationsService"],
            angular2_hotkeys__WEBPACK_IMPORTED_MODULE_11__["HotkeysService"]])
    ], AssignmentReviewComponent);
    return AssignmentReviewComponent;
}());



/***/ }),

/***/ "./src/app/components/create-assignment/create-assignment.component.css":
/*!******************************************************************************!*\
  !*** ./src/app/components/create-assignment/create-assignment.component.css ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".inner-container{\n    margin: 20px 20px 20px 20px;\n}"

/***/ }),

/***/ "./src/app/components/create-assignment/create-assignment.component.html":
/*!*******************************************************************************!*\
  !*** ./src/app/components/create-assignment/create-assignment.component.html ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div *ngIf=\"!loading\">\n  <app-navbar></app-navbar>\n\n  <!-- Container for sidebar(s) + page content -->\n  <ng-sidebar-container style=\"height: 800px;\">\n    <!-- A sidebar -->\n    <ng-sidebar [(opened)]=\"_opened\">\n      <app-side-panel></app-side-panel>\n    </ng-sidebar>\n\n    <!-- Page content -->\n    <div ng-sidebar-content>\n      <div class=\"main\" style=\"margin:auto; margin-top: 50px; width: 90%\">\n        <h4>Create An Assignment</h4>\n        <br>\n        <form>\n          <div class=\"row\">\n            <div class=\"col-5\" style=\"border:1px solid black;\">\n              <div class=\"inner-container\">\n                <div class=\"form-group\">\n                  <label for=\"name\">Name</label>\n                  <input type=\"text\" class=\"form-control\" id=\"name\" aria-describedby=\"emailHelp\" placeholder=\"Enter assignment name here\" name=\"name\"\n                    [(ngModel)]=\"assignment.name\" required>\n                </div>\n                <div class=\"form-group\">\n                  <label for=\"type\">Assignment Type</label>\n                  <select class=\"custom-select\" [(ngModel)]=\"assignment.type\" name=\"type\" id=\"type\">\n                    <option [ngValue]=0>Dot</option>\n                    <option [ngValue]=1>Rect</option>\n                    <option [ngValue]=2>State</option>\n                    <option [ngValue]=3>Segment</option>\n                  </select>\n                </div>\n                <div class=\"form-group\">\n                  <label for=\"user1\">Labeling User 1</label>\n                  <select class=\"custom-select\" [(ngModel)]=\"assignment.userList[0]\" id=\"user1\" name=\"user1\" (change)=\"onRefreshUserSelection()\">\n                    <option [ngValue]=null>N/A</option>\n                    <option *ngFor=\"let user of currentUserList\" [ngValue]=\"user\">{{user.lastName}}, {{user.firstName}}</option>\n                  </select>\n                </div>\n                <div class=\"form-group\">\n                  <label for=\"user2\">Labeling User 2</label>\n                  <select class=\"custom-select\" [(ngModel)]=\"assignment.userList[1]\" id=\"user2\" name=\"user2\" (change)=\"onRefreshUserSelection()\">\n                    <option [ngValue]=null>N/A</option>\n                    <option *ngFor=\"let user of currentUserList\" [ngValue]=\"user\">{{user.lastName}}, {{user.firstName}}</option>\n                  </select>\n                </div>\n                <!-- <div class=\"form-group\">\n                  <label for=\"label3\">Labeling User 3</label>\n                  <select class=\"custom-select\" [(ngModel)]=\"assignment.userList[2]\" name=\"user3\" (change)=\"onRefreshUserSelection()\">\n                    <option [ngValue]=null>N/A</option>\n                    <option *ngFor=\"let user of currentUserList\" [ngValue]=\"user\">{{user.lastName}}, {{user.firstName}}</option>\n                  </select>\n                </div>\n                <div class=\"form-group\">\n                  <label for=\"label4\">Labeling User 4</label>\n                  <select class=\"custom-select\" [(ngModel)]=\"assignment.userList[3]\" name=\"user4\" (change)=\"onRefreshUserSelection()\">\n                    <option [ngValue]=null>N/A</option>\n                    <option *ngFor=\"let user of currentUserList\" [ngValue]=\"user\">{{user.lastName}}, {{user.firstName}}</option>\n                  </select>\n                </div> -->\n              </div>\n            </div>\n            <div class=\"col-3\" style=\"border:1px solid black;\">\n              <div class=\"inner-container\">\n                <h6>Add Tags</h6>\n                <tag-input [(ngModel)]='assignment.tagList' name=\"tagList\"></tag-input>\n              </div>\n            </div>\n            <div class=\"col-4\" style=\"border:1px solid black;\">\n              <div class=\"inner-container\">\n                <h6>Start Date</h6>\n                <form class=\"form-inline\">\n                  <div class=\"form-group\">\n                    <div class=\"input-group\">\n                      <input class=\"form-control\" placeholder=\"yyyy-mm-dd\" name=\"dp\" [(ngModel)]=\"startDate\" ngbDatepicker #d1=\"ngbDatepicker\">\n                      <div class=\"input-group-append\">\n                        <button class=\"btn btn-outline-secondary\" (click)=\"d1.toggle()\" type=\"button\">\n                          <i class=\"fa fa-calendar\"></i>\n                        </button>\n                      </div>\n                    </div>\n                  </div>\n                </form>\n                <hr>\n                <br>\n                <h6>End Date</h6>\n                <form class=\"form-inline\">\n                  <div class=\"form-group\">\n                    <div class=\"input-group\">\n                      <input class=\"form-control\" placeholder=\"yyyy-mm-dd\" name=\"dp\" [(ngModel)]=\"endDate\" ngbDatepicker #d2=\"ngbDatepicker\">\n                      <div class=\"input-group-append\">\n                        <button class=\"btn btn-outline-secondary\" (click)=\"d2.toggle()\" type=\"button\">\n                          <i class=\"fa fa-calendar\"></i>\n                        </button>\n                      </div>\n                    </div>\n                  </div>\n                </form>\n              </div>\n            </div>\n          </div>\n          <br>\n          <div *ngIf=\"duplicateUser\" class=\"alert alert-danger\" role=\"alert\">\n            Oops. You can't have duplicate labeling user.\n          </div>\n          <div *ngIf=\"emptyStartDate\" class=\"alert alert-danger\" role=\"alert\">\n            Oops. Start Date can't be empty.\n          </div>\n          <div *ngIf=\"emptyEndDate\" class=\"alert alert-danger\" role=\"alert\">\n            Oops. End Date can't be empty.\n          </div>\n          <div *ngIf=\"assignmentCreated\" class=\"alert alert-success\" role=\"alert\">\n            Assignment created.\n          </div>\n          <button class=\"btn btn-outline-dark\" (click)=\"onCreateAssignment()\">Create</button>\n        </form>\n      </div>\n    </div>\n  </ng-sidebar-container>\n\n</div>\n<div *ngIf=\"loading\" class=\"text-center\" style=\"margin:150px 200px 0 200px\">\n  <i class=\"fa fa-spinner fa-5x faa-spin animated\"></i>\n</div>\n"

/***/ }),

/***/ "./src/app/components/create-assignment/create-assignment.component.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/components/create-assignment/create-assignment.component.ts ***!
  \*****************************************************************************/
/*! exports provided: CreateAssignmentComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateAssignmentComponent", function() { return CreateAssignmentComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _app_const__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../app-const */ "./src/app/app-const.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/helper-service/helper.service */ "./src/app/services/helper-service/helper.service.ts");
/* harmony import */ var _services_user_service_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/user-service/user.service */ "./src/app/services/user-service/user.service.ts");
/* harmony import */ var _services_assignment_service_assignment_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/assignment-service/assignment.service */ "./src/app/services/assignment-service/assignment.service.ts");
/* harmony import */ var _models_assignment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../models/assignment */ "./src/app/models/assignment.ts");
/* harmony import */ var ng2_file_upload_ng2_file_upload__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ng2-file-upload/ng2-file-upload */ "./node_modules/ng2-file-upload/ng2-file-upload.js");
/* harmony import */ var ng2_file_upload_ng2_file_upload__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(ng2_file_upload_ng2_file_upload__WEBPACK_IMPORTED_MODULE_7__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};








var URL = 'http://140.143.15.26:8181/longwood-be/image/upload';
// const URL = 'http://localhost:8181/longwood-be/image/upload';
// const URL = 'http://192.144.132.111:8181/longwood-be/image/upload';
var CreateAssignmentComponent = /** @class */ (function () {
    function CreateAssignmentComponent(helperService, assignmentService, userService, router) {
        this.helperService = helperService;
        this.assignmentService = assignmentService;
        this.userService = userService;
        this.router = router;
        this.uploader = new ng2_file_upload_ng2_file_upload__WEBPACK_IMPORTED_MODULE_7__["FileUploader"]({ url: URL });
        this.duplicateUser = false;
        this.emptyStartDate = false;
        this.emptyEndDate = false;
        this.assignmentCreated = false;
        this.fileUploaded = false;
        this.fileUploading = false;
        this.currentUserList = [];
        this.serverPath = _app_const__WEBPACK_IMPORTED_MODULE_1__["AppConst"].serverPath;
        this._opened = false;
        this.assignment = new _models_assignment__WEBPACK_IMPORTED_MODULE_6__["Assignment"]();
    }
    CreateAssignmentComponent.prototype._toggleSidebar = function () {
        this._opened = !this._opened;
    };
    CreateAssignmentComponent.prototype.onUploadAll = function () {
        this.fileUploading = true;
        this.uploader.uploadAll();
    };
    CreateAssignmentComponent.prototype.onCreateAssignment = function () {
        var _this = this;
        console.log('on create asssignment');
        this.onCheckDuplicateUser();
        if (this.startDate == null) {
            this.emptyStartDate = true;
            var that_1 = this;
            setTimeout(function () {
                that_1.emptyStartDate = false;
            }.bind(this), 5000);
        }
        else if (this.endDate == null) {
            this.emptyEndDate = true;
            var that_2 = this;
            setTimeout(function () {
                that_2.emptyEndDate = false;
            }.bind(this), 5000);
        }
        else if (!this.duplicateUser) {
            this.assignment.startDate = this.startDate.month + '-' + this.startDate.day + '-' + this.startDate.year;
            this.assignment.endDate = this.endDate.month + '-' + this.endDate.day + '-' + this.endDate.year;
            this.assignmentService.createAssignment(this.assignment).subscribe(function (res) {
                console.log(res.text());
                _this.assignmentCreated = true;
                var that = _this;
                setTimeout(function () {
                    that.assignmentCreated = false;
                }.bind(_this), 5000);
                var id = res.json().id;
                _this.router.navigate(['/selectFile', id]);
            }, function (error) {
                console.log(error);
            });
        }
    };
    CreateAssignmentComponent.prototype.onGetUserList = function () {
        var _this = this;
        this.userService.getUserList().subscribe(function (res) {
            _this.currentUserList = res.json();
        }, function (error) {
            console.log(error);
        });
    };
    CreateAssignmentComponent.prototype.onRefreshUserSelection = function () {
        this.duplicateUser = false;
        var that = this;
        setTimeout(function () {
            that.duplicateUser = false;
        }.bind(this), 5000);
    };
    CreateAssignmentComponent.prototype.onCheckDuplicateUser = function () {
        var user1 = this.assignment.userList[0];
        var user2 = this.assignment.userList[1];
        var user3 = this.assignment.userList[2];
        var user4 = this.assignment.userList[3];
        if (user1 != null) {
            if (user2 != null && user1.id == user2.id) {
                this.duplicateUser = true;
            }
            if (user3 != null && user1.id == user3.id) {
                this.duplicateUser = true;
            }
            if (user4 != null && user1.id == user4.id) {
                this.duplicateUser = true;
            }
        }
        if (user2 != null) {
            if (user3 != null && user2.id == user3.id) {
                this.duplicateUser = true;
            }
            if (user4 != null && user2.id == user4.id) {
                this.duplicateUser = true;
            }
        }
        if (user3 != null) {
            if (user4 != null && user4.id == user3.id) {
                this.duplicateUser = true;
            }
        }
    };
    CreateAssignmentComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.assignment.userList = [null, null, null, null];
        this.assignment.tagList = ['Default'];
        this.assignment.type = 0;
        this.helperService.sideMenuStatus$.subscribe(function (open) {
            _this._opened = open;
        });
        this.onGetUserList();
    };
    CreateAssignmentComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-create-assignment',
            template: __webpack_require__(/*! ./create-assignment.component.html */ "./src/app/components/create-assignment/create-assignment.component.html"),
            styles: [__webpack_require__(/*! ./create-assignment.component.css */ "./src/app/components/create-assignment/create-assignment.component.css")]
        }),
        __metadata("design:paramtypes", [_services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_3__["HelperService"], _services_assignment_service_assignment_service__WEBPACK_IMPORTED_MODULE_5__["AssignmentService"], _services_user_service_user_service__WEBPACK_IMPORTED_MODULE_4__["UserService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], CreateAssignmentComponent);
    return CreateAssignmentComponent;
}());



/***/ }),

/***/ "./src/app/components/dashboard/dashboard.component.css":
/*!**************************************************************!*\
  !*** ./src/app/components/dashboard/dashboard.component.css ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/dashboard/dashboard.component.html":
/*!***************************************************************!*\
  !*** ./src/app/components/dashboard/dashboard.component.html ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div>\n  <app-navbar></app-navbar>\n\n  <!-- Container for sidebar(s) + page content -->\n  <ng-sidebar-container style=\"height: 800px;\">\n    <!-- A sidebar -->\n    <ng-sidebar [(opened)]=\"_opened\">\n      <app-side-panel></app-side-panel>\n    </ng-sidebar>\n\n    <!-- Page content -->\n    <div ng-sidebar-content>\n      <div class=\"container\" style=\"margin-top: 50px; \">\n        <div class=\"jumbotron p-2 p-md-4 text-white rounded bg-dark\">\n          <!-- <div class=\"col-md-6 px-0\"> -->\n          <h1 class=\"display-4 font-italic\">Welcome back,\n            <span>{{user?.username}}</span>\n          </h1>\n        </div>\n        <div class=\"row \">\n          <div class=\"col-6\">\n            <div style=\"margin-top: 50px;\">\n              <p>\n                <i>Click on the assignment number to view</i>\n              </p>\n            </div>\n          </div>\n          <div class=\"col-6\" style=\"border:1px solid black\">\n            <div style=\"margin-top: 30px;\">\n              <h4>Total: &nbsp;{{total}} images</h4>\n              <table class=\"table\">\n                <thead class=\"thead-light\">\n                <tr>\n                  <th scope=\"col\">Name</th>\n                  <th scope=\"col\">New</th>\n                  <th scope=\"col\">Changed</th>\n                  <th scope=\"col\">Done</th>\n                  <th scope=\"col\">Sub-total</th>\n                  <th scope=\"col\">Percentage</th>\n                </tr>\n                </thead>\n                <tbody>\n                <tr>\n                  <th scope=\"row\">Dot</th>\n                  <td>{{dotNewNumber}}</td>\n                  <td>{{dotChangedNumber}}</td>\n                  <td>{{dotDoneNumber}}</td>\n                  <td>{{dotNewNumber+dotChangedNumber+dotDoneNumber}}</td>\n                  <td>{{dotDoneNumber/(dotNewNumber+dotChangedNumber+dotDoneNumber) | percent}}</td>\n                </tr>\n                <tr>\n                  <th scope=\"row\">Rect</th>\n                  <td>{{rectNewNumber}}</td>\n                  <td>{{rectChangedNumber}}</td>\n                  <td>{{rectDoneNumber}}</td>\n                  <td>{{rectNewNumber+rectChangedNumber+rectDoneNumber}}</td>\n                  <td>{{rectDoneNumber / (rectNewNumber+rectChangedNumber+rectDoneNumber) | percent}}</td>\n                </tr>\n                </tbody>\n              </table>\n            </div>\n          </div>\n        </div>\n        <br>\n        <h4>Your Assignments</h4>\n        <div class=\"row\">\n          <div class=\"col-12\">\n            <table class=\"table table-hover\">\n              <thead class=\"thead-light\">\n              <tr>\n                <th scope=\"col\">ID</th>\n                <th scope=\"col\">Name</th>\n                <th scope=\"col\">Status</th>\n                <th scope=\"col\">Type</th>\n                <th scope=\"col\">Action</th>\n              </tr>\n              </thead>\n              <div *ngIf=\"busy\" class=\"text-center\" style=\"margin: 100px 0px 0 0px\">\n                <i class=\"fa fa-spinner fa-4x faa-spin animated\"></i>\n              </div>\n              <tbody *ngIf=\"!busy\">\n              <tr *ngFor=\"let itemDub of assignmentItemDubList\">\n                <td><span (click)=\"onClickAssignmentItem(itemDub)\" style=\"cursor: pointer;color: blue;\">{{itemDub.assignmentItemId}}</span>\n                </td>\n                <td>{{itemDub.name}}</td>\n                <td>{{itemDub.status}}</td>\n                <td>{{itemDub.type}}</td>\n                <td *ngIf=\"itemDub.status == 0\">\n                  <button class=\"btn btn-outline-primary btn-sm\" (click)=\"onAcceptItem(itemDub)\">Accept</button>\n                  &nbsp;\n                  <button class=\"btn btn-outline-danger btn-sm\" (click)=\"onDeclineItem(itemDub)\">Decline</button>\n                </td>\n                <td *ngIf=\"itemDub.status == 1\">\n                  <button class=\"btn btn-outline-primary btn-sm\" (click)=\"onSubmitItem(itemDub)\">Submit</button>\n                </td>\n              </tr>\n              </tbody>\n            </table>\n          </div>\n        </div>\n      </div>\n    </div>\n  </ng-sidebar-container>\n</div>\n\n<simple-notifications></simple-notifications>\n"

/***/ }),

/***/ "./src/app/components/dashboard/dashboard.component.ts":
/*!*************************************************************!*\
  !*** ./src/app/components/dashboard/dashboard.component.ts ***!
  \*************************************************************/
/*! exports provided: DashboardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashboardComponent", function() { return DashboardComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _app_const__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../app-const */ "./src/app/app-const.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_login_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/login.service */ "./src/app/services/login.service.ts");
/* harmony import */ var _services_task_service_task_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/task-service/task.service */ "./src/app/services/task-service/task.service.ts");
/* harmony import */ var _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/helper-service/helper.service */ "./src/app/services/helper-service/helper.service.ts");
/* harmony import */ var _services_user_service_user_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../services/user-service/user.service */ "./src/app/services/user-service/user.service.ts");
/* harmony import */ var _services_assignment_service_assignment_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../services/assignment-service/assignment.service */ "./src/app/services/assignment-service/assignment.service.ts");
/* harmony import */ var angular2_notifications__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! angular2-notifications */ "./node_modules/angular2-notifications/angular2-notifications.umd.js");
/* harmony import */ var angular2_notifications__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(angular2_notifications__WEBPACK_IMPORTED_MODULE_8__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};









var DashboardComponent = /** @class */ (function () {
    function DashboardComponent(helperService, taskService, loginService, userService, assignmentService, notificationService, router) {
        this.helperService = helperService;
        this.taskService = taskService;
        this.loginService = loginService;
        this.userService = userService;
        this.assignmentService = assignmentService;
        this.notificationService = notificationService;
        this.router = router;
        this.serverPath = _app_const__WEBPACK_IMPORTED_MODULE_1__["AppConst"].serverPath;
        this._opened = false;
        this.taskList = [];
        this.rectTaskList = [];
        this.dotTaskList = [];
        this.total = 0;
        this.rectNumber = 0;
        this.dotNumber = 0;
        this.rectNewNumber = 0;
        this.rectChangedNumber = 0;
        this.rectDoneNumber = 0;
        this.dotNewNumber = 0;
        this.dotChangedNumber = 0;
        this.dotDoneNumber = 0;
        this.loggedIn = false;
        this.busy = false;
        this.assignmentItemList = [];
        this.assignmentItemDubList = [];
        this.data = [
            {
                'name': 'Dot',
                'value': 0
            },
            {
                'name': 'Rect',
                'value': 0
            },
        ];
        this.view = [320, 200];
        this.colorScheme = {
            domain: ['#659dbd', '#C38D9E', '#41B3A3']
        };
        // options
        this.showLegend = false;
        // pie
        this.showLabels = true;
        this.explodeSlices = false;
        this.doughnut = false;
    }
    DashboardComponent.prototype._toggleSidebar = function () {
        this._opened = !this._opened;
    };
    DashboardComponent.prototype.onSelect = function (event) {
        console.log(event);
        var type;
        if (event.name === 'Rect') {
            type = 1;
        }
        else if (event.name == 'Dot') {
            type = 0;
        }
        this.taskService.onTaskType = type;
        console.log(type);
        console.log(this.taskService.onTaskType);
        this.router.navigate(['/home']);
    };
    DashboardComponent.prototype.onTaskCategory = function (taskList) {
        for (var i in taskList) {
            var type = taskList[i].taskType;
            var status_1 = taskList[i].taskStatus;
            if (type == 0) {
                this.dotTaskList.push(taskList[i]);
                this.data[0].value += 1;
                if (status_1 == 0) {
                    this.dotNewNumber += 1;
                    console.log(this.dotNewNumber);
                }
                else if (status_1 == 1) {
                    this.dotChangedNumber += 1;
                }
                else if (status_1 == 2) {
                    this.dotDoneNumber += 1;
                }
            }
            else if (type == 1) {
                this.rectTaskList.push(taskList[i]);
                this.data[1].value += 1;
                if (status_1 == 0) {
                    this.rectNewNumber += 1;
                }
                else if (status_1 == 1) {
                    this.rectChangedNumber += 1;
                }
                else if (status_1 == 2) {
                    this.rectDoneNumber += 1;
                }
            }
        }
        this.total = this.data[0].value + this.data[1].value;
        this.data[0].value = this.dotDoneNumber + ' / ' + this.data[0].value;
        this.data[1].value = this.rectDoneNumber + ' / ' + this.data[1].value;
        this.data = Array.from(this.data, function (x) { return x; });
    };
    DashboardComponent.prototype.onCheckSession = function () {
        var _this = this;
        this.loginService.checkSession().subscribe(function (res) {
            _this.user = res.json();
        }, function (error) {
            console.log(error);
        });
    };
    DashboardComponent.prototype.onAcceptItem = function (itemDub) {
        this.busy = true;
        this.assignmentService.acceptAssignmentItem(itemDub.assignmentItemId).subscribe(function (res) {
            location.reload();
        }, function (error) {
            console.log(error);
        });
    };
    DashboardComponent.prototype.onDeclineItem = function (itemDub) {
        var _this = this;
        this.busy = true;
        console.log('item declined');
        this.assignmentService.declineAssignmentItem(itemDub.assignmentItemId).subscribe(function (res) {
            location.reload();
            _this.busy = false;
        }, function (error) {
            console.log(error);
            _this.busy = false;
        });
    };
    DashboardComponent.prototype.onClickAssignmentItem = function (item) {
        console.log(item);
        if (item.type == 3) {
            this.router.navigate(['/segment/' + item.assignmentItemId]);
        }
        else {
            this.router.navigate(['/home/' + item.assignmentItemId]);
        }
    };
    DashboardComponent.prototype.onSubmitItem = function (item) {
        var _this = this;
        console.log(item);
        var assigmentItemId = item.assignmentItemId;
        this.assignmentService.checkAssignmentItemFinished(assigmentItemId).subscribe(function (res) {
            var isFinished = res.text();
            if (isFinished == 'true') {
                _this.assignmentService.submitAssignment(assigmentItemId).subscribe();
                location.reload();
            }
            else {
                _this.assignmentItemUnfinished = true;
                _this.create('Not Yet', 'warn', 'Please make sure the assignment is done before submitting.');
            }
        });
        // this.assignmentService.submitAssignment(assigmentItemId).subscribe(
        //   res => {
        //     location.reload();
        //   }, error => {
        //     console.log(error);
        //   }
        // );
    };
    // Notification creation
    DashboardComponent.prototype.create = function (title, type, message) {
        this.notificationService.create(title, message, type, {
            timeOut: 10000,
            showProgressBar: true,
            pauseOnHover: true
        });
    };
    DashboardComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.onCheckSession();
        this.helperService.sideMenuStatus$.subscribe(function (open) {
            _this._opened = open;
        });
        this.assignmentService.getUnfinishedAssignmentItemDubListByUser().subscribe(function (res) {
            _this.assignmentItemDubList = res.json();
        }, function (error) {
            console.log(error);
        });
        this.userService.getUserAssignmentItemInfo().subscribe(function (res) {
            var info = res.json();
            _this.dotNewNumber = info.dotNew;
            _this.dotChangedNumber = info.dotChanged;
            _this.dotDoneNumber = info.dotDone;
            _this.rectNewNumber = info.rectNew;
            _this.rectChangedNumber = info.rectChanged;
            _this.rectDoneNumber = info.rectDone;
        });
    };
    DashboardComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-dashboard',
            template: __webpack_require__(/*! ./dashboard.component.html */ "./src/app/components/dashboard/dashboard.component.html"),
            styles: [__webpack_require__(/*! ./dashboard.component.css */ "./src/app/components/dashboard/dashboard.component.css")]
        }),
        __metadata("design:paramtypes", [_services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_5__["HelperService"],
            _services_task_service_task_service__WEBPACK_IMPORTED_MODULE_4__["TaskService"],
            _services_login_service__WEBPACK_IMPORTED_MODULE_3__["LoginService"],
            _services_user_service_user_service__WEBPACK_IMPORTED_MODULE_6__["UserService"],
            _services_assignment_service_assignment_service__WEBPACK_IMPORTED_MODULE_7__["AssignmentService"],
            angular2_notifications__WEBPACK_IMPORTED_MODULE_8__["NotificationsService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], DashboardComponent);
    return DashboardComponent;
}());



/***/ }),

/***/ "./src/app/components/file-manager/file-manager-content/file-manager-content.component.css":
/*!*************************************************************************************************!*\
  !*** ./src/app/components/file-manager/file-manager-content/file-manager-content.component.css ***!
  \*************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".file-container{\n\twidth: 90%;\n\tmargin: auto;\n\tmargin-top: 50px;\n\tmargin-bottom: 50px;\n}\n\n.big-checkbox {width: 20px; height: 20px;}\n\n.brightness {\n  display: inline-block;\n  cursor: pointer;\n\n}\n\n.brightness:hover {\n  color: blue;\n}\n\n.selected {\n  text-decoration: underline;\n  font-weight: bold;\n}\n\n.box {\n  border: 1px solid red;\n}\n\nul {\n  list-style-type: none;\n}\n\n.my-drop-zone { border: dotted 3px lightgray; }\n"

/***/ }),

/***/ "./src/app/components/file-manager/file-manager-content/file-manager-content.component.html":
/*!**************************************************************************************************!*\
  !*** ./src/app/components/file-manager/file-manager-content/file-manager-content.component.html ***!
  \**************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"file-container\">\n  <div style=\"min-height: 650px;\">\n    <div class=\"row\">\n      <div class=\"col-4\">\n        <label class=\"control\">Filter items\n          <input type=\"text\" class=\"input\" placeholder=\"filter\" [(ngModel)]=\"filter\">\n        </label>\n      </div>\n      <div class=\"col-4\">\n        <label class=\"control\">itemsPerPage\n          <input type=\"number\" class=\"input\" min=\"0\" [(ngModel)]=\"config.itemsPerPage\">\n        </label>\n      </div>\n      <div class=\"col-4\">\n        <label class=\"control\">currentPage\n          <input type=\"number\" class=\"input\" min=\"0\" [(ngModel)]=\"config.currentPage\">\n        </label>\n      </div>\n    </div>\n    <br>\n    <!--<h6>ROOT/{{currentPath}}</h6>-->\n    <h5 *ngFor=\"let name of folderPathArr; let i = index\" class=\"brightness\"\n        style=\"cursor: pointer; font-weight: bolder \"\n        (click)=\"onClickPath(i)\">/{{name}}</h5>\n    <hr>\n    <div class=\"row\">\n      <div class=\"col-4 text-center\">Name</div>\n      <div class=\"col-4\" style=\"margin-left: -30px;\">Dicom | Type</div>\n      <div class=\"col-4 text-right\">\n        <!--hide buttons if no content-->\n        <div *ngIf=\"folderPathArr.length > 0\">\n          <button *ngIf=\"!editMode\" type=\"button\" class=\"btn btn-outline-dark\" (click)=\"onNewFolder()\">New Folder\n          </button>\n          <button *ngIf=\"!editMode\" type=\"button\" class=\"btn btn-outline-dark\" (click)=\"onClickEdit()\">Edit</button>\n          <button *ngIf=\"editMode\" type=\"button\" class=\"btn btn-outline-dark\" (click)=\"onDeleteFolder()\">Delete</button>\n          <button *ngIf=\"editMode\" type=\"button\" class=\"btn btn-outline-dark\" (click)=\"onCancelEdit()\">Cancel</button>\n        </div>\n      </div>\n    </div>\n    <hr>\n\n    <div ng2FileDrop class=\"well my-drop-zone\"\n         (onFileDrop)=\"onFileDropped()\"\n         [uploader]=\"currentUploader\" style=\"min-height: 520px; padding-top: 10px;\">\n      <div class=\"row\">\n        <div class=\"col-5 \" style=\"overflow: auto;\">\n          <ul>\n\n            <li *ngFor=\"let file of fileList | stringFilter: filter | paginate: config\" [contextMenu]=\"basicMenu\"\n                [contextMenuSubject]=\"file\"\n                style=\" margin-right: 40px; margin-bottom: 5px;\">\n          <span *ngIf=\"file.type == 'folder'\">\n            <span class=\"brightness\" style=\"width: 330px;\">\n              <input *ngIf=\"editMode\" type=\"checkbox\" name=\"folderName\" class=\"big-checkbox pull-left\"\n                     (change)=\"onSelectFolder($event)\" [value]=\"file.id\" [checked]=\"onCheckChecked(file)\">&nbsp;\n              <i class=\"fa fa-folder pull-left\" style=\"font-size: 25px;\" (click)=\"onClickFile(file)\"></i>&nbsp;\n              <span (click)=\"onClickFile(file)\" class=\"pull-left\">{{file.name}}</span>\n            </span>\n          </span>\n\n              <span *ngIf=\"file.type == 'file'\" (click)=\"onClickFile(file)\"\n                    [ngClass]=\"{'selected': file==currentFile}\">\n            <span class=\"brightness\" style=\"cursor: pointer; width: 330px;\">\n              <input *ngIf=\"editMode\" type=\"checkbox\" name=\"folderName\" class=\"big-checkbox pull-left\"\n                     (change)=\"onSelectFolder($event)\" [value]=\"file.id\" [checked]=\"onCheckChecked(file)\">&nbsp;\n            <span>\n              <i class=\"fa fa-file-o pull-left\" style=\"font-size: 20px;\"></i>&nbsp;\n                <span class=\"pull-left\">{{file.name}}</span>\n              <span class=\"pull-right\">\n                <span *ngIf=\"file.dicomExists\" class=\"fa fa-check\" aria-hidden=\"true\"></span>\n                <span *ngIf=\"!file.dicomExists\" class=\"fa fa-times\" aria-hidden=\"true\"></span>\n              | {{ file.imageType }}\n              </span>\n            </span>\n            </span>\n          </span>\n\n\n            </li>\n          </ul>\n        </div>\n        <div class=\"col-4 text-center\">\n          <div *ngIf=\"displayImage\">\n            <img class=\"img-thumbnail\" [src]=\"imgUrl\">\n          </div>\n        </div>\n        <div class=\"col-3\">\n          <h6 *ngIf=\"displayImage\">{{ currentImage }}</h6>\n          <h6 *ngIf=\"displayImage\">Image Type: {{ imageType }}</h6>\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <br>\n  <hr>\n  <pagination-controls [id]=\"config.id\"\n                       [maxSize]=\"maxSize\"\n                       [directionLinks]=\"directionLinks\"\n                       [autoHide]=\"autoHide\"\n                       [responsive]=\"responsive\"\n                       [previousLabel]=\"labels.previousLabel\"\n                       [nextLabel]=\"labels.nextLabel\"\n                       [screenReaderPaginationLabel]=\"labels.screenReaderPaginationLabel\"\n                       [screenReaderPageLabel]=\"labels.screenReaderPageLabel\"\n                       [screenReaderCurrentLabel]=\"labels.screenReaderCurrentLabel\"\n                       (pageChange)=\"onPageChange($event)\"></pagination-controls>\n\n</div>\n\n<ng-progress [color]=\"progressBarColor\"></ng-progress>\n\n\n<simple-notifications></simple-notifications>\n<!--<button id=\"uploadButton\" (click)=\"create()\" hidden></button>-->\n\n<!--Modal Create Folder-->\n<ngx-smart-modal #myModal identifier=\"myModal\" (onClose)=\"onNewFolderClose()\">\n  <div class=\"form-group\">\n    <p style=\"color:red;\">{{ createFolderMessage }}</p>\n    <p *ngIf=\"illegalNewFolderName\" style=\"color:red;\">Invalid New Name, no special character or space allowed.</p>\n    <label for=\"folderName\">Folder Name</label>\n    <input type=\"text\" class=\"form-control\" id=\"folderName\" placeholder=\"New Folder Name\" [(ngModel)]=\"newFolderName\"\n           autofocus>\n  </div>\n  <button class=\"btn btn-sm btn-outline-dark pointer\" (click)=\"onSetFolderName()\" style=\"width: 70px;\">OK</button>\n\n  <button class=\"btn btn-sm btn-outline-dark pointer pull-right\" (click)=\"myModal.close()\">Cancel</button>\n\n</ngx-smart-modal>\n\n\n<!--Modal Rename-->\n<context-menu [useBootstrap4]=\"true\">\n  <ng-template contextMenuItem let-item (execute)=\"onClickRename($event.item)\">\n    Rename\n  </ng-template>\n</context-menu>\n\n<ngx-smart-modal #renameModal identifier=\"renameModal\" (onClose)=\"onRenameClose()\">\n  <p *ngIf=\"illegalName\" style=\"color:red;\">Invalid New Name, no special character or space allowed.</p>\n  <div class=\"form-group\">\n    <label for=\"newName\">New Name</label>\n    <input type=\"text\" class=\"form-control\" id=\"newName\" [(ngModel)]=\"newName\" [autofocus]=\"true\">\n  </div>\n  <button class=\"btn btn-sm btn-outline-dark pointer\" (click)=\"onSetNewName()\" style=\"width: 70px;\">OK</button>\n\n  <button class=\"btn btn-sm btn-outline-dark pointer pull-right\" (click)=\"renameModal.close()\">Cancel</button>\n\n</ngx-smart-modal>\n\n<ngx-smart-modal #fileTypeModal identifier=\"fileTypeModal\" [closable]=\"false\" (onDismiss)=\"onCancelUpload()\" (onEscape)=\"onCancelUpload()\">\n  <div class=\"form-group\">\n    <h6>Please select the file type:</h6>\n\n    <!-- Default checked -->\n    <div class=\"form-check form-check-inline\">\n      <input class=\"form-check-input\" type=\"radio\" name=\"folderName1RadioOptions\" id=\"folderName1Radio1\"\n             value=\"mri\" [(ngModel)]=\"uploadFileType\">\n      <label class=\"form-check-label\" for=\"folderName1Radio1\">MRI</label>\n    </div>\n    <div class=\"form-check form-check-inline\">\n      <input class=\"form-check-input\" type=\"radio\" name=\"folderName1RadioOptions\" id=\"folderName1Radio2\"\n             value=\"ct\" [(ngModel)]=\"uploadFileType\">\n      <label class=\"form-check-label\" for=\"folderName1Radio2\">CT</label>\n    </div>\n    <div class=\"form-check form-check-inline\">\n      <input class=\"form-check-input\" type=\"radio\" name=\"folderName1RadioOptions\" id=\"folderName1Radio3\"\n             value=\"xray\" [(ngModel)]=\"uploadFileType\">\n      <label class=\"form-check-label\" for=\"folderName1Radio3\">X-Ray</label>\n    </div>\n    <br>\n  </div>\n  <button class=\"btn btn-sm btn-outline-dark pointer\" (click)=\"onDropUpload()\" style=\"width: 70px;\">OK</button>\n\n  <button class=\"btn btn-sm btn-outline-dark pointer pull-right\" (click)=\"onCancelUpload()\">Cancel</button>\n\n</ngx-smart-modal>\n"

/***/ }),

/***/ "./src/app/components/file-manager/file-manager-content/file-manager-content.component.ts":
/*!************************************************************************************************!*\
  !*** ./src/app/components/file-manager/file-manager-content/file-manager-content.component.ts ***!
  \************************************************************************************************/
/*! exports provided: FileManagerContentComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FileManagerContentComponent", function() { return FileManagerContentComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_io_service_io_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../services/io-service/io.service */ "./src/app/services/io-service/io.service.ts");
/* harmony import */ var _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../services/helper-service/helper.service */ "./src/app/services/helper-service/helper.service.ts");
/* harmony import */ var _app_const__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../app-const */ "./src/app/app-const.ts");
/* harmony import */ var ngx_smart_modal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ngx-smart-modal */ "./node_modules/ngx-smart-modal/esm5/ngx-smart-modal.js");
/* harmony import */ var ngx_contextmenu__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ngx-contextmenu */ "./node_modules/ngx-contextmenu/fesm5/ngx-contextmenu.js");
/* harmony import */ var ng2_file_upload__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ng2-file-upload */ "./node_modules/ng2-file-upload/index.js");
/* harmony import */ var ng2_file_upload__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(ng2_file_upload__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var angular2_notifications__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! angular2-notifications */ "./node_modules/angular2-notifications/angular2-notifications.umd.js");
/* harmony import */ var angular2_notifications__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(angular2_notifications__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _ngx_progressbar_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-progressbar/core */ "./node_modules/@ngx-progressbar/core/fesm5/ngx-progressbar-core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};









// const URL = 'http://localhost:8181/longwood-be/image/upload';
var URL = 'http://152.136.197.88:8181/longwood-be/image/upload';
// const URL = 'http://35.192.119.153:8181/longwood-be/image/upload';
var FileManagerContentComponent = /** @class */ (function () {
    function FileManagerContentComponent(ioService, helperService, ngxSmartModalService, notificationService) {
        this.ioService = ioService;
        this.helperService = helperService;
        this.ngxSmartModalService = ngxSmartModalService;
        this.notificationService = notificationService;
        this.filter = '';
        this.maxSize = 7;
        this.directionLinks = true;
        this.autoHide = true;
        this.responsive = true;
        this.imgUrl = '';
        this.displayImage = false;
        this.currentPath = '';
        this.folderPathArr = [];
        this.editMode = false;
        this.config = {
            id: 'advanced',
            itemsPerPage: 20,
            currentPage: 1
        };
        this.selectedFolderList = [];
        this.p = 1;
        this.labels = {
            previousLabel: 'Previous',
            nextLabel: 'Next',
            screenReaderPaginationLabel: 'Pagination',
            screenReaderPageLabel: 'page',
            screenReaderCurrentLabel: "You're on page"
        };
        this.uploaderList = [];
        this.uploader = new ng2_file_upload__WEBPACK_IMPORTED_MODULE_6__["FileUploader"]({ url: URL });
        this.hasBaseDropZoneOver = false;
        this.hasAnotherDropZoneOver = false;
        this.currentUploader = new ng2_file_upload__WEBPACK_IMPORTED_MODULE_6__["FileUploader"]({ url: URL });
        this.progressBarColor = '#e03f1b';
    }
    FileManagerContentComponent.prototype.fileOverBase = function (e) {
        this.hasBaseDropZoneOver = e;
    };
    FileManagerContentComponent.prototype.fileOverAnother = function (e) {
        this.hasAnotherDropZoneOver = e;
    };
    // Notification creation
    FileManagerContentComponent.prototype.create = function (title, type, message) {
        this.notificationService.create(title, message, type, {
            timeOut: 0,
            showProgressBar: false,
            pauseOnHover: true
        });
    };
    FileManagerContentComponent.prototype.onFileDropped = function () {
        this.uploadFileType = 'ct';
        this.ngxSmartModalService.getModal('fileTypeModal').open();
    };
    FileManagerContentComponent.prototype.onDropUpload = function () {
        var _this = this;
        this.ngxSmartModalService.getModal('fileTypeModal').close();
        this.uploaderList.push(this.currentUploader);
        var fileItem = this.uploaderList[this.uploaderList.length - 1];
        var fileName = fileItem.queue[0].file.name;
        this.create('Uploading...', 'info', fileName);
        if (fileName.indexOf('.') > 0) {
            fileName = fileName.substring(0, fileName.lastIndexOf('.'));
        }
        this.currentUploader.onBuildItemForm = function (item, form) {
            form.append('folderName', fileName);
            form.append('type', _this.uploadFileType);
            form.append('folderPath', _this.folderPathArr.join('/'));
        };
        this.currentUploader.queue[0].upload();
        this.progressBar.start();
        var that = this;
        setTimeout(function () {
            that.progressBar.set(that.currentUploader.progress);
        }.bind(this), 100);
        this.currentUploader = new ng2_file_upload__WEBPACK_IMPORTED_MODULE_6__["FileUploader"]({ url: URL });
        // setTimeout(function () {
        //   $('#uploadButton').trigger('click');
        // }.bind(this), 100);
    };
    FileManagerContentComponent.prototype.onCancelUpload = function () {
        this.currentUploader.queue.pop();
        this.ngxSmartModalService.getModal('fileTypeModal').close();
    };
    FileManagerContentComponent.prototype.onSuccessUpload = function (item, response, status, headers) {
        this.create('Finished uploading', 'success', item.file.name);
        this.helperService.fetchDirectoryStructure = true;
        this.gotoFolder(this.currentPath);
        if (this.currentUploader.queue.length == 0) {
            this.progressBar.complete();
        }
    };
    FileManagerContentComponent.prototype.onErrorUpload = function (item, response, status, headers) {
        this.create('Upload Failed', 'error', item.file.name);
        this.helperService.fetchDirectoryStructure = true;
        this.gotoFolder(this.currentPath);
        if (this.currentUploader.queue.length == 0) {
            this.progressBar.complete();
        }
    };
    FileManagerContentComponent.prototype.checkUploadSuccess = function () {
        console.log(this.currentUploader.queue);
        for (var i = 0; i < this.currentUploader.queue.length; i++) {
            if (this.currentUploader.queue[i].isSuccess) {
                console.log('finished');
                this.helperService.fetchDirectoryStructure = true;
                this.gotoFolder(this.currentPath);
                this.create('Finished uploading', 'success', this.currentUploader.queue[i].file.name);
                this.currentUploader.queue.splice(i, 1);
            }
        }
    };
    FileManagerContentComponent.prototype.onClose = function () {
        this.ngxSmartModalService.getModal('fileTypeModal').close();
        alert("test");
    };
    FileManagerContentComponent.prototype.onPageChange = function (number) {
        console.log('change to page', number);
        this.config.currentPage = number;
        console.log(this.selectedFolderList);
    };
    FileManagerContentComponent.prototype.onSelectFolder = function (event) {
        console.log(event.target.checked);
        console.log(event.target);
        if (event.target.checked == true) {
            this.selectedFolderList.push(event.target.value);
        }
        if (event.target.checked == false) {
            var index = this.selectedFolderList.indexOf(event.target.value);
            this.selectedFolderList.splice(index, 1);
        }
        console.log(this.selectedFolderList);
    };
    FileManagerContentComponent.prototype.onClickFile = function (file) {
        var _this = this;
        console.log(file);
        var path = this.currentPath + file.name + '/';
        this.ioService.selectedFolder = path;
        if (file.type == 'folder') {
            this.filter = '';
            this.ioService.getFileList(path).subscribe(function (res) {
                _this.helperService.displayImageContent = { 'display': false, 'url': '' };
                _this.currentPath = _this.currentPath + file.name + '/';
                _this.folderPathArr = _this.currentPath.split('/');
                _this.fileList = res.json();
                _this.ioService.fileList = _this.fileList;
            }, function (error) {
                console.log(error);
            });
        }
        else {
            console.log('display image: ' + path);
            this.currentImage = file.name;
            this.displayImage = true;
            this.imgUrl = _app_const__WEBPACK_IMPORTED_MODULE_3__["AppConst"].serverPath + '/image/getImage/' + path;
            this.currentFile = file;
            this.imageType = file.imageType;
        }
    };
    FileManagerContentComponent.prototype.onClickPath = function (i) {
        var _this = this;
        console.log(this.folderPathArr[i]);
        var path = this.folderPathArr.slice(0, i + 1).join('/') + '/';
        this.currentPath = path;
        this.ioService.getFileList(path).subscribe(function (res) {
            _this.helperService.displayImageContent = { 'display': false, 'url': '' };
            // if (!this.currentPath == '/') {
            //   this.folderPathArr = this.currentPath.split('/');
            // } else {
            //   this.folderPathArr = [''];
            // }
            _this.folderPathArr = _this.currentPath.split('/');
            _this.fileList = res.json();
            _this.ioService.fileList = _this.fileList;
        }, function (error) {
            console.log(error);
        });
    };
    FileManagerContentComponent.prototype.onClickEdit = function () {
        this.editMode = true;
    };
    FileManagerContentComponent.prototype.onCancelEdit = function () {
        this.editMode = false;
        this.selectedFolderList = [];
    };
    FileManagerContentComponent.prototype.onDeleteFolder = function () {
        var _this = this;
        this.ioService.deleteFolder(this.selectedFolderList).subscribe(function (res) {
            // this.ioService.fetchFileList = true;
            _this.editMode = false;
            _this.helperService.fetchDirectoryStructure = true;
            _this.selectedFolderList = [];
            _this.gotoFolder(_this.currentPath);
        });
    };
    FileManagerContentComponent.prototype.fetchFileList = function () {
        var _this = this;
        this.ioService.fileListStatus$.subscribe(function (fileList) {
            _this.fileList = fileList;
        });
    };
    FileManagerContentComponent.prototype.onCheckChecked = function (file) {
        return this.selectedFolderList.includes(file.id + '');
    };
    FileManagerContentComponent.prototype.onNewFolder = function () {
        this.ngxSmartModalService.getModal('myModal').open();
    };
    FileManagerContentComponent.prototype.gotoFolder = function (folderPath) {
        var _this = this;
        this.ioService.getFileList(folderPath).subscribe(function (res) {
            _this.helperService.displayImageContent = { 'display': false, 'url': '' };
            _this.folderPathArr = _this.currentPath.split('/');
            _this.fileList = res.json();
            _this.ioService.fileList = _this.fileList;
        }, function (error) {
            console.log(error);
        });
    };
    FileManagerContentComponent.prototype.onSetFolderName = function () {
        var _this = this;
        if (this.newFolderName == undefined) {
            this.illegalNewFolderName = true;
            return;
        }
        this.illegalNewFolderName = !this.newFolderName.match(/^[\w,\-&]+$/i);
        if (this.illegalNewFolderName) {
            return;
        }
        this.ioService.createFolder(this.currentPath, this.newFolderName, 'ct').subscribe(function (res) {
            // this.ioService.fetchFileList = true;
            _this.helperService.fetchDirectoryStructure = true;
            _this.newFolderName = '';
            _this.gotoFolder(_this.currentPath);
            _this.createFolderMessage = '';
            _this.ngxSmartModalService.getModal('myModal').close();
        }, function (error) {
            _this.createFolderMessage = error.text();
        });
    };
    FileManagerContentComponent.prototype.onClickRename = function (file) {
        console.log(file);
        this.targetFile = file;
        this.ngxSmartModalService.getModal('renameModal').open();
    };
    FileManagerContentComponent.prototype.onSetNewName = function () {
        var _this = this;
        if (this.newName == undefined) {
            this.illegalName = true;
            return;
        }
        this.illegalName = !this.newName.match(/^[\w,\-&]+$/i);
        if (this.illegalName) {
            return;
        }
        this.ioService.renameFolder(this.targetFile.id, this.newName).subscribe(function (res) {
            _this.ngxSmartModalService.getModal('renameModal').close();
            _this.newName = '';
            _this.targetFile = null;
            _this.gotoFolder(_this.currentPath);
            _this.helperService.fetchDirectoryStructure = true;
        }, function (error) {
            console.log(error);
        });
    };
    FileManagerContentComponent.prototype.onNewFolderClose = function () {
        this.newFolderName = '';
        this.illegalNewFolderName = false;
    };
    FileManagerContentComponent.prototype.onRenameClose = function () {
        this.newName = '';
        this.targetFile = null;
        this.illegalName = false;
    };
    FileManagerContentComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.fetchFileList();
        // this.helperService.folderAction$.subscribe(
        //   action => {
        //     this.folderAction = action;
        //     this.ioService.deleteFolder(this.selectedFolderList).subscribe(
        //       res => {
        //         this.ioService.fetchFileList = true;
        //       }
        //     );
        //   }
        // );
        this.helperService.displayImageContent$.subscribe(function (imgObj) {
            console.log(imgObj);
            _this.displayImage = imgObj.display;
            _this.filter = '';
            var url = _app_const__WEBPACK_IMPORTED_MODULE_3__["AppConst"].serverPath + '/image/getImage/' + imgObj.url + '.jpg';
            _this.imgUrl = url;
            var pieces = url.split('/');
            _this.currentImage = pieces[pieces.length - 1];
            pieces = imgObj.url.split('/');
            pieces.pop();
            pieces.push('');
            _this.folderPathArr = pieces.slice(0, pieces.length);
            console.log(_this.folderPathArr);
        });
        this.helperService.currentFolderPath$.subscribe(function (path) {
            _this.filter = '';
            _this.currentPath = path;
            _this.folderPathArr = _this.currentPath.split('/');
            console.log(_this.currentPath);
        });
        var that = this;
        this.currentPath = 'ROOT/';
        this.fetchFileList();
        this.gotoFolder('ROOT/');
        setInterval(function () {
            // that.checkUploadSuccess();
            that.currentUploader.onSuccessItem = function (item, response, status, headers) { return that.onSuccessUpload(item, response, status, headers); };
            that.currentUploader.onErrorItem = function (item, response, status, headers) { return that.onErrorUpload(item, response, status, headers); };
        }, 500);
        // this.currentUploader.onSuccessItem = (item, response, status, headers) => this.onSuccessUpload(item, response, status, headers);
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])(ngx_contextmenu__WEBPACK_IMPORTED_MODULE_5__["ContextMenuComponent"]),
        __metadata("design:type", ngx_contextmenu__WEBPACK_IMPORTED_MODULE_5__["ContextMenuComponent"])
    ], FileManagerContentComponent.prototype, "basicMenu", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('dropUpload'),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"])
    ], FileManagerContentComponent.prototype, "dropUpload", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])(_ngx_progressbar_core__WEBPACK_IMPORTED_MODULE_8__["NgProgressComponent"]),
        __metadata("design:type", _ngx_progressbar_core__WEBPACK_IMPORTED_MODULE_8__["NgProgressComponent"])
    ], FileManagerContentComponent.prototype, "progressBar", void 0);
    FileManagerContentComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-file-manager-content',
            template: __webpack_require__(/*! ./file-manager-content.component.html */ "./src/app/components/file-manager/file-manager-content/file-manager-content.component.html"),
            styles: [__webpack_require__(/*! ./file-manager-content.component.css */ "./src/app/components/file-manager/file-manager-content/file-manager-content.component.css")],
            changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ChangeDetectionStrategy"].Default
        }),
        __metadata("design:paramtypes", [_services_io_service_io_service__WEBPACK_IMPORTED_MODULE_1__["IoService"], _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_2__["HelperService"], ngx_smart_modal__WEBPACK_IMPORTED_MODULE_4__["NgxSmartModalService"], angular2_notifications__WEBPACK_IMPORTED_MODULE_7__["NotificationsService"]])
    ], FileManagerContentComponent);
    return FileManagerContentComponent;
}());



/***/ }),

/***/ "./src/app/components/file-manager/file-manager-nav/file-manager-nav.component.css":
/*!*****************************************************************************************!*\
  !*** ./src/app/components/file-manager/file-manager-nav/file-manager-nav.component.css ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".nav-font {\n\tcolor: white;\n}\n\n.pointer {\n  cursor: pointer;\n}\n"

/***/ }),

/***/ "./src/app/components/file-manager/file-manager-nav/file-manager-nav.component.html":
/*!******************************************************************************************!*\
  !*** ./src/app/components/file-manager/file-manager-nav/file-manager-nav.component.html ***!
  \******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<nav class=\"navbar navbar-expand-lg navbar-light bg-secondary justify-content-between\">\n  <a class=\"navbar-brand\" style=\"color: white;\">File Manager</a>\n\n  <form class=\"form-inline\">\n    <a class=\"navbar-brand nav-font\" routerLink=\"/uploadImages\" routerLinkActive=\"active\">Upload</a>\n\n  </form>\n</nav>\n"

/***/ }),

/***/ "./src/app/components/file-manager/file-manager-nav/file-manager-nav.component.ts":
/*!****************************************************************************************!*\
  !*** ./src/app/components/file-manager/file-manager-nav/file-manager-nav.component.ts ***!
  \****************************************************************************************/
/*! exports provided: FileManagerNavComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FileManagerNavComponent", function() { return FileManagerNavComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../services/helper-service/helper.service */ "./src/app/services/helper-service/helper.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var FileManagerNavComponent = /** @class */ (function () {
    function FileManagerNavComponent(helperService) {
        this.helperService = helperService;
    }
    FileManagerNavComponent.prototype.deleteFolder = function () {
        this.helperService.folderAction = 'delete';
    };
    FileManagerNavComponent.prototype.ngOnInit = function () {
    };
    FileManagerNavComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-file-manager-nav',
            template: __webpack_require__(/*! ./file-manager-nav.component.html */ "./src/app/components/file-manager/file-manager-nav/file-manager-nav.component.html"),
            styles: [__webpack_require__(/*! ./file-manager-nav.component.css */ "./src/app/components/file-manager/file-manager-nav/file-manager-nav.component.css")]
        }),
        __metadata("design:paramtypes", [_services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_1__["HelperService"]])
    ], FileManagerNavComponent);
    return FileManagerNavComponent;
}());



/***/ }),

/***/ "./src/app/components/file-manager/file-manager-tree/file-manager-tree.component.css":
/*!*******************************************************************************************!*\
  !*** ./src/app/components/file-manager/file-manager-tree/file-manager-tree.component.css ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".box {\n  border: 1px solid red;\n}\n\n\n"

/***/ }),

/***/ "./src/app/components/file-manager/file-manager-tree/file-manager-tree.component.html":
/*!********************************************************************************************!*\
  !*** ./src/app/components/file-manager/file-manager-tree/file-manager-tree.component.html ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div style=\"margin-top: 30px;  max-height: 750px; max-width: 500px; overflow-x: scroll;\n    white-space: nowrap;\">\n  <!--<div>-->\n  <!--<span>Display Image Files? No</span>&nbsp;-->\n  <!--<ui-switch [(ngModel)]=\"displayImage\" (change)=\"toggleTreeDisplay()\" size=\"small\"></ui-switch>&nbsp;-->\n  <!--<span>Yes</span>-->\n  <!--</div>-->\n  <hr>\n  <tree [tree]=\"tree\" (nodeSelected)=\"handleSelected($event)\" [settings]=\"settings\" #treeComponent>\n    <ng-template let-node>\n      <!--<i class=\"fa {{node.type}}\"></i>&nbsp;-->\n      <span class=\"node-name\" [innerHTML]=\"node.value\"></span>\n    </ng-template>\n  </tree>\n</div>\n"

/***/ }),

/***/ "./src/app/components/file-manager/file-manager-tree/file-manager-tree.component.ts":
/*!******************************************************************************************!*\
  !*** ./src/app/components/file-manager/file-manager-tree/file-manager-tree.component.ts ***!
  \******************************************************************************************/
/*! exports provided: FileManagerTreeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FileManagerTreeComponent", function() { return FileManagerTreeComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_io_service_io_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../services/io-service/io.service */ "./src/app/services/io-service/io.service.ts");
/* harmony import */ var _services_image_service_image_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../services/image-service/image.service */ "./src/app/services/image-service/image.service.ts");
/* harmony import */ var _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../services/helper-service/helper.service */ "./src/app/services/helper-service/helper.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var FileManagerTreeComponent = /** @class */ (function () {
    function FileManagerTreeComponent(ioService, imageService, helperService) {
        this.ioService = ioService;
        this.imageService = imageService;
        this.helperService = helperService;
        this.settings = {
            'static': true,
            // rootIsVisible: true,
            'cssClasses': {
                'expanded': 'fa fa-caret-down fa-lg',
                'collapsed': 'fa fa-caret-right fa-lg',
                'leaf': 'fa fa-lg',
                'empty': 'fa fa-caret-right disabled'
            },
            'templates': {
                'node': '<i class="fa fa-folder-o fa-lg"></i>',
                'leaf': '<i class="fa fa-file-o fa-lg"></i>',
                'leftMenu': '<i class="fa fa-navicon fa-lg"></i>'
            }
        };
    }
    FileManagerTreeComponent.prototype.getPath = function () {
        return this.path;
    };
    FileManagerTreeComponent.prototype.handleSelected = function (nodeEvent) {
        var _this = this;
        var node0 = nodeEvent.node;
        var node = nodeEvent.node;
        var path = '';
        console.log(node);
        console.log(node.node.type);
        while (node.parent != null) {
            path = node.value + '/' + path;
            node = node.parent;
        }
        this.path = path;
        console.log(path);
        this.ioService.selectedFolder = path;
        if (node0.node.type == 'fa-folder') {
            this.ioService.getFileList(path).subscribe(function (res) {
                _this.helperService.displayImageContent = { 'display': false, 'url': '' };
                _this.fileList = res.json();
                _this.ioService.fileList = _this.fileList;
                _this.helperService.currentFolderPath = path;
            }, function (error) {
                console.log(error);
            });
        }
        else {
            this.helperService.displayImageContent = {
                'display': true,
                'url': path.substr(0, path.length - 1)
            };
        }
    };
    FileManagerTreeComponent.prototype.hideImage = function (array) {
        for (var i = array.length - 1; i >= 0; --i) {
            var obj = array[i];
            if (!obj.children) {
                array.splice(i, 1);
            }
            else {
                this.hideImage(obj.children);
            }
        }
    };
    FileManagerTreeComponent.prototype.toggleTreeDisplay = function () {
        if (this.displayImage) {
            var treeTemp = JSON.parse(JSON.stringify(this.tree));
            console.log('hiding image...');
            this.hideImage(treeTemp.children);
            this.tree = treeTemp;
            this.displayImage = false;
        }
        else {
            this.tree = JSON.parse(JSON.stringify(this.treeStore));
            this.displayImage = true;
        }
    };
    FileManagerTreeComponent.prototype.fetchDirectoryStructure = function () {
        var _this = this;
        this.ioService.getDirectoryStructure().subscribe(function (res) {
            _this.tree = res.json();
            _this.treeStore = res.json();
            _this.tree.settings = {
                'static': true,
                'cssClasses': {
                    'expanded': 'fa fa-caret-down fa-lg',
                    'collapsed': 'fa fa-caret-right fa-lg',
                    'leaf': 'fa fa-lg',
                    'empty': 'fa '
                },
                'templates': {
                    'node': '<i class="fa fa-folder fa-lg"></i>',
                    'leaf': '<i class="fa fa-file-o fa-lg"></i>',
                    'leftMenu': '<i class="fa fa-navicon fa-lg"></i>'
                }
            };
            if (!_this.displayImage) {
                // let treeTemp = JSON.parse(JSON.stringify(this.tree));
                var treeTemp = _this.tree;
                console.log('hiding image...');
                _this.hideImage(treeTemp.children);
                _this.tree = treeTemp;
            }
        }, function (error) {
            console.log(error);
        });
    };
    FileManagerTreeComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.fetchDirectoryStructure();
        this.helperService.fetchDirectoryStructure$.subscribe(function (needFetch) {
            if (needFetch) {
                _this.fetchDirectoryStructure();
            }
        });
        this.ioService.fetchFileList$.subscribe(function (status) {
            if (status === true) {
                _this.ioService.getFileList(_this.path).subscribe(function (res) {
                    _this.fileList = res.json();
                    _this.ioService.fileList = _this.fileList;
                }, function (error) {
                    console.log(error);
                });
            }
        });
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('treeComponent'),
        __metadata("design:type", Object)
    ], FileManagerTreeComponent.prototype, "treeComponent", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])('displayImage'),
        __metadata("design:type", Object)
    ], FileManagerTreeComponent.prototype, "displayImage", void 0);
    FileManagerTreeComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-file-manager-tree',
            template: __webpack_require__(/*! ./file-manager-tree.component.html */ "./src/app/components/file-manager/file-manager-tree/file-manager-tree.component.html"),
            styles: [__webpack_require__(/*! ./file-manager-tree.component.css */ "./src/app/components/file-manager/file-manager-tree/file-manager-tree.component.css")]
        }),
        __metadata("design:paramtypes", [_services_io_service_io_service__WEBPACK_IMPORTED_MODULE_1__["IoService"], _services_image_service_image_service__WEBPACK_IMPORTED_MODULE_2__["ImageService"], _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_3__["HelperService"]])
    ], FileManagerTreeComponent);
    return FileManagerTreeComponent;
}());



/***/ }),

/***/ "./src/app/components/file-manager/file-manager.component.css":
/*!********************************************************************!*\
  !*** ./src/app/components/file-manager/file-manager.component.css ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".file-container {\n\twidth: 90%;\n\tmargin: auto;\n\tmargin-top: 50px;\n}\n\n.box {\n\tborder: 1px solid black;\n}\n\n.mycontent-right {\n  border-left: 1px dashed #333;\n}\n"

/***/ }),

/***/ "./src/app/components/file-manager/file-manager.component.html":
/*!*********************************************************************!*\
  !*** ./src/app/components/file-manager/file-manager.component.html ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div>\n\t<app-navbar></app-navbar>\n\n\t<!-- Container for sidebar(s) + page content -->\n\t<ng-sidebar-container style=\"height: 800px;\">\n\t\t<!-- A sidebar -->\n\t\t<ng-sidebar [(opened)]=\"_opened\">\n\t\t\t<app-side-panel></app-side-panel>\n\t\t</ng-sidebar>\n\n\t\t<!-- Page content -->\n\t\t<div ng-sidebar-content>\n\t\t\t<div class=\"file-container\" >\n\t\t\t\t<app-file-manager-nav></app-file-manager-nav>\n\t\t\t\t<div class=\"row\">\n\t\t\t\t\t<div class=\"col-3\" >\n\t\t\t\t\t\t<div >\n\t\t\t\t\t\t\t<app-file-manager-tree [displayImage]=\"false\"></app-file-manager-tree>\n\t\t\t\t\t\t</div>\n\t\t\t\t\t</div>\n\t\t\t\t\t<div class=\"col-9\">\n\t\t\t\t\t\t<div class=\"mycontent-right\">\n\t\t\t\t\t\t\t<app-file-manager-content></app-file-manager-content>\n\t\t\t\t\t\t</div>\n\t\t\t\t\t</div>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</div>\n\t</ng-sidebar-container>\n\n\t\n</div>\n"

/***/ }),

/***/ "./src/app/components/file-manager/file-manager.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/components/file-manager/file-manager.component.ts ***!
  \*******************************************************************/
/*! exports provided: FileManagerComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FileManagerComponent", function() { return FileManagerComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../services/helper-service/helper.service */ "./src/app/services/helper-service/helper.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var FileManagerComponent = /** @class */ (function () {
    function FileManagerComponent(helperService) {
        this.helperService = helperService;
        this._opened = false;
    }
    FileManagerComponent.prototype._toggleSidebar = function () {
        this._opened = !this._opened;
    };
    FileManagerComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.helperService.sideMenuStatus$.subscribe(function (open) {
            console.log(open);
            _this._opened = open;
        });
    };
    FileManagerComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-file-manager',
            template: __webpack_require__(/*! ./file-manager.component.html */ "./src/app/components/file-manager/file-manager.component.html"),
            styles: [__webpack_require__(/*! ./file-manager.component.css */ "./src/app/components/file-manager/file-manager.component.css")]
        }),
        __metadata("design:paramtypes", [_services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_1__["HelperService"]])
    ], FileManagerComponent);
    return FileManagerComponent;
}());



/***/ }),

/***/ "./src/app/components/file-manager/select-file-content/select-file-content.component.css":
/*!***********************************************************************************************!*\
  !*** ./src/app/components/file-manager/select-file-content/select-file-content.component.css ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".file-container{\n  width: 90%;\n  margin: auto;\n  margin-top: 50px;\n  margin-bottom: 100px;\n}\n\n.big-checkbox {width: 20px; height: 20px;}\n"

/***/ }),

/***/ "./src/app/components/file-manager/select-file-content/select-file-content.component.html":
/*!************************************************************************************************!*\
  !*** ./src/app/components/file-manager/select-file-content/select-file-content.component.html ***!
  \************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"file-container\" >\n\n\n  <div class=\"row\">\n    <div class=\"col-4\">\n      <label class=\"control\">Filter items\n        <input type=\"text\" class=\"input\" placeholder=\"filter\" [(ngModel)]=\"filter\">\n      </label>\n    </div>\n    <div class=\"col-4\">\n      <label class=\"control\">itemsPerPage\n        <input type=\"number\" class=\"input\" min=\"0\" [(ngModel)]=\"config.itemsPerPage\">\n      </label>\n    </div>\n    <div class=\"col-4\">\n      <label class=\"control\">currentPage\n        <input type=\"number\" class=\"input\" min=\"0\" [(ngModel)]=\"config.currentPage\">\n      </label>\n    </div>\n  </div>\n  <hr>\n\n\n  <ul *ngFor=\"let file of fileList | stringFilter: filter | paginate: config; let i = index\" style=\" margin-right: 40px;\">\n\t\t<span *ngIf=\"file.type == 'folder'\" >\n                <input type=\"radio\" name=\"folderName\" class=\"big-checkbox\" [(ngModel)]=\"selectedFolder\" [value]=\"file.id\" (change)=\"onSelectFolder()\"  >&nbsp;\n\t\t\t<i class=\"fa fa-folder\" style=\"font-size: 30px;\"></i>\n      <span>{{file.name}}</span>\n\t\t</span>\n    <!--<span *ngIf=\"file.type == 'file'\" ><i class=\"far fa-file\" style=\"font-size: 30px;\"></i> {{file.name}}</span>-->\n  </ul>\n  <hr>\n  <pagination-controls [id]=\"config.id\"\n                       [maxSize]=\"maxSize\"\n                       [directionLinks]=\"directionLinks\"\n                       [autoHide]=\"autoHide\"\n                       [responsive]=\"responsive\"\n                       [previousLabel]=\"labels.previousLabel\"\n                       [nextLabel]=\"labels.nextLabel\"\n                       [screenReaderPaginationLabel]=\"labels.screenReaderPaginationLabel\"\n                       [screenReaderPageLabel]=\"labels.screenReaderPageLabel\"\n                       [screenReaderCurrentLabel]=\"labels.screenReaderCurrentLabel\"\n                       (pageChange)=\"onPageChange($event)\"></pagination-controls>\n\n\n</div>\n"

/***/ }),

/***/ "./src/app/components/file-manager/select-file-content/select-file-content.component.ts":
/*!**********************************************************************************************!*\
  !*** ./src/app/components/file-manager/select-file-content/select-file-content.component.ts ***!
  \**********************************************************************************************/
/*! exports provided: SelectFileContentComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SelectFileContentComponent", function() { return SelectFileContentComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_io_service_io_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../services/io-service/io.service */ "./src/app/services/io-service/io.service.ts");
/* harmony import */ var _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../services/helper-service/helper.service */ "./src/app/services/helper-service/helper.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var SelectFileContentComponent = /** @class */ (function () {
    function SelectFileContentComponent(helperService, router, ioService, route) {
        var _this = this;
        this.helperService = helperService;
        this.router = router;
        this.ioService = ioService;
        this.route = route;
        this.filter = '';
        this.maxSize = 7;
        this.directionLinks = true;
        this.autoHide = true;
        this.responsive = true;
        this.config = {
            id: 'advanced',
            itemsPerPage: 10,
            currentPage: 1
        };
        this.p = 1;
        this.labels = {
            previousLabel: 'Previous',
            nextLabel: 'Next',
            screenReaderPaginationLabel: 'Pagination',
            screenReaderPageLabel: 'page',
            screenReaderCurrentLabel: "You're on page"
        };
        this.route.params.forEach(function (params) {
            _this.assignmentId = Number.parseInt(params['id']);
        });
    }
    SelectFileContentComponent.prototype.onPageChange = function (number) {
        console.log('change to page', number);
        this.config.currentPage = number;
    };
    SelectFileContentComponent.prototype.onSelectFolder = function () {
        console.log(this.selectedFolder);
        this.helperService.selectedFolder = this.selectedFolder;
    };
    SelectFileContentComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.ioService.fileListStatus$.subscribe(function (fileList) {
            _this.fileList = fileList;
            console.log(_this.fileList);
        });
        this.helperService.selectedFolder$.subscribe(function (selectedFolder) {
            _this.selectedFolder = selectedFolder;
        });
    };
    SelectFileContentComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-select-file-content',
            template: __webpack_require__(/*! ./select-file-content.component.html */ "./src/app/components/file-manager/select-file-content/select-file-content.component.html"),
            styles: [__webpack_require__(/*! ./select-file-content.component.css */ "./src/app/components/file-manager/select-file-content/select-file-content.component.css")]
        }),
        __metadata("design:paramtypes", [_services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_2__["HelperService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _services_io_service_io_service__WEBPACK_IMPORTED_MODULE_1__["IoService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]])
    ], SelectFileContentComponent);
    return SelectFileContentComponent;
}());



/***/ }),

/***/ "./src/app/components/file-manager/select-file-nav/select-file-nav.component.css":
/*!***************************************************************************************!*\
  !*** ./src/app/components/file-manager/select-file-nav/select-file-nav.component.css ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".nav-font {\n\tcolor: white;\n}"

/***/ }),

/***/ "./src/app/components/file-manager/select-file-nav/select-file-nav.component.html":
/*!****************************************************************************************!*\
  !*** ./src/app/components/file-manager/select-file-nav/select-file-nav.component.html ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<nav class=\"navbar navbar-expand-lg navbar-light bg-secondary\" >\n  <a class=\"navbar-brand \" style=\"color:white;\">Select Image Folder for Patient</a>\n</nav>\n"

/***/ }),

/***/ "./src/app/components/file-manager/select-file-nav/select-file-nav.component.ts":
/*!**************************************************************************************!*\
  !*** ./src/app/components/file-manager/select-file-nav/select-file-nav.component.ts ***!
  \**************************************************************************************/
/*! exports provided: SelectFileNavComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SelectFileNavComponent", function() { return SelectFileNavComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var SelectFileNavComponent = /** @class */ (function () {
    function SelectFileNavComponent() {
    }
    SelectFileNavComponent.prototype.ngOnInit = function () {
    };
    SelectFileNavComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-select-file-nav',
            template: __webpack_require__(/*! ./select-file-nav.component.html */ "./src/app/components/file-manager/select-file-nav/select-file-nav.component.html"),
            styles: [__webpack_require__(/*! ./select-file-nav.component.css */ "./src/app/components/file-manager/select-file-nav/select-file-nav.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], SelectFileNavComponent);
    return SelectFileNavComponent;
}());



/***/ }),

/***/ "./src/app/components/file-manager/select-file.component.css":
/*!*******************************************************************!*\
  !*** ./src/app/components/file-manager/select-file.component.css ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".file-container {\n\twidth: 90%;\n\tmargin: auto;\n\tmargin-top: 50px;\n}\n\n.box {\n\tborder: 1px solid black;\n}\n\n.mycontent-right {\n  border-left: 1px dashed #333;\n}\n\n\n\n"

/***/ }),

/***/ "./src/app/components/file-manager/select-file.component.html":
/*!********************************************************************!*\
  !*** ./src/app/components/file-manager/select-file.component.html ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div>\n  <app-navbar></app-navbar>\n\n  <!-- Container for sidebar(s) + page content -->\n  <ng-sidebar-container style=\"height: 800px;\">\n    <!-- A sidebar -->\n    <ng-sidebar [(opened)]=\"_opened\">\n      <app-side-panel></app-side-panel>\n    </ng-sidebar>\n\n    <!-- Page content -->\n    <div ng-sidebar-content>\n      <div class=\"file-container\">\n        <simple-notifications></simple-notifications>\n        <app-select-file-nav></app-select-file-nav>\n        <br>\n        <div class=\"btn-group\" role=\"group\" aria-label=\"Basic example\">\n          <button class=\"btn btn-link\" (click)=\"expandAll()\">Expand All</button>\n          <button class=\"btn btn-link\" (click)=\"collapseAll()\">Collapse All</button>\n        </div>\n\n        <button type=\"button\" class=\"btn btn-outline-primary pull-right\" (click)=\"nextStep()\">\n          <span class=\"glyphicon glyphicon-upload\"></span> Next: Select Images\n        </button>\n\n        <div class=\"row\">\n          <div class=\"col-3\">\n            <div class=\"accordion\" id=\"accordion\">\n              <!--******************************* Patient 1 ***************************-->\n              <div class=\"card\">\n                <div class=\"card-header\" id=\"headingOne\">\n                  <h5 class=\"mb-0\">\n                    <button class=\"btn btn-link\" data-toggle=\"collapse\" data-target=\"#collapseOne\" aria-expanded=\"true\"\n                            aria-controls=\"collapseOne\">\n                      Patient 1\n                    </button>\n                  </h5>\n                </div>\n\n                <div id=\"collapseOne\" class=\"collapse show\" aria-labelledby=\"headingOne\" data-parent=\"#accordion\">\n                  <div class=\"card-body\">\n                    <div class=\"inner-container\">\n                      <div class=\"input-group\">\n                        <div class=\"input-group-prepend\">\n                          <span class=\"input-group-text\" id=\"basic-addon1\">Patient 1</span>\n                        </div>\n                        <input type=\"text\" class=\"form-control\" id=\"patientName1\" name=\"patientName1\"\n                               [(ngModel)]=\"patientName1\"/>\n                      </div>\n                    </div>\n                  </div>\n                </div>\n              </div>\n\n\n              <!--******************************* Patient 2 ***************************-->\n              <div class=\"card\">\n                <div class=\"card-header\" id=\"headingTwo\">\n                  <h5 class=\"mb-0\">\n                    <button class=\"btn btn-link collapsed\" data-toggle=\"collapse\" data-target=\"#collapseTwo\"\n                            aria-expanded=\"false\" aria-controls=\"collapseTwo\">\n                      Patient 2\n                    </button>\n                  </h5>\n                </div>\n                <div id=\"collapseTwo\" class=\"collapse show\" aria-labelledby=\"headingTwo\" data-parent=\"#accordion\">\n                  <div class=\"card-body\">\n                    <div class=\"inner-container\">\n                      <div class=\"input-group\">\n                        <div class=\"input-group-prepend\">\n                          <span class=\"input-group-text\" id=\"basic-addon2\">Patient 2</span>\n                        </div>\n                        <input type=\"text\" class=\"form-control\" id=\"patientName2\" name=\"patientName2\"\n                               [(ngModel)]=\"patientName2\"/>\n                      </div>\n\n                    </div>\n                  </div>\n                </div>\n              </div>\n\n\n              <!--******************************* Patient 3 ***************************-->\n              <div class=\"card\">\n                <div class=\"card-header\" id=\"headingThree\">\n                  <h5 class=\"mb-0\">\n                    <button class=\"btn btn-link collapsed\" data-toggle=\"collapse\" data-target=\"#collapseThree\"\n                            aria-expanded=\"false\" aria-controls=\"collapseThree\">\n                      Patient 3\n                    </button>\n                  </h5>\n                </div>\n                <div id=\"collapseThree\" class=\"collapse show\" aria-labelledby=\"headingThree\" data-parent=\"#accordion\">\n                  <div class=\"card-body\">\n                    <div class=\"inner-container\">\n                      <div class=\"input-group\">\n                        <div class=\"input-group-prepend\">\n                          <span class=\"input-group-text\" id=\"basic-addon3\">Patient 3</span>\n                        </div>\n                        <input type=\"text\" class=\"form-control\" id=\"patientName3\" name=\"patientName3\"\n                               [(ngModel)]=\"patientName3\"/>\n                      </div>\n\n                    </div>\n                  </div>\n                </div>\n              </div>\n\n\n              <!--******************************* Patient 4 ***************************-->\n              <div class=\"card\">\n                <div class=\"card-header\" id=\"headingFour\">\n                  <h5 class=\"mb-0\">\n                    <button class=\"btn btn-link collapsed\" data-toggle=\"collapse\" data-target=\"#collapseFour\"\n                            aria-expanded=\"false\" aria-controls=\"collapseFour\">\n                      Patient 4\n                    </button>\n                  </h5>\n                </div>\n                <div id=\"collapseFour\" class=\"collapse show\" aria-labelledby=\"headingFour\" data-parent=\"#accordion\">\n                  <div class=\"card-body\">\n                    <div class=\"inner-container\">\n                      <div class=\"input-group\">\n                        <div class=\"input-group-prepend\">\n                          <span class=\"input-group-text\" id=\"basic-addon4\">Patient 4</span>\n                        </div>\n                        <input type=\"text\" class=\"form-control\" id=\"patientName4\" name=\"patientName4\"\n                               [(ngModel)]=\"patientName4\"/>\n                      </div>\n\n                    </div>\n                  </div>\n                </div>\n              </div>\n\n\n              <!--******************************* Patient 5 ***************************-->\n              <div class=\"card\">\n                <div class=\"card-header\" id=\"headingFive\">\n                  <h5 class=\"mb-0\">\n                    <button class=\"btn btn-link collapsed\" data-toggle=\"collapse\" data-target=\"#collapseFive\"\n                            aria-expanded=\"false\" aria-controls=\"collapseFive\">\n                      Patient 5\n                    </button>\n                  </h5>\n                </div>\n                <div id=\"collapseFive\" class=\"collapse show\" aria-labelledby=\"headingFive\" data-parent=\"#accordion\">\n                  <div class=\"card-body\">\n                    <div class=\"inner-container\">\n                      <div class=\"input-group\">\n                        <div class=\"input-group-prepend\">\n                          <span class=\"input-group-text\" id=\"basic-addon5\">Patient 5</span>\n                        </div>\n                        <input type=\"text\" class=\"form-control\" id=\"patientName5\" name=\"patientName4\"\n                               [(ngModel)]=\"patientName5\"/>\n                      </div>\n\n                    </div>\n                  </div>\n                </div>\n              </div>\n            </div>\n          </div>\n          <div class=\"col-9\">\n            <h4>Select Image Folder for</h4>\n            <select class=\"form-control\" style=\"max-width: 400px;\" name=\"currentPatient\" [(ngModel)]=\"currentPatient\"\n                    (change)=\"onSelectPatient()\">\n              <option [value]=\"1\" [selected]=\"currentPatient == 1\">Patient 1</option>\n              <option [value]=\"2\" [selected]=\"currentPatient == 2\">Patient 2</option>\n              <option [value]=\"3\" [selected]=\"currentPatient == 3\">Patient 3</option>\n              <option [value]=\"4\" [selected]=\"currentPatient == 4\">Patient 4</option>\n              <option [value]=\"5\" [selected]=\"currentPatient == 5\">Patient 5</option>\n            </select>\n            <hr>\n            <div class=\"row\">\n              <div class=\"col-4\">\n                <div>\n                  <app-file-manager-tree></app-file-manager-tree>\n                </div>\n              </div>\n              <div class=\"col-8\">\n                <div class=\"mycontent-right\">\n                  <app-select-file-content></app-select-file-content>\n                </div>\n              </div>\n            </div>\n          </div>\n        </div>\n\n\n        <br>\n\n\n      </div>\n    </div>\n  </ng-sidebar-container>\n\n\n</div>\n"

/***/ }),

/***/ "./src/app/components/file-manager/select-file.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/components/file-manager/select-file.component.ts ***!
  \******************************************************************/
/*! exports provided: SelectFileComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SelectFileComponent", function() { return SelectFileComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../services/helper-service/helper.service */ "./src/app/services/helper-service/helper.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_assignment_service_assignment_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/assignment-service/assignment.service */ "./src/app/services/assignment-service/assignment.service.ts");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var angular2_notifications__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! angular2-notifications */ "./node_modules/angular2-notifications/angular2-notifications.umd.js");
/* harmony import */ var angular2_notifications__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(angular2_notifications__WEBPACK_IMPORTED_MODULE_5__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var SelectFileComponent = /** @class */ (function () {
    function SelectFileComponent(helperService, router, assignmentService, route, notificationService) {
        var _this = this;
        this.helperService = helperService;
        this.router = router;
        this.assignmentService = assignmentService;
        this.route = route;
        this.notificationService = notificationService;
        this._opened = false;
        this.currentPatient = 1;
        this.folderList = [];
        this.missingFolder = false;
        this.route.params.forEach(function (params) {
            _this.assignmentId = Number.parseInt(params['id']);
        });
    }
    SelectFileComponent.prototype.expandAll = function () {
        jquery__WEBPACK_IMPORTED_MODULE_4__('.collapse').addClass('collapse show');
    };
    SelectFileComponent.prototype.collapseAll = function () {
        jquery__WEBPACK_IMPORTED_MODULE_4__('.collapse').removeClass('show');
    };
    SelectFileComponent.prototype.nextStep = function () {
        var _this = this;
        if ((this.patientName1 != null && this.folderId1 == null) ||
            (this.patientName2 != null && this.folderId2 == null) ||
            (this.patientName3 != null && this.folderId3 == null) ||
            (this.patientName4 != null && this.folderId4 == null) ||
            (this.patientName5 != null && this.folderId5 == null)) {
            this.missingFolder = true;
            var content = 'There is patient without image folder.';
            this.create(content);
        }
        else {
            this.missingFolder = false;
            var itemList = [
                { 'patientName': this.patientName1, 'folderId': this.folderId1 },
                { 'patientName': this.patientName2, 'folderId': this.folderId2 },
                { 'patientName': this.patientName3, 'folderId': this.folderId3 },
                { 'patientName': this.patientName4, 'folderId': this.folderId4 },
                { 'patientName': this.patientName5, 'folderId': this.folderId5 }
            ];
            this.assignmentService.selectAssignmentPatientFolder(this.assignmentId, itemList).subscribe(function (res) {
                _this.router.navigate(['/selectImages'], { queryParams: { assignmentId: _this.assignmentId } });
            }, function (error) {
                console.log(error);
            });
        }
    };
    SelectFileComponent.prototype.create = function (content) {
        var title = 'Oops. Not yet.';
        var type = 'warn';
        this.notificationService.create(title, content, type, {
            timeOut: 15000,
            showProgressBar: true,
            pauseOnHover: true,
            position: ['top', 'left']
        });
    };
    SelectFileComponent.prototype.onSelectPatient = function () {
        console.log(this.currentPatient);
        if (this.currentPatient == 1) {
            this.selectedFolder = this.folderId1;
        }
        if (this.currentPatient == 2) {
            this.selectedFolder = this.folderId2;
        }
        if (this.currentPatient == 3) {
            this.selectedFolder = this.folderId3;
        }
        if (this.currentPatient == 4) {
            this.selectedFolder = this.folderId4;
        }
        if (this.currentPatient == 5) {
            this.selectedFolder = this.folderId5;
        }
        this.helperService.selectedFolder = this.selectedFolder;
    };
    SelectFileComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.helperService.sideMenuStatus$.subscribe(function (open) {
            console.log(open);
            _this._opened = open;
        });
        this.helperService.selectedFolder$.subscribe(function (selectedFolder) {
            _this.selectedFolder = selectedFolder;
            console.log(_this.selectedFolder);
            if (_this.currentPatient == 1) {
                _this.folderId1 = _this.selectedFolder;
            }
            if (_this.currentPatient == 2) {
                _this.folderId2 = _this.selectedFolder;
            }
            if (_this.currentPatient == 3) {
                _this.folderId3 = _this.selectedFolder;
            }
            if (_this.currentPatient == 4) {
                _this.folderId4 = _this.selectedFolder;
            }
            if (_this.currentPatient == 5) {
                _this.folderId5 = _this.selectedFolder;
            }
        });
    };
    SelectFileComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-select-file',
            template: __webpack_require__(/*! ./select-file.component.html */ "./src/app/components/file-manager/select-file.component.html"),
            styles: [__webpack_require__(/*! ./select-file.component.css */ "./src/app/components/file-manager/select-file.component.css")]
        }),
        __metadata("design:paramtypes", [_services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_1__["HelperService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _services_assignment_service_assignment_service__WEBPACK_IMPORTED_MODULE_3__["AssignmentService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], angular2_notifications__WEBPACK_IMPORTED_MODULE_5__["NotificationsService"]])
    ], SelectFileComponent);
    return SelectFileComponent;
}());



/***/ }),

/***/ "./src/app/components/forget-password/forget-password.component.css":
/*!**************************************************************************!*\
  !*** ./src/app/components/forget-password/forget-password.component.css ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".form-gap {\n    padding-top: 100px;\n}"

/***/ }),

/***/ "./src/app/components/forget-password/forget-password.component.html":
/*!***************************************************************************!*\
  !*** ./src/app/components/forget-password/forget-password.component.html ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"form-gap\">\n</div>\n<div class=\"container\">\n  <div class=\"row\">\n    <div class=\"col-4\"></div>\n    <div class=\"col-4\">\n      <div class=\"panel panel-default\">\n        <div class=\"panel-body\">\n          <div class=\"text-center\">\n            <h3>\n              <i class=\"fa fa-lock fa-4x\"></i>\n            </h3>\n            <h2 class=\"text-center\">Forgot Password?</h2>\n            <p>You can reset your password here.</p>\n            <div class=\"panel-body\">\n\n              <form id=\"register-form\" role=\"form\" autocomplete=\"off\" class=\"form\" method=\"post\">\n\n                <div class=\"form-group\">\n                  <div class=\"input-group\">\n                    <span class=\"input-group-addon\">\n                      <i class=\"glyphicon glyphicon-envelope color-blue\"></i>\n                    </span>\n                    <input id=\"email\" name=\"email\" placeholder=\"email address\" class=\"form-control\" type=\"email\">\n                  </div>\n                </div>\n                <div class=\"form-group\">\n                  <input name=\"recover-submit\" class=\"btn btn-lg btn-dark btn-block\" value=\"Reset Password\" type=\"submit\">\n                </div>\n                <div class=\"form-group\">\n                  <input name=\"recover-cancel\" class=\"btn btn-lg btn-light btn-block\" value=\"Cancel\" type=\"submit\" (click)=\"cancelRecover()\">\n                </div>\n                <input type=\"hidden\" class=\"hide\" name=\"token\" id=\"token\" value=\"\">\n              </form>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n  <div class=\"col-4\"></div>\n</div>"

/***/ }),

/***/ "./src/app/components/forget-password/forget-password.component.ts":
/*!*************************************************************************!*\
  !*** ./src/app/components/forget-password/forget-password.component.ts ***!
  \*************************************************************************/
/*! exports provided: ForgetPasswordComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ForgetPasswordComponent", function() { return ForgetPasswordComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var ForgetPasswordComponent = /** @class */ (function () {
    function ForgetPasswordComponent(router) {
        this.router = router;
    }
    ForgetPasswordComponent.prototype.cancelRecover = function () {
        this.router.navigate(['/login']);
    };
    ForgetPasswordComponent.prototype.ngOnInit = function () {
    };
    ForgetPasswordComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-forget-password',
            template: __webpack_require__(/*! ./forget-password.component.html */ "./src/app/components/forget-password/forget-password.component.html"),
            styles: [__webpack_require__(/*! ./forget-password.component.css */ "./src/app/components/forget-password/forget-password.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]])
    ], ForgetPasswordComponent);
    return ForgetPasswordComponent;
}());



/***/ }),

/***/ "./src/app/components/home/home.component.css":
/*!****************************************************!*\
  !*** ./src/app/components/home/home.component.css ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".main {\n\twidth: 95% !important; \n\tmargin: auto;\n}\n\n"

/***/ }),

/***/ "./src/app/components/home/home.component.html":
/*!*****************************************************!*\
  !*** ./src/app/components/home/home.component.html ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div *ngIf=\"!loading\">\n  <app-navbar></app-navbar>\n\n  <!-- Container for sidebar(s) + page content -->\n  <ng-sidebar-container style=\"height: 800px;\">\n    <!-- A sidebar -->\n    <ng-sidebar [(opened)]=\"_opened\">\n      <app-side-panel></app-side-panel>\n    </ng-sidebar>\n\n    <!-- Page content -->\n    <div ng-sidebar-content>\n      <div class=\"main\">\n        <div class=\"row\">\n          <div id=\"mid-panel\" class=\"col-10\" style=\"border:1px solid black;\">\n            <app-annotation-panel [imageUrl]=\"imageUrl\" [taskList]=\"taskList\" [assignmentItemId]=\"assignmentItemId\"></app-annotation-panel>\n          </div>\n          <div id=\"right-panel\" class=\"col-2\" style=\"border:1px solid black;\">\n            <!--<app-info-panel (updateStatus)=\"onGetTaskListByUser()\" [patientList]=\"patientList\"></app-info-panel>-->\n            <app-info-panel  [patientList]=\"patientList\"></app-info-panel>\n\n          </div>\n        </div>\n      </div>\n    </div>\n\n  </ng-sidebar-container>\n\n\n</div>\n<div *ngIf=\"loading\" class=\"text-center\" style=\"margin:150px 200px 0 200px\">\n  <i class=\"fa fa-spinner fa-5x faa-spin animated\"></i>\n</div>\n"

/***/ }),

/***/ "./src/app/components/home/home.component.ts":
/*!***************************************************!*\
  !*** ./src/app/components/home/home.component.ts ***!
  \***************************************************/
/*! exports provided: HomeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeComponent", function() { return HomeComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/animations */ "./node_modules/@angular/animations/fesm5/animations.js");
/* harmony import */ var _app_const__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../app-const */ "./src/app/app-const.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_login_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/login.service */ "./src/app/services/login.service.ts");
/* harmony import */ var _services_image_service_image_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/image-service/image.service */ "./src/app/services/image-service/image.service.ts");
/* harmony import */ var _services_task_service_task_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../services/task-service/task.service */ "./src/app/services/task-service/task.service.ts");
/* harmony import */ var _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../services/helper-service/helper.service */ "./src/app/services/helper-service/helper.service.ts");
/* harmony import */ var _services_patient_service_patient_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../services/patient-service/patient.service */ "./src/app/services/patient-service/patient.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};









var HomeComponent = /** @class */ (function () {
    function HomeComponent(loginService, imageService, taskService, helperService, patientService, route, router) {
        var _this = this;
        this.loginService = loginService;
        this.imageService = imageService;
        this.taskService = taskService;
        this.helperService = helperService;
        this.patientService = patientService;
        this.route = route;
        this.router = router;
        this.serverPath = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath;
        this.loggedIn = false;
        this.displaySideNav = true;
        this.patientList = [];
        this.taskList = [];
        this.assignmentItemId = 12;
        this.loading = true;
        this._opened = false;
        this.route.params.forEach(function (params) {
            _this.assignmentItemId = Number.parseInt(params['assignmentItemId']);
        });
    }
    HomeComponent.prototype._toggleSidebar = function () {
        this._opened = !this._opened;
    };
    HomeComponent.prototype.toggleDisplay = function () {
        this.leftPanel = document.getElementById('left-panel');
        this.midPanel = document.getElementById('mid-panel');
        this.rightPanel = document.getElementById('right-panel');
        this.displaySideNav = !this.displaySideNav;
        if (this.displaySideNav) {
            this.displaySidePanel();
        }
        else {
            this.hideSidePanel();
        }
    };
    HomeComponent.prototype.displaySidePanel = function () {
        this.midPanel.className = "col-8";
        this.rightPanel.className = "col-2";
    };
    HomeComponent.prototype.hideSidePanel = function () {
        this.midPanel.className = "col-10";
        this.rightPanel.className = "col-2";
    };
    HomeComponent.prototype.onLogout = function () {
        var _this = this;
        this.loginService.logout().subscribe(function (res) {
            console.log(res.text());
            _this.loggedIn = false;
            _this.router.navigate(['/login']);
        }, function (error) {
            _this.loggedIn = true;
        });
    };
    HomeComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.taskType = this.taskService.onTaskType;
        this.patientService.getPatientsByAssignmentItem(this.assignmentItemId).subscribe(function (res) {
            console.log(res.json());
            _this.patientList = res.json();
            _this.loading = false;
        }, function (error) {
            console.log(error);
        });
        this.helperService.sideMenuStatus$.subscribe(function (open) {
            console.log(open);
            _this._opened = open;
        });
    };
    HomeComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-home',
            template: __webpack_require__(/*! ./home.component.html */ "./src/app/components/home/home.component.html"),
            styles: [__webpack_require__(/*! ./home.component.css */ "./src/app/components/home/home.component.css")],
            animations: [
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["trigger"])('displaySideNav', [
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["state"])('true', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({})),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["state"])('false', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({
                        transform: 'scaleX(0) translateX(-100%)', display: 'none'
                    })),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])('true => false', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])('400ms 0.5s ease-out')),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])('false => true', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])('400ms 0.5s ease-out'))
                ])
            ]
        }),
        __metadata("design:paramtypes", [_services_login_service__WEBPACK_IMPORTED_MODULE_4__["LoginService"],
            _services_image_service_image_service__WEBPACK_IMPORTED_MODULE_5__["ImageService"],
            _services_task_service_task_service__WEBPACK_IMPORTED_MODULE_6__["TaskService"],
            _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_7__["HelperService"],
            _services_patient_service_patient_service__WEBPACK_IMPORTED_MODULE_8__["PatientService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]])
    ], HomeComponent);
    return HomeComponent;
}());



/***/ }),

/***/ "./src/app/components/info-panel/info-panel.component.css":
/*!****************************************************************!*\
  !*** ./src/app/components/info-panel/info-panel.component.css ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/info-panel/info-panel.component.html":
/*!*****************************************************************!*\
  !*** ./src/app/components/info-panel/info-panel.component.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div style=\"margin-top: 20px;\">\n  <form (ngSubmit)=\"saveTaskDescription()\">\n    <h5>Patient</h5>\n    <select class=\"form-control\" name=\"currentPatient\" [(ngModel)]=\"currentPatient\" (change)=\"setCurrentPatient()\">\n      <option value=\"null\" disabled>Select a patient</option>\n      <option *ngFor=\"let patient of patientList\" [ngValue]=\"patient\">{{patient.name}}</option>\n    </select>\n    <hr>\n    <div style=\"margin-top: 10px;\">\n      <div class=\"form-group\">\n        <label>Status</label><br>\n        <div class=\"btn-group\" role=\"group\" aria-label=\"...\">\n          <button type=\"button\" class=\"btn btn-outline-dark\" [ngClass]=\"{'active': taskStatus==0}\" (click)=\"setStatus(0)\">New</button>\n          <button type=\"button\" class=\"btn btn-outline-dark\" [ngClass]=\"{'active': taskStatus==1}\" (click)=\"setStatus(1)\">Changed</button>\n          <button type=\"button\" class=\"btn btn-outline-dark\" [ngClass]=\"{'active': taskStatus==2}\" (click)=\"setStatus(2)\">Done</button>\n        </div>\n\n      </div>\n      <!--<div *ngIf=\"statusChanged\" class=\"alert alert-success\">Status updated.</div>-->\n    </div>\n    <hr>\n    <h6>Tags</h6>\n    <a *ngFor=\"let tag of tagList\" class=\"badge badge-pill badge-light\" style=\"cursor: pointer;\"\n       (click)=\"selectTag(tag)\">{{tag}}</a>\n    <br><br>\n    <div class=\"form-group\">\n      <input class=\"form-control\" [(ngModel)]=\"currentTag\" name=\"tag\" value=\"currentTag\" disabled>\n    </div>\n    <hr>\n    <h6>Image Description</h6>\n    <p>*description for the image</p>\n    <div class=\"form-group\">\n      <textarea class=\"form-control\" aria-label=\"With textarea\" [(ngModel)]=\"taskDescription\" name=\"taskDescription\"\n                value=\"taskDescription\"></textarea>\n    </div>\n    <button type=\"submit\" class=\"btn btn-dark btn-sm\">Save</button>\n    <br>\n    <br>\n    <div *ngIf=\"taskDescriptionSaved\" class=\"alert alert-success\">Image description saved.</div>\n    <div *ngIf=\"emptyTaskDescription\" class=\"alert alert-danger\">Image description can't be empty.</div>\n  </form>\n  <hr>\n  <form (ngSubmit)=\"saveLabelDescription()\">\n    <h6>Label Description</h6>\n    <p>*description for the selected label</p>\n    <div class=\"form-group\">\n      <textarea class=\"form-control\" aria-label=\"With textarea\" [(ngModel)]=\"currentDescription\" name=\"description\"\n                value=\"currentDescription\"></textarea>\n    </div>\n    <button type=\"submit\" class=\"btn btn-dark btn-sm\">Save</button>\n    <br>\n    <br>\n    <div *ngIf=\"descriptionSaved\" class=\"alert alert-success\">Description saved.</div>\n    <div *ngIf=\"emptyDescription\" class=\"alert alert-danger\">Description can't be empty.</div>\n  </form>\n</div>\n<hr>\n"

/***/ }),

/***/ "./src/app/components/info-panel/info-panel.component.ts":
/*!***************************************************************!*\
  !*** ./src/app/components/info-panel/info-panel.component.ts ***!
  \***************************************************************/
/*! exports provided: InfoPanelComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InfoPanelComponent", function() { return InfoPanelComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_image_service_image_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../services/image-service/image.service */ "./src/app/services/image-service/image.service.ts");
/* harmony import */ var _services_task_service_task_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/task-service/task.service */ "./src/app/services/task-service/task.service.ts");
/* harmony import */ var _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/helper-service/helper.service */ "./src/app/services/helper-service/helper.service.ts");
/* harmony import */ var angular2_hotkeys__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! angular2-hotkeys */ "./node_modules/angular2-hotkeys/index.js");
/* harmony import */ var angular2_hotkeys__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(angular2_hotkeys__WEBPACK_IMPORTED_MODULE_4__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var InfoPanelComponent = /** @class */ (function () {
    function InfoPanelComponent(imageService, taskService, helperService, _hotkeysService) {
        var _this = this;
        this.imageService = imageService;
        this.taskService = taskService;
        this.helperService = helperService;
        this._hotkeysService = _hotkeysService;
        this.updateStatus = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.currentDescription = '';
        this.descriptionSaved = false;
        this.emptyDescription = false;
        this.statusChanged = false;
        this.taskDescriptionSaved = false;
        this.emptyTaskDescription = false;
        this.tagList = [];
        this.statusHandMarkedTaskList = {};
        this._hotkeysService.add(new angular2_hotkeys__WEBPACK_IMPORTED_MODULE_4__["Hotkey"]('d', function (event) {
            _this.setStatus(2);
            return false; // Prevent bubbling
        }));
    }
    InfoPanelComponent.prototype.selectTag = function (tag) {
        this.currentTag = tag;
        this.imageService.newDescription = {
            'description': this.currentDescription,
            'index': this.currentLabelIndex,
            'type': this.currentLabelType
        };
        this.helperService.tag = {
            'tag': tag,
            'index': this.currentLabelIndex,
            'type': this.currentLabelType
        };
    };
    InfoPanelComponent.prototype.setStatus = function (status) {
        var _this = this;
        this.statusHandMarkedTaskList[this.taskId] = true;
        console.log(this.statusHandMarkedTaskList);
        this.taskStatus = status;
        var that = this;
        this.statusChanged = true;
        setTimeout(function () {
            that.statusChanged = false;
        }.bind(this), 3000);
        var task = {
            'id': this.taskId,
            'status': this.taskStatus
        };
        this.taskService.setTaskStatus(task).subscribe(function (res) {
            console.log(res);
            _this.updateStatus.emit(null);
            _this.taskService.taskStatus = _this.taskId;
        });
    };
    InfoPanelComponent.prototype.saveTaskDescription = function () {
        var that = this;
        if (this.taskDescription != null && this.taskDescription != '') {
            this.taskService.onNewTaskDescription = {
                'taskDescription': this.taskDescription
            };
            this.taskDescriptionSaved = true;
            setTimeout(function () {
                that.taskDescriptionSaved = false;
            }.bind(this), 3000);
        }
        else {
            this.emptyTaskDescription = true;
            setTimeout(function () {
                that.emptyTaskDescription = false;
            }.bind(this), 3000);
        }
    };
    InfoPanelComponent.prototype.saveLabelDescription = function () {
        var that = this;
        if (this.currentDescription != null && this.currentDescription != '') {
            this.emptyDescription = false;
            this.imageService.newDescription = {
                'description': this.currentDescription,
                'index': this.currentLabelIndex,
                'type': this.currentLabelType
            };
            this.descriptionSaved = true;
            setTimeout(function () {
                that.descriptionSaved = false;
            }.bind(this), 3000);
        }
        else {
            this.emptyDescription = true;
            setTimeout(function () {
                that.emptyDescription = false;
            }.bind(this), 3000);
        }
    };
    InfoPanelComponent.prototype.setCurrentPatient = function () {
        console.log(this.currentPatient);
        this.imageService.patient = this.currentPatient;
    };
    InfoPanelComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.imageService.currentDescriptionObject$.subscribe(function (object) {
            _this.descriptionSaved = false;
            _this.currentDescription = object['description'];
            _this.currentLabelIndex = object['index'];
            _this.currentLabelType = object['type'];
            console.log(_this.currentDescription, _this.currentLabelIndex, _this.currentLabelType);
        });
        this.imageService.currentTaskStatus$.subscribe(function (object) {
            _this.taskStatus = object['status'];
            _this.taskId = object['id'];
        });
        this.taskService.taskDescription$.subscribe(function (object) {
            _this.taskDescription = object['taskDescription'];
            console.log(_this.taskDescription);
        });
        this.helperService.tag$.subscribe(function (object) {
            _this.currentTag = object['tag'];
        });
        this.helperService.tagList$.subscribe(function (tagList) {
            _this.tagList = Object.keys(tagList).map(function (personNamedIndex) {
                var tag = tagList[personNamedIndex];
                return tag;
            });
            console.log(_this.tagList);
        });
        this.helperService.onSwitchImage$.subscribe(function (previousTask) {
            console.log(previousTask);
            console.log(_this.statusHandMarkedTaskList[previousTask.id + '']);
            if ((previousTask != null && previousTask != undefined) && !_this.statusHandMarkedTaskList[previousTask.id]) {
                var task = {
                    'id': previousTask.id,
                    'status': 2
                };
                _this.taskService.setTaskStatus(task).subscribe(function (res) {
                    _this.updateStatus.emit(null);
                    _this.taskService.previousTaskStatus = previousTask.id;
                });
            }
        });
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", Object)
    ], InfoPanelComponent.prototype, "updateStatus", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])('patientList'),
        __metadata("design:type", Object)
    ], InfoPanelComponent.prototype, "patientList", void 0);
    InfoPanelComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-info-panel',
            template: __webpack_require__(/*! ./info-panel.component.html */ "./src/app/components/info-panel/info-panel.component.html"),
            styles: [__webpack_require__(/*! ./info-panel.component.css */ "./src/app/components/info-panel/info-panel.component.css")]
        }),
        __metadata("design:paramtypes", [_services_image_service_image_service__WEBPACK_IMPORTED_MODULE_1__["ImageService"], _services_task_service_task_service__WEBPACK_IMPORTED_MODULE_2__["TaskService"], _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_3__["HelperService"], angular2_hotkeys__WEBPACK_IMPORTED_MODULE_4__["HotkeysService"]])
    ], InfoPanelComponent);
    return InfoPanelComponent;
}());



/***/ }),

/***/ "./src/app/components/login/login.component.css":
/*!******************************************************!*\
  !*** ./src/app/components/login/login.component.css ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/*body {*/\n    /*background-image: url(\"../../../assets/images/pikachu.jpg\");*/\n    /*background-size: cover;*/\n    /*background-repeat: no-repeat;*/\n    /*background-position: center; */\n    /*background-color: #cccccc;*/\n    /*min-height: 100%;*/\n    /*min-width: 1024px;*/\n    /*width: 100%;*/\n    /*height: auto;*/\n    /*position:fixed;*/\n    /*top:0;*/\n    /*left:0;*/\n    /*}*/\n    /*label {*/\n    /*color: #F5EFEE;*/\n    /*}*/\n    .input {\n\n    position: fixed;\n    max-width: 500px;\n    height: 30%;\n    top: 50%;\n    left: 38%;\n\n}\n\n"

/***/ }),

/***/ "./src/app/components/login/login.component.html":
/*!*******************************************************!*\
  !*** ./src/app/components/login/login.component.html ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<body>\n  <div class=\"bg-image\"></div>\n\n\t<div *ngIf=\"!busy\" class=\"input\" style=\"margin-top:-200px;\">\n    <div class=\"text-center\" style=\" margin-bottom: 20px;\">\n      <h3>Welcome to Our Secret World!</h3>\n      <br>\n      <h5 class=\"text-center\">Please login. </h5>\n    </div>\n\t\t<div *ngIf=\"loginError\" style=\"color:red;\">Incorrect username or password.</div>\n\t\t<form (ngSubmit)=\"onLogin()\">\n\t\t\t<div class=\"form-group\">\n\t\t\t\t<label for=\"username\">Username *</label>\n\t\t\t\t<input type=\"text\" class=\"form-control\" id=\"username\" name=\"username\" [(ngModel)]=\"credential.username\" required=\"required\"\n\t\t\t\t autofocus=\"autofocus\" />\n\t\t\t</div>\n\t\t\t<div class=\"form-group\">\n\t\t\t\t<label for=\"password\">Password *</label>\n\t\t\t\t<input type=\"password\" class=\"form-control\" id=\"password\" name=\"password\" [(ngModel)]=\"credential.password\" required=\"required\"\n\t\t\t\t/>\n\n\t\t\t</div>\n\t\t\t<button type=\"submit\" class=\"btn btn-dark btn-block\">Log in</button>\n\t\t</form>\n\n    <!--<hr>-->\n\t\t<!--<div>-->\n\t\t\t<!--<a routerLink=\"/forgetPassword\" routerLinkActive=\"active\">-->\n\t\t\t\t<!--<span style=\"font-size: 1.2em;color: gainsboro;\">Forgot Password</span>-->\n\t\t\t<!--</a>-->\n\t\t<!--</div>-->\n\t</div>\n\n\t<div *ngIf=\"busy\" class=\"text-center\" style=\"margin: 100px 0px 0 0px\">\n\t\t<i class=\"fa fa-spinner fa-5x faa-spin animated\"></i>\n\t</div>\n\n\n</body>\n"

/***/ }),

/***/ "./src/app/components/login/login.component.ts":
/*!*****************************************************!*\
  !*** ./src/app/components/login/login.component.ts ***!
  \*****************************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _app_const__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../app-const */ "./src/app/app-const.ts");
/* harmony import */ var _services_login_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/login.service */ "./src/app/services/login.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var LoginComponent = /** @class */ (function () {
    function LoginComponent(loginService, router) {
        this.loginService = loginService;
        this.router = router;
        this.busy = false;
        this.serverPath = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath;
        this.loginError = false;
        this.loggedIn = false;
        this.credential = { 'username': '', 'password': '' };
        this.emailSent = false;
        this.usernameExists = false;
        this.emailExists = false;
        this.emailNotExists = false;
        this.forgetPasswordEmailSent = false;
    }
    LoginComponent.prototype.onLogin = function () {
        var _this = this;
        this.busy = true;
        if (this.credential.username.trim() == "" || this.credential.password.trim() == "") {
            this.busy = false;
            this.loggedIn = false;
            this.loginError = true;
        }
        else {
            this.loginService.sendCredential(this.credential.username, this.credential.password).subscribe(function (res) {
                var user = res.json();
                console.log(user);
                _this.loggedIn = true;
                var role = user.role[0].authority;
                if (role == 'ROLE_USER') {
                    _this.router.navigate(['/dashboard']);
                }
                if (role == 'ROLE_ADMIN') {
                    _this.router.navigate(['/adminDashboard']);
                }
            }, function (error) {
                _this.busy = false;
                _this.loggedIn = false;
                _this.loginError = true;
            });
        }
    };
    LoginComponent.prototype.onCheckSession = function () {
        var _this = this;
        this.loginService.checkSession().subscribe(function (res) {
            var user = res.json();
            _this.loggedIn = true;
            var role = user.authorities[0].authority;
            if (role == "ROLE_USER") {
                _this.router.navigate(['/dashboard']);
            }
            if (role == "ROLE_ADMIN") {
                _this.router.navigate(['/adminDashboard']);
            }
            _this.busy = false;
        }, function (error) {
            _this.busy = false;
        });
    };
    // onForgetPassword() {
    //   this.forgetPasswordEmailSent = false;
    //   this.emailNotExists = false;
    //   this.userService.retrievePassword(this.recoverEmail).subscribe(
    //     res => {
    //       console.log(res);
    //       this.emailSent = true;
    //     },
    //     error => {
    //       console.log(error.text());
    //       let errorMessage=error.text();
    //       if (errorMessage==="usernameExists") this.usernameExists=true;
    //       if (errorMessage==="emailExists") this.emailExists=true;
    //     }
    //   );
    // }
    LoginComponent.prototype.ngOnInit = function () {
        this.busy = true;
        this.onCheckSession();
    };
    LoginComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-login',
            template: __webpack_require__(/*! ./login.component.html */ "./src/app/components/login/login.component.html"),
            styles: [__webpack_require__(/*! ./login.component.css */ "./src/app/components/login/login.component.css")]
        }),
        __metadata("design:paramtypes", [_services_login_service__WEBPACK_IMPORTED_MODULE_3__["LoginService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]])
    ], LoginComponent);
    return LoginComponent;
}());



/***/ }),

/***/ "./src/app/components/navbar/navbar.component.css":
/*!********************************************************!*\
  !*** ./src/app/components/navbar/navbar.component.css ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".spin:hover {\n    -webkit-animation: fa-spin 2s infinite linear;\n    animation: fa-spin 2s infinite linear;\n  }\n  \n  .side-container {\n    background-color: white; \n    border:2px solid black;\n    width: 200px;\n    height:800px;\n  }"

/***/ }),

/***/ "./src/app/components/navbar/navbar.component.html":
/*!*********************************************************!*\
  !*** ./src/app/components/navbar/navbar.component.html ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<nav class=\"navbar navbar-expand-lg navbar-dark bg-dark \">\n  <span style=\"cursor: pointer; color: aliceblue;\" class=\"text-center\" (click)=\"_toggleSidebar()\">\n    <i class=\"fa fa-align-justify fa-lg\"></i>&nbsp;&nbsp;\n    <span *ngIf=\"displaySideNav\">MENU</span>\n  <span class=\"navbar-brand mb-0 h1\">AI &amp; Orthopaedics</span>\n  </span>\n  <ul class=\"navbar-nav mr-auto\">\n    <li class=\"nav-item\" style=\"font-weight: bolder;\">\n      <a *ngIf=\"adminView\" id=\"admin-dashboard\" class=\"nav-link\" routerLink=\"/adminDashboard\" routerLinkActive=\"active\">Dashboard</a>\n    </li>\n    <li class=\"nav-item\">\n      <a *ngIf=\"userView\" class=\"nav-link\" routerLink=\"/dashboard\" routerLinkActive=\"active\">Dashboard</a>\n      <a *ngIf=\"adminView\" id=\"admin-panel\" class=\"nav-link\" routerLink=\"/adminPanel\">Admin Panel</a>\n    </li>\n    <li class=\"nav-item\">\n      <a *ngIf=\"adminView\" class=\"nav-link\" routerLink=\"/fileManager\" routerLinkActive=\"active\">File Manager</a>\n    </li>\n  </ul>\n\n  <!--<form class=\"form-inline\">-->\n    <!--<button class=\"btn btn-outline-success my-2 my-sm-0\" type=\"submit\">Search</button>-->\n  <!--</form>-->\n</nav>\n\n"

/***/ }),

/***/ "./src/app/components/navbar/navbar.component.ts":
/*!*******************************************************!*\
  !*** ./src/app/components/navbar/navbar.component.ts ***!
  \*******************************************************/
/*! exports provided: NavbarComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NavbarComponent", function() { return NavbarComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _app_const__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../app-const */ "./src/app/app-const.ts");
/* harmony import */ var _services_login_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/login.service */ "./src/app/services/login.service.ts");
/* harmony import */ var _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/helper-service/helper.service */ "./src/app/services/helper-service/helper.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var NavbarComponent = /** @class */ (function () {
    function NavbarComponent(helperService, loginService) {
        this.helperService = helperService;
        this.loginService = loginService;
        this.serverPath = _app_const__WEBPACK_IMPORTED_MODULE_1__["AppConst"].serverPath;
        this.loading = true;
        this._opened = false;
    }
    NavbarComponent.prototype._toggleSidebar = function () {
        this._opened = !this._opened;
        this.helperService.sideMenu = this._opened;
    };
    NavbarComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.helperService.clickAdminPanel$.subscribe(function (click) {
            if (click) {
                document.getElementById('admin-panel').click();
                console.log('admin panel triggered');
            }
        });
        this.loginService.checkSession().subscribe(function (res) {
            var user = res.json();
            var role = user.authorities[0].authority;
            if (role == "ROLE_USER") {
                _this.userView = true;
                _this.adminView = false;
            }
            if (role == "ROLE_ADMIN") {
                _this.userView = false;
                _this.adminView = true;
            }
        });
    };
    NavbarComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-navbar',
            template: __webpack_require__(/*! ./navbar.component.html */ "./src/app/components/navbar/navbar.component.html"),
            styles: [__webpack_require__(/*! ./navbar.component.css */ "./src/app/components/navbar/navbar.component.css")]
        }),
        __metadata("design:paramtypes", [_services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_3__["HelperService"], _services_login_service__WEBPACK_IMPORTED_MODULE_2__["LoginService"]])
    ], NavbarComponent);
    return NavbarComponent;
}());



/***/ }),

/***/ "./src/app/components/segment-panel/segment-panel.component.css":
/*!**********************************************************************!*\
  !*** ./src/app/components/segment-panel/segment-panel.component.css ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".main-container {\n  margin-top: 10px;\n  margin-left: 30px;\n  margin-right: 30px;\n}\n"

/***/ }),

/***/ "./src/app/components/segment-panel/segment-panel.component.html":
/*!***********************************************************************!*\
  !*** ./src/app/components/segment-panel/segment-panel.component.html ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div>\n  <app-navbar></app-navbar>\n\n  <!-- Container for sidebar(s) + page content -->\n  <ng-sidebar-container style=\"height: 800px;\">\n    <!-- A sidebar -->\n    <ng-sidebar [(opened)]=\"_opened\">\n      <app-side-panel></app-side-panel>\n    </ng-sidebar>\n\n    <!-- Page content -->\n    <div ng-sidebar-content>\n      <div class=\"main-container\">\n        <div class=\"row\">\n          <div class=\"col-4\">\n            <h5>Patient</h5>\n            <select class=\"form-control\" name=\"currentPatient\" [(ngModel)]=\"currentPatient\"\n                    (change)=\"setCurrentPatient()\" style=\"max-width: 400px;\">\n              <option value=\"null\" disabled>Select a patient</option>\n              <option *ngFor=\"let patient of patientList\" [ngValue]=\"patient\">{{patient.name}}</option>\n            </select>\n          </div>\n          <div class=\"col-8\">\n          </div>\n        </div>\n      </div>\n      <hr>\n      <div *ngIf=\"patientSelected\" class=\"embed-responsive embed-responsive-16by9\"\n           style=\"margin-left: 30px; margin-right: 30px;\">\n        <iframe class=\"embed-responsive-item\" [src]=\"sanitizedUrl\" allowfullscreen></iframe>\n      </div>\n    </div>\n  </ng-sidebar-container>\n</div>\n"

/***/ }),

/***/ "./src/app/components/segment-panel/segment-panel.component.ts":
/*!*********************************************************************!*\
  !*** ./src/app/components/segment-panel/segment-panel.component.ts ***!
  \*********************************************************************/
/*! exports provided: SegmentPanelComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SegmentPanelComponent", function() { return SegmentPanelComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _app_const__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../app-const */ "./src/app/app-const.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_patient_service_patient_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/patient-service/patient.service */ "./src/app/services/patient-service/patient.service.ts");
/* harmony import */ var _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/helper-service/helper.service */ "./src/app/services/helper-service/helper.service.ts");
/* harmony import */ var _services_segment_service_segment_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/segment-service/segment.service */ "./src/app/services/segment-service/segment.service.ts");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_7__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};








var SegmentPanelComponent = /** @class */ (function () {
    function SegmentPanelComponent(helperService, patientService, segmentService, router, sanitizer, route) {
        var _this = this;
        this.helperService = helperService;
        this.patientService = patientService;
        this.segmentService = segmentService;
        this.router = router;
        this.sanitizer = sanitizer;
        this.route = route;
        this.serverPath = _app_const__WEBPACK_IMPORTED_MODULE_1__["AppConst"].serverPath;
        this._opened = false;
        this.patientList = [];
        this.currentPatient = null;
        this.patientSelected = false;
        this.tagList = [{ display: 'Background', value: 'background' }, { display: 'Ball', value: 'Ball' }, { display: 'Cup', value: 'Cup' }, { display: 'Dazhuanzi', value: 'Dazhuanzi' }];
        this.route.params.forEach(function (params) {
            _this.assignmentItemId = Number.parseInt(params['assignmentItemId']);
        });
    }
    SegmentPanelComponent.prototype._toggleSidebar = function () {
        this._opened = !this._opened;
    };
    SegmentPanelComponent.prototype.setCurrentPatient = function () {
        var _this = this;
        this.segmentService.getSegmentData(this.assignmentItemId, this.currentPatient.id).subscribe(function (res) {
            console.log(res.json());
            _this.patientSelected = true;
            jquery__WEBPACK_IMPORTED_MODULE_7__('iframe').attr('src', jquery__WEBPACK_IMPORTED_MODULE_7__('iframe').attr('src'));
        });
    };
    SegmentPanelComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.helperService.sideMenuStatus$.subscribe(function (open) {
            _this._opened = open;
        });
        this.patientService.getPatientsByAssignmentItem(this.assignmentItemId).subscribe(function (res) {
            console.log(res.json());
            _this.patientList = res.json();
        }, function (error) {
            console.log(error);
        });
        // this.url = 'http://localhost';
        this.url = 'http://152.136.197.88:8282';
        // this.url = 'http://35.192.119.153:8282';
        this.sanitizedUrl =
            this.sanitizer.bypassSecurityTrustResourceUrl(this.url);
    };
    SegmentPanelComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-segment-panel',
            template: __webpack_require__(/*! ./segment-panel.component.html */ "./src/app/components/segment-panel/segment-panel.component.html"),
            styles: [__webpack_require__(/*! ./segment-panel.component.css */ "./src/app/components/segment-panel/segment-panel.component.css")]
        }),
        __metadata("design:paramtypes", [_services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_4__["HelperService"],
            _services_patient_service_patient_service__WEBPACK_IMPORTED_MODULE_3__["PatientService"],
            _services_segment_service_segment_service__WEBPACK_IMPORTED_MODULE_5__["SegmentService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__["DomSanitizer"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]])
    ], SegmentPanelComponent);
    return SegmentPanelComponent;
}());



/***/ }),

/***/ "./src/app/components/select-images/select-images.component.css":
/*!**********************************************************************!*\
  !*** ./src/app/components/select-images/select-images.component.css ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".selected {\n  border: 3px solid hotpink;\n}\n"

/***/ }),

/***/ "./src/app/components/select-images/select-images.component.html":
/*!***********************************************************************!*\
  !*** ./src/app/components/select-images/select-images.component.html ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-navbar></app-navbar>\n\n<!-- Container for sidebar(s) + page content -->\n<ng-sidebar-container style=\"height: 800px;\">\n  <!-- A sidebar -->\n  <ng-sidebar [(opened)]=\"_opened\">\n    <app-side-panel></app-side-panel>\n  </ng-sidebar>\n\n  <div ng-sidebar-content>\n    <div style=\"margin-left: 40px;margin-right: 40px;\">\n      <div class=\"row\">\n        <div class=\"col-6\" style=\"border:1px solid black;\">\n          <div id=\"stage-div\" style=\"margin:auto;margin-top:20px;margin-bottom:20px;\">\n            <ko-stage #stage [config]=\"configStage\" id=\"canvas\">\n              <ko-layer #imageLayer id=\"image-layer\">\n                <ko-image #image [config]=\"imageConfig\"></ko-image>\n              </ko-layer>\n            </ko-stage>\n          </div>\n          <ngb-alert *ngIf=\"emptyStartEnd\" type=\"primary\" (close)=\"closeAlert()\">Start/End can not be empty.</ngb-alert>\n          <ngb-alert *ngIf=\"invalidStart\" type=\"primary\" (close)=\"closeAlert()\">Start image name was not found.\n          </ngb-alert>\n          <ngb-alert *ngIf=\"invalidEnd\" type=\"primary\" (close)=\"closeAlert()\">End image name was not found.</ngb-alert>\n          <ngb-alert *ngIf=\"invalidStartEnd\" type=\"primary\" (close)=\"closeAlert()\">Start image must be before end image\n            .\n          </ngb-alert>\n          <ngb-alert *ngIf=\"patientNotSet\" type=\"primary\" (close)=\"closeAlert()\">Some patient is not set yet. Please\n            select images for that and try again.\n          </ngb-alert>\n\n\n          <span id=\"scaleX\" hidden></span>\n          <span id=\"scaleY\" hidden></span>\n          <span id=\"defaultHeight\" hidden></span>\n        </div>\n        <div class=\"col-4\" style=\"border:1px solid black;\">\n          <!--<div *ngIf=\"busy\" class=\"text-center\" style=\"margin: 100px 0px 0 0px\">-->\n          <!--<i class=\"fas fa-spinner fa-3x faa-spin animated\"></i>-->\n          <!--</div>-->\n          <!--<perfect-scrollbar *ngIf=\"!busy\" id=\"scroll-bar\" style=\"max-height:1000px;margin-top:10px;margin-bottom: 10px;\" [config]=\"config\">-->\n          <!--<div *ngFor=\"let image of imageList; let i=index; trackBy: trackByFn\" class=\"card text-center\" style=\"margin-bottom: 10px;background-color: black;\">-->\n          <!--<div>-->\n          <!--<img src=\"{{serverPath}}/image/getImage/{{image.folderName}}/{{image.fileName}}\" class=\"img-fluid\" style=\"cursor: pointer; width: auto; height: 120px;\"-->\n          <!--alt=\"Image Thumbnail\" (click)=\"onSelectImage(image)\">-->\n          <!--</div>-->\n          <!--<span style=\"color: white;font-size: 8pt\">{{image.fileName | slice:0:image.fileName.length-4}}</span>-->\n          <!--</div>-->\n\n          <!--</perfect-scrollbar>-->\n\n          <form class=\"form-inline\" style=\"margin-top: 20px;\">\n            <div class=\"input-group\" style=\"width: 200px;\">\n              <div class=\"input-group-prepend\">\n                <div class=\"input-group-text\">Items</div>\n              </div>\n              <input type=\"number\" class=\"form-control\" id=\"itemsPerPage\" name=\"itemsPerPage\" min=\"0\"\n                     [(ngModel)]=\"config.itemsPerPage\">\n            </div>\n            &nbsp;&nbsp;\n            <div class=\"input-group\" style=\"width: 200px;\">\n              <div class=\"input-group-prepend\">\n                <div class=\"input-group-text\">Page</div>\n              </div>\n              <input type=\"number\" class=\"form-control\" id=\"currentPage\" name=\"currentPage\" min=\"0\"\n                     [(ngModel)]=\"config.currentPage\">\n            </div>\n          </form>\n          <hr>\n          <div *ngIf=\"!busy\">\n            <ul class=\"list-inline\" style=\"margin-bottom: 10px;\">\n              <li style=\"width:120px;\" class=\"list-inline-item\"\n                  *ngFor=\"let image of imageList | stringFilter: filter | paginate: config; let i=index; trackBy: trackByFn\">\n                <div>\n                  <img src=\"{{serverPath}}/image/getImage/{{image.folderPath}}\" class=\"img-fluid\"\n                       [ngClass]=\"currentImage == image? 'selected' : ''\"\n                       style=\"cursor: pointer; width: auto; height: 120px;\"\n                       alt=\"Image Thumbnail\" (click)=\"onSelectImage(image)\">\n                </div>\n                <span class=\"text-center\"\n                      style=\"font-size: 10pt\">{{image.fileName | slice:0:image.fileName.length-4}}</span>\n              </li>\n            </ul>\n            <pagination-controls style=\"font-size: medium;\" [id]=\"config.id\"\n                                 [maxSize]=\"maxSize\"\n                                 [directionLinks]=\"directionLinks\"\n                                 [autoHide]=\"autoHide\"\n                                 [responsive]=\"responsive\"\n                                 [previousLabel]=\"labels.previousLabel\"\n                                 [nextLabel]=\"labels.nextLabel\"\n                                 [screenReaderPaginationLabel]=\"labels.screenReaderPaginationLabel\"\n                                 [screenReaderPageLabel]=\"labels.screenReaderPageLabel\"\n                                 [screenReaderCurrentLabel]=\"labels.screenReaderCurrentLabel\"\n                                 (pageChange)=\"onPageChange($event)\"></pagination-controls>\n\n          </div>\n\n          <div *ngIf=\"busy\" class=\"text-center\" style=\"margin: 100px 0px 0 0px\">\n            <i class=\"fa fa-spinner fa-3x faa-spin animated\"></i>\n          </div>\n        </div>\n        <div class=\"col-2\" style=\"border:1px solid black;\">\n          <div style=\"margin-top:20px;\">\n            <small>Select a patient and fill start/end image name to select images</small>\n            <hr>\n            <h5>Patient</h5>\n            <select class=\"form-control\" name=\"currentPatient\" [(ngModel)]=\"currentPatient\"\n                    (change)=\"setCurrentPatient()\">\n              <option value=\"null\" disabled>Select a patient</option>\n              <option *ngFor=\"let patient of patientList\" [ngValue]=\"patient\">{{patient.name}}</option>\n            </select>\n            <br>\n            <p>Start Image: {{startImageDisplay}}</p>\n            <p>End Image: {{endImageDisplay}}</p>\n            <hr>\n            <form (ngSubmit)=\"onSubmitStartEnd()\">\n              <div class=\"form-group\">\n                <label for=\"startImage\">Start</label>\n                <input type=\"text\" class=\"form-control\" id=\"startImage\" name=\"startImage\" [(ngModel)]=\"startImage\"\n                       required=\"required\" (change)=\"onSelectChanged()\">\n              </div>\n              <div class=\"form-group\">\n                <label for=\"endImage\">End</label>\n                <input type=\"text\" class=\"form-control\" id=\"endImage\" name=\"endImage\" [(ngModel)]=\"endImage\"\n                       required=\"required\" (change)=\"onSelectChanged()\">\n              </div>\n              <button type=\"submit\" class=\"btn btn-outline-dark\">Select</button>\n            </form>\n            <br>\n            <div *ngIf=\"imageSelected\" class=\"alert alert-success\" style=\"font-size: 0.75em;\">Selected images are from\n              \"{{tempStart}}\" to \"{{tempEnd}}\".\n            </div>\n            <hr>\n            <a *ngIf=\"imageSelected\" class=\"btn btn-outline-dark\" (click)=\"onSetPickedImages()\">Complete</a>\n            <br><br>\n            <div *ngIf=\"imagePicked\" class=\"alert alert-success\" style=\"font-size: 0.75em;\">Images are set on patient\n              <strong>{{currentPatient.name}}</strong></div>\n            <div *ngIf=\"busy2\" class=\"text-center\" style=\"margin: 10px 0px 0 0px\">\n              <i class=\"fa fa-spinner fa-3x faa-spin animated\"></i>\n            </div>\n            <hr>\n            <button class=\"btn btn-block btn-outline-dark\" (click)=\"onFinish()\">Finish Creating Assignment</button>\n            <br>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n\n</ng-sidebar-container>\n"

/***/ }),

/***/ "./src/app/components/select-images/select-images.component.ts":
/*!*********************************************************************!*\
  !*** ./src/app/components/select-images/select-images.component.ts ***!
  \*********************************************************************/
/*! exports provided: SelectImagesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SelectImagesComponent", function() { return SelectImagesComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _app_const__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../app-const */ "./src/app/app-const.ts");
/* harmony import */ var _services_image_service_image_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/image-service/image.service */ "./src/app/services/image-service/image.service.ts");
/* harmony import */ var _services_task_service_task_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/task-service/task.service */ "./src/app/services/task-service/task.service.ts");
/* harmony import */ var _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/helper-service/helper.service */ "./src/app/services/helper-service/helper.service.ts");
/* harmony import */ var _services_assignment_service_assignment_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../services/assignment-service/assignment.service */ "./src/app/services/assignment-service/assignment.service.ts");
/* harmony import */ var _services_patient_service_patient_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../services/patient-service/patient.service */ "./src/app/services/patient-service/patient.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var angular2_hotkeys__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! angular2-hotkeys */ "./node_modules/angular2-hotkeys/index.js");
/* harmony import */ var angular2_hotkeys__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(angular2_hotkeys__WEBPACK_IMPORTED_MODULE_10__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};











var SelectImagesComponent = /** @class */ (function () {
    function SelectImagesComponent(imageService, taskService, helperService, route, router, assignmentService, patientService, _hotkeysService) {
        var _this = this;
        this.imageService = imageService;
        this.taskService = taskService;
        this.helperService = helperService;
        this.route = route;
        this.router = router;
        this.assignmentService = assignmentService;
        this.patientService = patientService;
        this._hotkeysService = _hotkeysService;
        this.filter = '';
        this.maxSize = 6;
        this.directionLinks = true;
        this.autoHide = true;
        this.responsive = true;
        this.config = {
            id: 'advanced',
            itemsPerPage: 16,
            currentPage: 1
        };
        this.p = 1;
        this.labels = {
            previousLabel: 'Previous',
            nextLabel: 'Next',
            screenReaderPaginationLabel: 'Pagination',
            screenReaderPageLabel: 'page',
            screenReaderCurrentLabel: "You're on page"
        };
        this.serverPath = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath;
        this.rectDescriptionList = [];
        this.dotDescriptionList = [];
        this.rectConfigList = [];
        this.dotConfigList = [];
        this.imageList = [];
        this.patientList = [];
        this._opened = false;
        this.imageSelected = false;
        this.imagePicked = false;
        this.emptyStartEnd = false;
        this.invalidStart = false;
        this.invalidEnd = false;
        this.invalidStartEnd = false;
        this.patientNotSet = false;
        this.busy = false;
        this.busy2 = false;
        this.patientStartEndList = {};
        this.route
            .queryParams
            .subscribe(function (params) {
            _this.assignmentId = params['assignmentId'];
            // this.imageService.getImageListByAssignmentAndPatient(this.assignmentId, this.patientName).subscribe(
            //   res => {
            //     this.imageList = res.json();
            //     this.patientId = this.imageList[0].patient.id;
            //   },
            //   error => {
            //     console.log(error);
            //   }
            // );
        });
        this._hotkeysService.add(new angular2_hotkeys__WEBPACK_IMPORTED_MODULE_10__["Hotkey"]('f', function (event) {
            var i = _this.imageList.indexOf(_this.currentImage);
            if (i < _this.imageList.length - 1) {
                i++;
            }
            _this.onSelectImage(_this.imageList[i]);
            return false; // Prevent bubbling
        }));
        this._hotkeysService.add(new angular2_hotkeys__WEBPACK_IMPORTED_MODULE_10__["Hotkey"]('a', function (event) {
            var i = _this.imageList.indexOf(_this.currentImage);
            if (i > 0) {
                i--;
            }
            _this.onSelectImage(_this.imageList[i]);
            return false; // Prevent bubbling
        }));
    }
    SelectImagesComponent.prototype._toggleSidebar = function () {
        this._opened = !this._opened;
    };
    SelectImagesComponent.prototype.onPageChange = function (number) {
        console.log('change to page', number);
        this.config.currentPage = number;
    };
    SelectImagesComponent.prototype.canvasInit = function () {
        this.imageConfig = Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])({
            x: 0,
            y: 0,
            image: this.imageObj,
            width: this.imageWidth,
            height: this.imageHeight
        });
        this.configStage = Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])({
            container: 'canvas',
            x: 0,
            y: 0,
            width: this.imageWidth,
            height: this.imageHeight
        });
    };
    SelectImagesComponent.prototype.onSelectImage = function (image) {
        this.currentImage = image;
        var url = this.serverPath + '/image/getImage/' + image.folderPath;
        this.imageObj.src = url;
        var that = this;
        this.imageObj.onload = function () {
            console.log(this.width);
            var w = that.imageObj.width;
            var h = that.imageObj.height;
            console.log('w,h: ' + w + ',' + h);
            // let stageHeight = document.getElementById('stage-div').offsetHeight;
            var stageHeight = that.height;
            var scaleY = stageHeight / h;
            var stageWidth = w / h * stageHeight;
            // let width = document.getElementById('stage-div').offsetWidth;
            var width = that.width;
            console.log(width, stageWidth, stageHeight);
            if ((w / h * stageHeight) > width - 50) {
                stageWidth = width - 50;
                stageHeight = stageWidth * h / w;
                scaleY = stageHeight / h;
            }
            else {
                stageWidth = w / h * stageHeight;
            }
            var scaleX = stageWidth / w;
            // document.getElementById("stage-div").style.width=stageWidth+"";
            jquery__WEBPACK_IMPORTED_MODULE_9__('#stage-div').width(stageWidth);
            console.log(document.getElementById('stage-div').style.width);
            that.image.getStage().height(stageHeight);
            that.image.getStage().width(stageWidth);
            that.image.getStage().draw();
            that.imageLayer.getStage().height(stageHeight);
            that.imageLayer.getStage().width(stageWidth);
            that.imageLayer.getStage().draw();
            that.stage.getStage().width(stageWidth);
            that.stage.getStage().height(stageHeight);
            that.stage.getStage().draw();
        };
        this.checkPage();
    };
    SelectImagesComponent.prototype.checkPage = function () {
        var size = this.imageList.length;
        var items = this.config.itemsPerPage;
        var totalPages = size / items;
        var i = this.imageList.indexOf(this.currentImage);
        var currentPage = Math.ceil((i + 1) / items);
        if (this.config.currentPage != currentPage) {
            this.config.currentPage = currentPage;
        }
    };
    SelectImagesComponent.prototype.checkStart = function () {
        for (var i = 0; i < this.imageList.length; i++) {
            var image = this.imageList[i];
            if (image.fileName.substring(0, image.fileName.length - 4) === this.startImage) {
                return false;
            }
        }
        return true;
    };
    SelectImagesComponent.prototype.checkEnd = function () {
        for (var i = 0; i < this.imageList.length; i++) {
            var image = this.imageList[i];
            if (image.fileName.substring(0, image.fileName.length - 4) === this.endImage) {
                return false;
            }
        }
        return true;
    };
    SelectImagesComponent.prototype.checkStartEnd = function () {
        var myArray1 = this.startImage.split(/([0-9]+)/);
        var myArray2 = this.endImage.split(/([0-9]+)/);
        var start = myArray1[1];
        var end = myArray2[1];
        if (Number(start) > Number(end)) {
            return true;
        }
        return false;
    };
    SelectImagesComponent.prototype.onSubmitStartEnd = function () {
        var _this = this;
        if (this.startImage == null || this.startImage == '' || this.endImage == null || this.endImage == '') {
            this.emptyStartEnd = true;
            setTimeout(function () { return _this.emptyStartEnd = false; }, 5000);
            return;
        }
        if (this.checkStart()) {
            this.invalidStart = true;
            setTimeout(function () { return _this.invalidStart = false; }, 5000);
            return;
        }
        if (this.checkEnd()) {
            this.invalidEnd = true;
            setTimeout(function () { return _this.invalidEnd = false; }, 5000);
            return;
        }
        if (this.checkStartEnd()) {
            this.invalidStartEnd = true;
            setTimeout(function () { return _this.invalidStartEnd = false; }, 5000);
            return;
        }
        this.tempStart = this.startImage;
        this.tempEnd = this.endImage;
        this.imageSelected = true;
        this.patientStartEndList[this.currentPatient.id] = [this.startImage, this.endImage];
    };
    SelectImagesComponent.prototype.onFinish = function () {
        var _this = this;
        for (var i = 0; i < this.patientList.length; i++) {
            var p = this.patientList[i];
            if (this.patientStartEndList[p.id + ''] == null || this.patientStartEndList[p.id + ''] == '') {
                this.patientNotSet = true;
                setTimeout(function () { return _this.patientNotSet = false; }, 5000);
                return;
            }
        }
        this.router.navigate(['/adminPanel']);
    };
    SelectImagesComponent.prototype.closeAlert = function () {
        this.emptyStartEnd = false;
        this.invalidStart = false;
        this.invalidEnd = false;
        this.invalidStartEnd = false;
    };
    SelectImagesComponent.prototype.onSetPickedImages = function () {
        var _this = this;
        this.busy2 = true;
        this.assignmentService.setPickedImages(this.assignmentId, this.patientId, this.tempStart, this.tempEnd).subscribe(function (res) {
            console.log(res);
            _this.imagePicked = true;
            _this.busy2 = false;
        }, function (error) {
            console.log(error);
        });
    };
    SelectImagesComponent.prototype.onSelectChanged = function () {
        this.imageSelected = false;
        this.imagePicked = false;
    };
    SelectImagesComponent.prototype.setCurrentPatient = function () {
        var _this = this;
        this.busy = true;
        console.log(this.currentPatient);
        this.imageService.getImageListByAssignmentAndPatient(this.assignmentId, this.currentPatient.name).subscribe(function (res) {
            _this.imageList = res.json();
            _this.patientId = _this.currentPatient.id;
            _this.imageSelected = false;
            _this.imagePicked = false;
            _this.busy = false;
            if (_this.patientStartEndList[_this.currentPatient.id + ''] != null) {
                _this.startImageDisplay = _this.patientStartEndList[_this.currentPatient.id + ''][0];
                _this.endImageDisplay = _this.patientStartEndList[_this.currentPatient.id + ''][1];
                _this.startImage = _this.startImageDisplay;
                _this.endImage = _this.endImageDisplay;
            }
            else {
                _this.startImage = '';
                _this.endImage = '';
                _this.startImageDisplay = 'N/A';
                _this.endImageDisplay = 'N/A';
            }
        }, function (error) {
            console.log(error);
        });
    };
    SelectImagesComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.imageService.newDescriptionObject$.subscribe(function (object) {
            var description = object['description'];
            var labelIndex = object['index'];
            var labelType = object['type'];
            console.log(description, labelIndex, labelType);
            if (labelType == 'rect') {
                _this.rectDescriptionList[labelIndex] = description;
            }
            else if (labelType == 'dot') {
                _this.dotDescriptionList[labelIndex] = description;
            }
        });
        this.taskService.newTaskDescription$.subscribe(function (object) {
            var taskDescription = object['taskDescription'];
            _this.currentTask['description'] = taskDescription;
        });
        for (var i = 0; i < 100; i++) {
            this.rectConfigList.push(new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"]({
                x: 0,
                y: 0,
                width: 0,
                height: 0,
                fill: 'transparent',
                stroke: 'red',
                strokeWidth: 2
            }));
        }
        for (var i = 0; i < 100; i++) {
            this.dotConfigList.push(new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"]({
                x: 0,
                y: 0,
                radius: 0,
                fill: 'transparent',
                stroke: 'yellow',
                strokeWidth: 2,
                draggable: true
            }));
        }
        this.imageObj = new Image();
        this.imageObj.src = 'assets/images/getstarted.jpg';
        this.imageObj.onload = function () {
        };
        this.imageWidth = 750;
        this.imageHeight = 650;
        jquery__WEBPACK_IMPORTED_MODULE_9__('#stage-div').width(this.imageWidth);
        this.width = this.imageWidth;
        jquery__WEBPACK_IMPORTED_MODULE_9__('#stage-div').height(this.imageHeight);
        this.height = this.imageHeight;
        this.imageObj.onload = this.canvasInit();
        console.log(this.imageObj);
        this.imageService.setCurrentImageSaved(true);
        this.helperService.sideMenuStatus$.subscribe(function (open) {
            console.log(open);
            _this._opened = open;
        });
        this.patientService.getPatientsByAssignment(this.assignmentId).subscribe(function (res) {
            console.log(res.json());
            _this.patientList = res.json();
        }, function (error) {
            console.log(error);
        });
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('stage'),
        __metadata("design:type", Object)
    ], SelectImagesComponent.prototype, "stage", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('image'),
        __metadata("design:type", Object)
    ], SelectImagesComponent.prototype, "image", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('imageLayer'),
        __metadata("design:type", Object)
    ], SelectImagesComponent.prototype, "imageLayer", void 0);
    SelectImagesComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-select-images',
            template: __webpack_require__(/*! ./select-images.component.html */ "./src/app/components/select-images/select-images.component.html"),
            styles: [__webpack_require__(/*! ./select-images.component.css */ "./src/app/components/select-images/select-images.component.css")]
        }),
        __metadata("design:paramtypes", [_services_image_service_image_service__WEBPACK_IMPORTED_MODULE_3__["ImageService"], _services_task_service_task_service__WEBPACK_IMPORTED_MODULE_4__["TaskService"], _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_5__["HelperService"], _angular_router__WEBPACK_IMPORTED_MODULE_8__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_8__["Router"], _services_assignment_service_assignment_service__WEBPACK_IMPORTED_MODULE_6__["AssignmentService"], _services_patient_service_patient_service__WEBPACK_IMPORTED_MODULE_7__["PatientService"], angular2_hotkeys__WEBPACK_IMPORTED_MODULE_10__["HotkeysService"]])
    ], SelectImagesComponent);
    return SelectImagesComponent;
}());



/***/ }),

/***/ "./src/app/components/settings/settings.component.css":
/*!************************************************************!*\
  !*** ./src/app/components/settings/settings.component.css ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".spin:hover {\n    -webkit-animation: fa-spin 2s infinite linear;\n    animation: fa-spin 2s infinite linear;\n  }\n  \n  .side-container {\n    background-color: white; \n    border:2px solid black;\n    width: 200px;\n    height:800px;\n  }\n\n\n"

/***/ }),

/***/ "./src/app/components/settings/settings.component.html":
/*!*************************************************************!*\
  !*** ./src/app/components/settings/settings.component.html ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div>\n  <app-navbar></app-navbar>\n\n  <!-- Container for sidebar(s) + page content -->\n  <ng-sidebar-container style=\"height: 800px;\">\n    <!-- A sidebar -->\n    <ng-sidebar [(opened)]=\"_opened\">\n      <app-side-panel></app-side-panel>\n    </ng-sidebar>\n\n    <!-- Page content -->\n    <div ng-sidebar-content>\n      <div class=\"container\" style=\"margin-top: 50px;\">\n        <h3>Settings</h3>\n        <br>\n        <div *ngIf=\"userUpdated\">\n          <div class=\"alert alert-success\">User information updated.</div>\n        </div>\n        <div *ngIf=\"passwordUpdated\">\n          <div class=\"alert alert-success\">Password updated.</div>\n        </div>\n        <div *ngIf=\"needCurrentPassword\">\n          <div class=\"alert alert-danger\">Current password is needed to update for new password.</div>\n        </div>\n        <div *ngIf=\"needNewPassword\">\n          <div class=\"alert alert-danger\">New password is not filled.</div>\n        </div>\n        <div *ngIf=\"mismatchedPassword\">\n          <div class=\"alert alert-danger\">New passwords don't match.</div>\n        </div>\n        <div *ngIf=\"wrongCurrentPassword\">\n          <div class=\"alert alert-danger\">Current password is incorrect.</div>\n        </div>\n        <ngb-tabset>\n          <ngb-tab title=\"Profile\">\n            <ng-template ngbTabContent>\n              <br>\n              <form (ngSubmit)=\"onUpdateUser()\">\n                <div class=\"form-row\">\n                  <div class=\"form-group col-md-6\">\n                    <label for=\"firstName\">First Name</label>\n                    <input type=\"text\" class=\"form-control\" id=\"firstName\" placeholder=\"Your first name\" name=\"firstName\" [(ngModel)]=\"user.firstName\">\n                  </div>\n                  <div class=\"form-group col-md-6\">\n                    <label for=\"lastName\">Last Name</label>\n                    <input type=\"text\" class=\"form-control\" id=\"lastName\" placeholder=\"Your last name\" name=\"lastName\" [(ngModel)]=\"user.lastName\">\n                  </div>\n                </div>\n                <div class=\"form-row\">\n                  <div class=\"form-group col-md-6\">\n                    <label for=\"email\">Email</label>\n                    <input type=\"email\" class=\"form-control\" id=\"email\" placeholder=\"Your email\" name=\"email\" [(ngModel)]=\"user.email\">\n                  </div>\n                  <div class=\"form-group col-md-6\">\n                    <label for=\"phone\">Phone</label>\n                    <input type=\"number\" class=\"form-control\" id=\"phone\" placeholder=\"Your phone number\" name=\"phone\" [(ngModel)]=\"user.phone\">\n                  </div>\n                </div>\n                <div class=\"form-group\">\n                  <label for=\"address1\">Address</label>\n                  <input type=\"text\" class=\"form-control\" id=\"address1\" placeholder=\"Your main street address\">\n                </div>\n                <div class=\"form-group\">\n                  <label for=\"address2\">Address 2</label>\n                  <input type=\"text\" class=\"form-control\" id=\"address2\" placeholder=\"Apartment, studio, or floor\">\n                </div>\n                <div class=\"form-row\">\n                  <div class=\"form-group col-md-6\">\n                    <label for=\"city\">City</label>\n                    <input type=\"text\" class=\"form-control\" id=\"city\">\n                  </div>\n                  <div class=\"form-group col-md-4\">\n                    <label for=\"state\">State</label>\n                    <select id=\"state\" class=\"form-control\">\n                      <option selected>Choose...</option>\n                      <option>...</option>\n                    </select>\n                  </div>\n                  <div class=\"form-group col-md-2\">\n                    <label for=\"zip\">Zip</label>\n                    <input type=\"text\" class=\"form-control\" id=\"zip\">\n                  </div>\n                </div>\n                <button type=\"submit\" class=\"btn btn-dark\">Submit</button>\n              </form>\n            </ng-template>\n          </ngb-tab>\n          <ngb-tab>\n            <ng-template ngbTabTitle>Password</ng-template>\n            <ng-template ngbTabContent>\n              <br>\n              <form (ngSubmit)=\"onUpdatePassword()\">\n                <div class=\"form-row\">\n                  <div class=\"form-group col-md-4\">\n                    <label for=\"currentPassword\">Current Password</label>\n                    <input type=\"password\" class=\"form-control\" id=\"currentPassword\" name=\"currentPassword\" [(ngModel)]=\"currentPassword\">\n                  </div>\n                  <div class=\"form-group col-md-4\">\n                    <label for=\"newPassword1\">New Password</label>\n                    <input type=\"password\" class=\"form-control\" id=\"newPassword1\" name=\"newPassword1\" [(ngModel)]=\"newPassword1\">\n                  </div>\n                  <div class=\"form-group col-md-4\">\n                    <label for=\"newPassword2\">Confirm New Password</label>\n                    <input type=\"password\" class=\"form-control\" id=\"newPassword2\" name=\"newPassword2\" [(ngModel)]=\"newPassword2\">\n                  </div>\n                  <button type=\"submit\" class=\"btn btn-dark\">Submit</button>\n                </div>\n              </form>\n            </ng-template>\n          </ngb-tab>\n        </ngb-tabset>\n      </div>\n    </div>\n  </ng-sidebar-container>\n</div>"

/***/ }),

/***/ "./src/app/components/settings/settings.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/components/settings/settings.component.ts ***!
  \***********************************************************/
/*! exports provided: SettingsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingsComponent", function() { return SettingsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _app_const__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../app-const */ "./src/app/app-const.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_login_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/login.service */ "./src/app/services/login.service.ts");
/* harmony import */ var _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/helper-service/helper.service */ "./src/app/services/helper-service/helper.service.ts");
/* harmony import */ var _services_user_service_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/user-service/user.service */ "./src/app/services/user-service/user.service.ts");
/* harmony import */ var _models_user__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../models/user */ "./src/app/models/user.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var SettingsComponent = /** @class */ (function () {
    function SettingsComponent(helperService, loginService, userService, router) {
        this.helperService = helperService;
        this.loginService = loginService;
        this.userService = userService;
        this.router = router;
        this.serverPath = _app_const__WEBPACK_IMPORTED_MODULE_1__["AppConst"].serverPath;
        this._opened = false;
        this.loggedIn = false;
        this.user = new _models_user__WEBPACK_IMPORTED_MODULE_6__["User"]();
        this.userUpdated = false;
        this.needCurrentPassword = false;
        this.needNewPassword = false;
        this.mismatchedPassword = false;
        this.passwordUpdated = false;
        this.wrongCurrentPassword = false;
    }
    SettingsComponent.prototype._toggleSidebar = function () {
        this._opened = !this._opened;
    };
    SettingsComponent.prototype.onLogout = function () {
        var _this = this;
        this.loginService.logout().subscribe(function (res) {
            console.log(res.text());
            _this.loggedIn = false;
            _this.router.navigate(['/login']);
        }, function (error) {
            _this.loggedIn = true;
        });
    };
    SettingsComponent.prototype.onUpdatePassword = function () {
        var _this = this;
        if (this.newPassword1 != this.newPassword2) {
            this.mismatchedPassword = true;
            var that_1 = this;
            setTimeout(function () {
                that_1.mismatchedPassword = false;
            }.bind(this), 5000);
        }
        else if ((this.currentPassword == null || this.currentPassword == "") && (this.newPassword1 != null || this.newPassword2 != "")) {
            this.needCurrentPassword = true;
            var that_2 = this;
            setTimeout(function () {
                that_2.needCurrentPassword = false;
            }.bind(this), 5000);
        }
        else if ((this.currentPassword != null && this.currentPassword != "") && (this.newPassword1 == null || this.newPassword2 == "")) {
            this.needNewPassword = true;
            var that_3 = this;
            setTimeout(function () {
                that_3.needNewPassword = false;
            }.bind(this), 5000);
        }
        else {
            this.userService.updatePassword(this.currentPassword, this.newPassword1).subscribe(function (res) {
                console.log(res.text());
                if (res.text() == "Password updated") {
                    _this.passwordUpdated = true;
                    var that_4 = _this;
                    setTimeout(function () {
                        that_4.passwordUpdated = false;
                    }.bind(_this), 5000);
                }
            }, function (error) {
                console.log(error.text());
                if (error.text() == "Current password is incorrect") {
                    _this.wrongCurrentPassword = true;
                    var that_5 = _this;
                    setTimeout(function () {
                        that_5.wrongCurrentPassword = false;
                    }.bind(_this), 3000);
                }
            });
        }
    };
    SettingsComponent.prototype.onUpdateUser = function () {
        var _this = this;
        this.userService.updateUser(this.user).subscribe(function (res) {
            _this.userUpdated = true;
            var that = _this;
            setTimeout(function () {
                that.userUpdated = false;
            }.bind(_this), 3000);
        }, function (error) {
        });
    };
    SettingsComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.helperService.sideMenuStatus$.subscribe(function (open) {
            _this._opened = open;
        });
        this.userService.getUser().subscribe(function (res) {
            console.log(res.json());
            _this.user = res.json();
        });
    };
    SettingsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-settings',
            template: __webpack_require__(/*! ./settings.component.html */ "./src/app/components/settings/settings.component.html"),
            styles: [__webpack_require__(/*! ./settings.component.css */ "./src/app/components/settings/settings.component.css")]
        }),
        __metadata("design:paramtypes", [_services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_4__["HelperService"],
            _services_login_service__WEBPACK_IMPORTED_MODULE_3__["LoginService"],
            _services_user_service_user_service__WEBPACK_IMPORTED_MODULE_5__["UserService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], SettingsComponent);
    return SettingsComponent;
}());



/***/ }),

/***/ "./src/app/components/side-panel/side-panel.component.css":
/*!****************************************************************!*\
  !*** ./src/app/components/side-panel/side-panel.component.css ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".spin:hover {\n    -webkit-animation: fa-spin 2s infinite linear;\n    animation: fa-spin 2s infinite linear;\n  }\n  \n  .side-container {\n    background-color: white; \n    border:2px solid black;\n    width: 200px;\n    height:800px;\n  }"

/***/ }),

/***/ "./src/app/components/side-panel/side-panel.component.html":
/*!*****************************************************************!*\
  !*** ./src/app/components/side-panel/side-panel.component.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"side-container container\">\n    <div style=\"margin-top: 20px; margin-bottom: 20px;\">\n      <!--<div class=\"checkbox-group\">-->\n        <!--<div class=\"form-check\">-->\n          <!--<input class=\"form-check-input\" type=\"checkbox\" id=\"gridCheck1\">-->\n          <!--<label class=\"form-check-label\" for=\"gridCheck1\">-->\n            <!--Check item 1 &nbsp;-->\n            <!--<i class=\"fas fa-briefcase-medical\"></i>-->\n          <!--</label>-->\n        <!--</div>-->\n        <!--<div class=\"form-check\">-->\n          <!--<input class=\"form-check-input\" type=\"checkbox\" id=\"gridCheck2\">-->\n          <!--<label class=\"form-check-label\" for=\"gridCheck2\">-->\n            <!--Check item 2 &nbsp;-->\n            <!--<i class=\"fas fa-briefcase-medical\"></i>-->\n          <!--</label>-->\n        <!--</div>-->\n        <!--<div class=\"form-check\">-->\n          <!--<input class=\"form-check-input\" type=\"checkbox\" id=\"gridCheck3\">-->\n          <!--<label class=\"form-check-label\" for=\"gridCheck3\">-->\n            <!--Check item 3 &nbsp;-->\n            <!--<i class=\"fa fa-briefcase-medical\"></i>-->\n          <!--</label>-->\n        <!--</div>-->\n      <!--</div>-->\n      <div style=\"margin-top:650px;\">\n        <div style=\"top:200px; bottom: 30px;\">\n          <button class=\"btn btn-dark btn-sm pull-left\" (click)=\"onLogout()\">Logout</button>\n        </div>\n        <div style=\"top:200px; right:10px; bottom: 30px;\">\n          <span id=\"settings\" style=\"cursor: pointer;\" (click)=\"onSettings()\">\n            <i class=\"fa fa-cog fa-2x pull-right spin\"></i>\n          </span>\n        </div>\n      </div>\n    </div>\n  </div>\n"

/***/ }),

/***/ "./src/app/components/side-panel/side-panel.component.ts":
/*!***************************************************************!*\
  !*** ./src/app/components/side-panel/side-panel.component.ts ***!
  \***************************************************************/
/*! exports provided: SidePanelComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SidePanelComponent", function() { return SidePanelComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_login_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/login.service */ "./src/app/services/login.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var SidePanelComponent = /** @class */ (function () {
    function SidePanelComponent(loginService, router) {
        this.loginService = loginService;
        this.router = router;
        this.loggedIn = false;
    }
    SidePanelComponent.prototype.ngOnInit = function () {
    };
    SidePanelComponent.prototype.onLogout = function () {
        var _this = this;
        this.loginService.logout().subscribe(function (res) {
            console.log(res.text());
            _this.loggedIn = false;
            _this.router.navigate(['/login']);
        }, function (error) {
            _this.loggedIn = true;
        });
    };
    SidePanelComponent.prototype.onSettings = function () {
        this.router.navigate(['/settings']);
    };
    SidePanelComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-side-panel',
            template: __webpack_require__(/*! ./side-panel.component.html */ "./src/app/components/side-panel/side-panel.component.html"),
            styles: [__webpack_require__(/*! ./side-panel.component.css */ "./src/app/components/side-panel/side-panel.component.css")]
        }),
        __metadata("design:paramtypes", [_services_login_service__WEBPACK_IMPORTED_MODULE_2__["LoginService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]])
    ], SidePanelComponent);
    return SidePanelComponent;
}());



/***/ }),

/***/ "./src/app/components/upload-images/upload-images.component.css":
/*!**********************************************************************!*\
  !*** ./src/app/components/upload-images/upload-images.component.css ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".inner-container{\n    margin: 20px 20px 20px 20px;\n}\n\n.pointer {\n  cursor: pointer;\n}\n\n.box {\n  border:1px solid red;\n}\n\n\n"

/***/ }),

/***/ "./src/app/components/upload-images/upload-images.component.html":
/*!***********************************************************************!*\
  !*** ./src/app/components/upload-images/upload-images.component.html ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div *ngIf=\"!loading\">\n  <app-navbar></app-navbar>\n  <!-- Container for sidebar(s) + page content -->\n  <ng-sidebar-container style=\"height: 800px;\">\n    <!-- A sidebar -->\n    <ng-sidebar [(opened)]=\"_opened\">\n      <app-side-panel></app-side-panel>\n    </ng-sidebar>\n    <!-- Page content -->\n    <div ng-sidebar-content>\n      <div class=\"main\" style=\"margin:auto; margin-top: 50px; width: 90%\">\n        <h4>Upload Images for the Assignment</h4>\n        <h6>Use ZIP file to upload</h6>\n        <p style=\"font-size: small;\">\n          1. Target folder - where you want to upload<br>\n          2. Browse a folder to upload and give a folder name\n        </p>\n\n        <form>\n          <div>\n            <button type=\"button\" class=\"btn btn-outline-dark\" (click)=\"onUploadAll()\">\n              <span class=\"glyphicon glyphicon-upload\"></span> Upload all\n            </button>\n            <button type=\"button\" class=\"btn btn-outline-dark pull-right\" (click)=\"cancelUpload()\">\n              <span class=\"glyphicon glyphicon-upload\"></span> Cancel\n            </button>\n          </div>\n          <br>\n          <ngb-alert *ngIf=\"fileNeeded\" type=\"light\" (close)=\"closeAlert()\">At least one file is needed to proceed.\n          </ngb-alert>\n          <ngb-alert *ngIf=\"noFileSelected\" type=\"light\" (close)=\"closeAlert()\">Browse a file to upload.</ngb-alert>\n          <ngb-alert *ngIf=\"notZipFile\" type=\"light\" (close)=\"closeAlert()\">Only Zip File is allowed.</ngb-alert>\n          <ngb-alert *ngIf=\"canProceed\" type=\"light\" (close)=\"closeAlert()\">File uploaded successfully.</ngb-alert>\n\n          <!-- ******** First Patient ********-->\n          <div class=\"row\">\n            <div class=\"col-5\" style=\"border:1px solid black;\">\n\n              <div class=\"inner-container\">\n                <div class=\"input-group\">\n                  <div class=\"input-group-prepend\">\n                    <span class=\"input-group-text\">Target Folder</span>\n                  </div>\n                  <input type=\"text\" class=\"form-control\" id=\"targetFolder1\" name=\"targetFolder1\"\n                         [(ngModel)]=\"targetFolder1\" disabled/>&nbsp;&nbsp;\n                  <button class=\"btn btn-outline-dark btn-sm\" (click)=\"browseFolder1()\">Select Folder</button>\n                  <br>\n                </div>\n              </div>\n              <div class=\"inner-container\">\n                <div class=\"input-group\">\n                  <div class=\"input-group-prepend\">\n                    <span class=\"input-group-text\" id=\"basic-addon1\">Folder Name</span>\n                  </div>\n                  <input type=\"text\" class=\"form-control\" id=\"folderName1\" name=\"folderName1\"\n                         [(ngModel)]=\"folderName1\"/>&nbsp;&nbsp;\n                  <!-- Default checked -->\n                  <div class=\"form-check form-check-inline\">\n                    <input class=\"form-check-input\" type=\"radio\" name=\"folderName1RadioOptions\" id=\"folderName1Radio1\"\n                           value=\"mri\" [(ngModel)]=\"type1\">\n                    <label class=\"form-check-label\" for=\"folderName1Radio1\">MRI</label>\n                  </div>\n                  <div class=\"form-check form-check-inline\">\n                    <input class=\"form-check-input\" type=\"radio\" name=\"folderName1RadioOptions\" id=\"folderName1Radio2\"\n                           value=\"ct\" [(ngModel)]=\"type1\">\n                    <label class=\"form-check-label\" for=\"folderName1Radio2\">CT</label>\n                  </div>\n                  <div class=\"form-check form-check-inline\">\n                    <input class=\"form-check-input\" type=\"radio\" name=\"folderName1RadioOptions\" id=\"folderName1Radio3\"\n                           value=\"xray\" [(ngModel)]=\"type1\">\n                    <label class=\"form-check-label\" for=\"folderName1Radio3\">X-Ray</label>\n                  </div>\n                  <input ng2FileSelect [uploader]=\"uploader1\" type=\"file\" #file style=\"display: none;\"/> &nbsp;\n                  <button type=\"button\" class=\"btn btn-outline-dark btn-sm\" (click)=\"file.value='';file.click();\">\n                    Browse...\n                  </button>\n                  <br>\n                </div>\n              </div>\n\n\n            </div>\n            <div class=\"col-7\" style=\"border:1px solid black;\">\n              <div class=\"inner-container\">\n                <table class=\"table\">\n                  <tbody>\n                  <tr *ngFor=\"let item of uploader1.queue\">\n                    <td>\n                      <strong style=\"max-width:130px; display: block; overflow: hidden; text-overflow: ellipsis;\">{{ item?.file?.name }}</strong>\n                    </td>\n                    <td *ngIf=\"uploader1.isHTML5\" nowrap>{{ item?.file?.size/1024/1024 | number:'.2' }} MB</td>\n                    <td *ngIf=\"uploader1.isHTML5\">\n                      <div class=\"progress\" style=\"margin-bottom: 0;\">\n                        <div class=\"progress-bar\" role=\"progressbar\" [ngStyle]=\"{ 'width': item.progress + '%' }\"></div>\n                      </div>\n                    </td>\n                    <td class=\"text-center\">\n                        <span *ngIf=\"item.isSuccess\">\n                          <i class=\"glyphicon glyphicon-ok\"></i>\n                        </span>\n                      <span *ngIf=\"item.isCancel\">\n                          <i class=\"glyphicon glyphicon-ban-circle\"></i>\n                        </span>\n                      <span *ngIf=\"item.isError\">\n                          <i class=\"glyphicon glyphicon-remove\"></i>\n                        </span>\n                    </td>\n                    <td nowrap>\n                        <span class=\"progress\" style=\"width:600px; margin-top: 8px;\">\n                          <div class=\"progress-bar bg-dark progress-bar-striped progress-bar-animated\"\n                               role=\"progressbar\"\n                               [ngStyle]=\"{ 'width': uploader1.progress + '%' }\"></div>\n                        </span>\n                    </td>\n                    <td>\n                      <div class=\"pointer\" (click)=\"item.remove()\">\n                        <i class=\"fa fa-window-close fa-2x\"></i>\n                      </div>\n                    </td>\n                  </tr>\n                  </tbody>\n                </table>\n                <div>\n\n                </div>\n              </div>\n            </div>\n          </div>\n\n          <!-- ******** Second Patient ********-->\n          <div class=\"row\">\n            <div class=\"col-5\" style=\"border:1px solid black;\">\n              <div class=\"inner-container\">\n                <div class=\"input-group\">\n                  <div class=\"input-group-prepend\">\n                    <span class=\"input-group-text\">Target Folder</span>\n                  </div>\n                  <input type=\"text\" class=\"form-control\" id=\"targetFolder2\" name=\"targetFolder2\"\n                         [(ngModel)]=\"targetFolder2\" disabled/>&nbsp;&nbsp;\n                  <button class=\"btn btn-outline-dark btn-sm\" (click)=\"browseFolder2()\">Select Folder</button>\n                  <br>\n                </div>\n              </div>\n\n              <div class=\"inner-container\">\n                <div class=\"input-group\">\n                  <div class=\"input-group-prepend\">\n                    <span class=\"input-group-text\" id=\"basic-addon2\">Folder Name</span>\n                  </div>\n                  <input type=\"text\" class=\"form-control\" id=\"folderName2\" name=\"folderName2\"\n                         [(ngModel)]=\"folderName2\"/>&nbsp;&nbsp;\n                  <!-- Default checked -->\n                  <div class=\"form-check form-check-inline\">\n                    <input class=\"form-check-input\" type=\"radio\" name=\"folderName2RadioOptions\" id=\"folderName2Radio1\"\n                           value=\"mri\" [(ngModel)]=\"type2\">\n                    <label class=\"form-check-label\" for=\"folderName2Radio1\">MRI</label>\n                  </div>\n                  <div class=\"form-check form-check-inline\">\n                    <input class=\"form-check-input\" type=\"radio\" name=\"folderName2RadioOptions\" id=\"folderName2Radio2\"\n                           value=\"ct\" [(ngModel)]=\"type2\">\n                    <label class=\"form-check-label\" for=\"folderName2Radio2\">CT</label>\n                  </div>\n                  <div class=\"form-check form-check-inline\">\n                    <input class=\"form-check-input\" type=\"radio\" name=\"folderName2RadioOptions\" id=\"folderName2Radio3\"\n                           value=\"xray\" [(ngModel)]=\"type2\">\n                    <label class=\"form-check-label\" for=\"folderName2Radio3\">X-Ray</label>\n                  </div>\n                  <input ng2FileSelect [uploader]=\"uploader2\" type=\"file\" #file2 style=\"display: none;\"/> &nbsp;\n                  <button type=\"button\" class=\"btn btn-outline-dark btn-sm\" (click)=\"file2.value='';file2.click();\">\n                    Browse...\n                  </button>\n                  <br>\n                </div>\n              </div>\n            </div>\n            <div class=\"col-7\" style=\"border:1px solid black;\">\n              <div class=\"inner-container\">\n                <table class=\"table\">\n                  <tbody>\n                  <tr *ngFor=\"let item of uploader2.queue\">\n                    <td>\n                      <strong>{{ item?.file?.name }}</strong>\n                    </td>\n                    <td *ngIf=\"uploader2.isHTML5\" nowrap>{{ item?.file?.size/1024/1024 | number:'.2' }} MB</td>\n                    <td *ngIf=\"uploader2.isHTML5\">\n                      <div class=\"progress\" style=\"margin-bottom: 0;\">\n                        <div class=\"progress-bar\" role=\"progressbar\" [ngStyle]=\"{ 'width': item.progress + '%' }\"></div>\n                      </div>\n                    </td>\n                    <td class=\"text-center\">\n                        <span *ngIf=\"item.isSuccess\">\n                          <i class=\"glyphicon glyphicon-ok\"></i>\n                        </span>\n                      <span *ngIf=\"item.isCancel\">\n                          <i class=\"glyphicon glyphicon-ban-circle\"></i>\n                        </span>\n                      <span *ngIf=\"item.isError\">\n                          <i class=\"glyphicon glyphicon-remove\"></i>\n                        </span>\n                    </td>\n                    <td nowrap>\n                        <span class=\"progress\" style=\"width:600px; margin-top: 8px;\">\n                          <div class=\"progress-bar bg-dark progress-bar-striped progress-bar-animated\"\n                               role=\"progressbar\"\n                               [ngStyle]=\"{ 'width': uploader2.progress + '%' }\"></div>\n                        </span>\n                    </td>\n                    <td>\n                      <div class=\"pointer\" (click)=\"item.remove()\">\n                        <i class=\"fa fa-window-close fa-2x\"></i>\n                      </div>\n                    </td>\n                  </tr>\n                  </tbody>\n                </table>\n              </div>\n            </div>\n          </div>\n\n          <!-- ******** Third Patient ********-->\n          <div class=\"row\">\n            <div class=\"col-5\" style=\"border:1px solid black;\">\n              <div class=\"inner-container\">\n                <div class=\"input-group\">\n                  <div class=\"input-group-prepend\">\n                    <span class=\"input-group-text\">Target Folder</span>\n                  </div>\n                  <input type=\"text\" class=\"form-control\" id=\"targetFolder3\" name=\"targetFolder3\"\n                         [(ngModel)]=\"targetFolder3\" disabled/>&nbsp;&nbsp;\n                  <button class=\"btn btn-outline-dark btn-sm\" (click)=\"browseFolder3()\">Select Folder</button>\n                  <br>\n                </div>\n              </div>\n\n              <div class=\"inner-container\">\n                <div class=\"input-group\">\n                  <div class=\"input-group-prepend\">\n                    <span class=\"input-group-text\" id=\"basic-addon3\">Folder Name</span>\n                  </div>\n                  <input type=\"text\" class=\"form-control\" id=\"folderName3\" name=\"folderName3\"\n                         [(ngModel)]=\"folderName3\"/>&nbsp;&nbsp;\n                  <!-- Default checked -->\n                  <div class=\"form-check form-check-inline\">\n                    <input class=\"form-check-input\" type=\"radio\" name=\"folderName3RadioOptions\" id=\"folderName3Radio1\"\n                           value=\"mri\" [(ngModel)]=\"type3\">\n                    <label class=\"form-check-label\" for=\"folderName3Radio1\">MRI</label>\n                  </div>\n                  <div class=\"form-check form-check-inline\">\n                    <input class=\"form-check-input\" type=\"radio\" name=\"folderName3RadioOptions\" id=\"folderName3Radio2\"\n                           value=\"ct\" [(ngModel)]=\"type3\">\n                    <label class=\"form-check-label\" for=\"folderName3Radio2\">CT</label>\n                  </div>\n                  <div class=\"form-check form-check-inline\">\n                    <input class=\"form-check-input\" type=\"radio\" name=\"folderName3RadioOptions\" id=\"folderName3Radio3\"\n                           value=\"xray\" [(ngModel)]=\"type3\">\n                    <label class=\"form-check-label\" for=\"folderName3Radio3\">X-Ray</label>\n                  </div>\n                  <input ng2FileSelect [uploader]=\"uploader3\" type=\"file\" #file3 style=\"display: none;\"/> &nbsp;\n                  <button type=\"button\" class=\"btn btn-outline-dark btn-sm\" (click)=\"file3.value='';file3.click();\">\n                    Browse...\n                  </button>\n                  <br>\n                </div>\n              </div>\n            </div>\n            <div class=\"col-7\" style=\"border:1px solid black;\">\n              <div class=\"inner-container\">\n                <table class=\"table\">\n                  <tbody>\n                  <tr *ngFor=\"let item of uploader3.queue\">\n                    <td>\n                      <strong>{{ item?.file?.name }}</strong>\n                    </td>\n                    <td *ngIf=\"uploader3.isHTML5\" nowrap>{{ item?.file?.size/1024/1024 | number:'.2' }} MB</td>\n                    <td *ngIf=\"uploader3.isHTML5\">\n                      <div class=\"progress\" style=\"margin-bottom: 0;\">\n                        <div class=\"progress-bar\" role=\"progressbar\" [ngStyle]=\"{ 'width': item.progress + '%' }\"></div>\n                      </div>\n                    </td>\n                    <td class=\"text-center\">\n                        <span *ngIf=\"item.isSuccess\">\n                          <i class=\"glyphicon glyphicon-ok\"></i>\n                        </span>\n                      <span *ngIf=\"item.isCancel\">\n                          <i class=\"glyphicon glyphicon-ban-circle\"></i>\n                        </span>\n                      <span *ngIf=\"item.isError\">\n                          <i class=\"glyphicon glyphicon-remove\"></i>\n                        </span>\n                    </td>\n                    <td nowrap>\n                        <span class=\"progress\" style=\"width:600px; margin-top: 8px;\">\n                          <div class=\"progress-bar bg-dark progress-bar-striped progress-bar-animated\"\n                               role=\"progressbar\"\n                               [ngStyle]=\"{ 'width': uploader3.progress + '%' }\"></div>\n                        </span>\n                    </td>\n                    <td>\n                      <div class=\"pointer\" (click)=\"item.remove()\">\n                        <i class=\"fa fa-window-close fa-2x\"></i>\n                      </div>\n                    </td>\n                  </tr>\n                  </tbody>\n                </table>\n              </div>\n            </div>\n          </div>\n\n          <!-- ******** Fourth Patient ********-->\n          <div class=\"row\">\n            <div class=\"col-5\" style=\"border:1px solid black;\">\n              <div class=\"inner-container\">\n                <div class=\"input-group\">\n                  <div class=\"input-group-prepend\">\n                    <span class=\"input-group-text\">Target Folder</span>\n                  </div>\n                  <input type=\"text\" class=\"form-control\" id=\"targetFolder4\" name=\"targetFolder4\"\n                         [(ngModel)]=\"targetFolder4\" disabled/>&nbsp;&nbsp;\n                  <button class=\"btn btn-outline-dark btn-sm\" (click)=\"browseFolder4()\">Select Folder</button>\n                  <br>\n                </div>\n              </div>\n\n              <div class=\"inner-container\">\n                <div class=\"input-group\">\n                  <div class=\"input-group-prepend\">\n                    <span class=\"input-group-text\" id=\"basic-addon4\">Folder Name</span>\n                  </div>\n                  <input type=\"text\" class=\"form-control\" id=\"folderName4\" name=\"folderName4\"\n                         [(ngModel)]=\"folderName4\"/>&nbsp;&nbsp;\n                  <!-- Default checked -->\n                  <div class=\"form-check form-check-inline\">\n                    <input class=\"form-check-input\" type=\"radio\" name=\"folderName4RadioOptions\" id=\"folderName4Radio1\"\n                           value=\"mri\" [(ngModel)]=\"type4\">\n                    <label class=\"form-check-label\" for=\"folderName4Radio1\">MRI</label>\n                  </div>\n                  <div class=\"form-check form-check-inline\">\n                    <input class=\"form-check-input\" type=\"radio\" name=\"folderName4RadioOptions\" id=\"folderName4Radio2\"\n                           value=\"ct\" [(ngModel)]=\"type4\">\n                    <label class=\"form-check-label\" for=\"folderName4Radio2\">CT</label>\n                  </div>\n                  <div class=\"form-check form-check-inline\">\n                    <input class=\"form-check-input\" type=\"radio\" name=\"folderName4RadioOptions\" id=\"folderName4Radio3\"\n                           value=\"xray\" [(ngModel)]=\"type4\">\n                    <label class=\"form-check-label\" for=\"folderName4Radio3\">X-Ray</label>\n                  </div>\n                  <input ng2FileSelect [uploader]=\"uploader4\" type=\"file\" #file4 style=\"display: none;\"/> &nbsp;\n                  <button type=\"button\" class=\"btn btn-outline-dark btn-sm\" (click)=\"file4.value='';file4.click();\">\n                    Browse...\n                  </button>\n                  <br>\n                </div>\n              </div>\n            </div>\n            <div class=\"col-7\" style=\"border:1px solid black;\">\n              <div class=\"inner-container\">\n                <table class=\"table\">\n                  <tbody>\n                  <tr *ngFor=\"let item of uploader4.queue\">\n                    <td>\n                      <strong>{{ item?.file?.name }}</strong>\n                    </td>\n                    <td *ngIf=\"uploader4.isHTML5\" nowrap>{{ item?.file?.size/1024/1024 | number:'.2' }} MB</td>\n                    <td *ngIf=\"uploader4.isHTML5\">\n                      <div class=\"progress\" style=\"margin-bottom: 0;\">\n                        <div class=\"progress-bar\" role=\"progressbar\" [ngStyle]=\"{ 'width': item.progress + '%' }\"></div>\n                      </div>\n                    </td>\n                    <td class=\"text-center\">\n                        <span *ngIf=\"item.isSuccess\">\n                          <i class=\"glyphicon glyphicon-ok\"></i>\n                        </span>\n                      <span *ngIf=\"item.isCancel\">\n                          <i class=\"glyphicon glyphicon-ban-circle\"></i>\n                        </span>\n                      <span *ngIf=\"item.isError\">\n                          <i class=\"glyphicon glyphicon-remove\"></i>\n                        </span>\n                    </td>\n                    <td nowrap>\n                        <span class=\"progress\" style=\"width:600px; margin-top: 8px;\">\n                          <div class=\"progress-bar bg-dark progress-bar-striped progress-bar-animated\"\n                               role=\"progressbar\"\n                               [ngStyle]=\"{ 'width': uploader4.progress + '%' }\"></div>\n                        </span>\n                    </td>\n                    <td>\n                      <div class=\"pointer\" (click)=\"item.remove()\">\n                        <i class=\"fa fa-window-close fa-2x\"></i>\n                      </div>\n                    </td>\n                  </tr>\n                  </tbody>\n                </table>\n              </div>\n            </div>\n          </div>\n\n          <!-- ******** Fifth Patient ********-->\n          <div class=\"row\">\n            <div class=\"col-5\" style=\"border:1px solid black;\">\n              <div class=\"inner-container\">\n                <div class=\"input-group\">\n                  <div class=\"input-group-prepend\">\n                    <span class=\"input-group-text\">Target Folder</span>\n                  </div>\n                  <input type=\"text\" class=\"form-control\" id=\"targetFolder5\" name=\"targetFolder5\"\n                         [(ngModel)]=\"targetFolder5\" disabled/>&nbsp;&nbsp;\n                  <button class=\"btn btn-outline-dark btn-sm\" (click)=\"browseFolder5()\">Select Folder</button>\n                  <br>\n                </div>\n              </div>\n\n              <div class=\"inner-container\">\n                <div class=\"input-group\">\n                  <div class=\"input-group-prepend\">\n                    <span class=\"input-group-text\" id=\"basic-addon5\">Folder Name</span>\n                  </div>\n                  <input type=\"text\" class=\"form-control\" id=\"folderName5\" name=\"folderName5\"\n                         [(ngModel)]=\"folderName5\"/>&nbsp;&nbsp;\n                  <!-- Default checked -->\n                  <div class=\"form-check form-check-inline\">\n                    <input class=\"form-check-input\" type=\"radio\" name=\"folderName5RadioOptions\" id=\"folderName5Radio1\"\n                           value=\"mri\" [(ngModel)]=\"type5\">\n                    <label class=\"form-check-label\" for=\"folderName5Radio1\">MRI</label>\n                  </div>\n                  <div class=\"form-check form-check-inline\">\n                    <input class=\"form-check-input\" type=\"radio\" name=\"folderName5RadioOptions\" id=\"folderName5Radio2\"\n                           value=\"ct\" [(ngModel)]=\"type5\">\n                    <label class=\"form-check-label\" for=\"folderName5Radio2\">CT</label>\n                  </div>\n                  <div class=\"form-check form-check-inline\">\n                    <input class=\"form-check-input\" type=\"radio\" name=\"folderName5RadioOptions\" id=\"folderName5Radio3\"\n                           value=\"xray\" [(ngModel)]=\"type5\">\n                    <label class=\"form-check-label\" for=\"folderName5Radio3\">X-Ray</label>\n                  </div>\n                  <input ng2FileSelect [uploader]=\"uploader5\" type=\"file\" #file5 style=\"display: none;\"/> &nbsp;\n                  <button type=\"button\" class=\"btn btn-outline-dark btn-sm\" (click)=\"file5.value='';file5.click();\">\n                    Browse...\n                  </button>\n                  <br>\n                </div>\n              </div>\n            </div>\n            <div class=\"col-7\" style=\"border:1px solid black;\">\n              <div class=\"inner-container\">\n                <table class=\"table\">\n                  <tbody>\n                  <tr *ngFor=\"let item of uploader5.queue\">\n                    <td>\n                      <strong>{{ item?.file?.name }}</strong>\n                    </td>\n                    <td *ngIf=\"uploader5.isHTML5\" nowrap>{{ item?.file?.size/1024/1024 | number:'.2' }} MB</td>\n                    <td *ngIf=\"uploader5.isHTML5\">\n                      <div class=\"progress\" style=\"margin-bottom: 0;\">\n                        <div class=\"progress-bar\" role=\"progressbar\" [ngStyle]=\"{ 'width': item.progress + '%' }\"></div>\n                      </div>\n                    </td>\n                    <td class=\"text-center\">\n                        <span *ngIf=\"item.isSuccess\">\n                          <i class=\"glyphicon glyphicon-ok\"></i>\n                        </span>\n                      <span *ngIf=\"item.isCancel\">\n                          <i class=\"glyphicon glyphicon-ban-circle\"></i>\n                        </span>\n                      <span *ngIf=\"item.isError\">\n                          <i class=\"glyphicon glyphicon-remove\"></i>\n                        </span>\n                    </td>\n                    <td nowrap>\n                        <span class=\"progress\" style=\"width:600px; margin-top: 8px;\">\n                          <div class=\"progress-bar bg-dark progress-bar-striped progress-bar-animated\"\n                               role=\"progressbar\"\n                               [ngStyle]=\"{ 'width': uploader5.progress + '%' }\"></div>\n                        </span>\n                    </td>\n                    <td>\n                      <div class=\"pointer\" (click)=\"item.remove()\">\n                        <i class=\"fa fa-window-close fa-2x\"></i>\n                      </div>\n                    </td>\n                  </tr>\n                  </tbody>\n                </table>\n              </div>\n            </div>\n          </div>\n          <br>\n        </form>\n      </div>\n    </div>\n  </ng-sidebar-container>\n</div>\n<div *ngIf=\"loading\" class=\"text-center\" style=\"margin:150px 200px 0 200px\">\n  <i class=\"fa fa-spinner fa-5x faa-spin animated\"></i>\n</div>\n\n\n<ngx-smart-modal #myModal identifier=\"myModal\">\n  <h3>Select a Target Folder</h3>\n\n  <app-file-manager-tree [displayImage]=\"false\"></app-file-manager-tree>\n\n  <hr>\n\n  <div *ngIf=\"myModal.hasData()\">\n    <pre>{{ myModal.getData() | json }}</pre>\n  </div>\n  <button class=\"btn btn-sm btn-outline-dark pointer\" (click)=\"selectFolder()\">Select</button>\n\n  <button class=\"btn btn-sm btn-outline-dark pointer pull-right\" (click)=\"myModal.close()\">Close</button>\n\n</ngx-smart-modal>\n\n<ngx-smart-modal #uploadModal identifier=\"uploadModal\" [closable]=\"false\" [dismissable]=\"false\" [escapable]=\"false\">\n  <div class=\"text-left\">\n    <span *ngIf=\"!canProceed\">Please wait while uploading...&nbsp;&nbsp;&nbsp;&nbsp;<i class=\"fa fa-spinner fa-3x faa-spin animated\"></i>\n    </span>\n    <br><br>\n    <div *ngIf=\"!canProceed\" class=\"text-center\"><button class=\"btn btn-outline-dark\" (click)=\"onCancelUpload()\">Cancel</button></div>\n\n    <div *ngIf=\"canProceed\">\n      <h6 *ngIf=\"fileUpload1Success\">First File Upload Completed!</h6><h6 *ngIf=\"fileUpload1Error\">{{fileUpload1Message}}</h6>\n      <h6 *ngIf=\"fileUpload2Success\">Second File Upload Completed!</h6><h6 *ngIf=\"fileUpload2Error\">{{fileUpload2Message}}</h6>\n      <h6 *ngIf=\"fileUpload3Success\">Third File Upload Completed!</h6><h6 *ngIf=\"fileUpload3Error\">{{fileUpload3Message}}</h6>\n      <h6 *ngIf=\"fileUpload4Success\">Fourth File Upload Completed!</h6><h6 *ngIf=\"fileUpload4Error\">{{fileUpload4Message}}</h6>\n      <h6 *ngIf=\"fileUpload5Success\">Fifth File Upload Completed!</h6><h6 *ngIf=\"fileUpload5Error\">{{fileUpload5Message}}</h6>\n\n      <button class=\"btn btn-outline-dark btn-block\" (click)=\"onUploadFinished()\">OK</button>\n    </div>\n  </div>\n</ngx-smart-modal>\n"

/***/ }),

/***/ "./src/app/components/upload-images/upload-images.component.ts":
/*!*********************************************************************!*\
  !*** ./src/app/components/upload-images/upload-images.component.ts ***!
  \*********************************************************************/
/*! exports provided: UploadImagesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UploadImagesComponent", function() { return UploadImagesComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _app_const__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../app-const */ "./src/app/app-const.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/helper-service/helper.service */ "./src/app/services/helper-service/helper.service.ts");
/* harmony import */ var _services_user_service_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/user-service/user.service */ "./src/app/services/user-service/user.service.ts");
/* harmony import */ var _services_assignment_service_assignment_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/assignment-service/assignment.service */ "./src/app/services/assignment-service/assignment.service.ts");
/* harmony import */ var _models_assignment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../models/assignment */ "./src/app/models/assignment.ts");
/* harmony import */ var ng2_file_upload_ng2_file_upload__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ng2-file-upload/ng2-file-upload */ "./node_modules/ng2-file-upload/ng2-file-upload.js");
/* harmony import */ var ng2_file_upload_ng2_file_upload__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(ng2_file_upload_ng2_file_upload__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var ngx_smart_modal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ngx-smart-modal */ "./node_modules/ngx-smart-modal/esm5/ngx-smart-modal.js");
/* harmony import */ var _services_io_service_io_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../services/io-service/io.service */ "./src/app/services/io-service/io.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};










// const URL = 'http://localhost:8181/longwood-be/image/upload';
//const URL = 'http://192.144.132.111:8181/longwood-be/image/upload';
// const URL = 'http://140.143.15.26:8181/longwood-be/image/upload';
// const URL = 'http://localhost:8181/longwood-be/image/upload';
// const URL = 'http://192.144.132.111:8181/longwood-be/image/upload';
var URL = 'http://152.136.197.88:8181/longwood-be/image/upload';
// const URL = 'http://35.192.119.153:8181/longwood-be/image/upload';
var UploadImagesComponent = /** @class */ (function () {
    function UploadImagesComponent(helperService, assignmentService, userService, route, router, ngxSmartModalService, ioService) {
        var _this = this;
        this.helperService = helperService;
        this.assignmentService = assignmentService;
        this.userService = userService;
        this.route = route;
        this.router = router;
        this.ngxSmartModalService = ngxSmartModalService;
        this.ioService = ioService;
        this.uploader1 = new ng2_file_upload_ng2_file_upload__WEBPACK_IMPORTED_MODULE_7__["FileUploader"]({
            url: URL,
            allowedMimeType: ['application/zip', 'application/octet-stream', 'application/x-zip-compressed', 'multipart/x-zip']
        });
        this.uploader2 = new ng2_file_upload_ng2_file_upload__WEBPACK_IMPORTED_MODULE_7__["FileUploader"]({
            url: URL,
            allowedMimeType: ['application/zip', 'application/octet-stream', 'application/x-zip-compressed', 'multipart/x-zip']
        });
        this.uploader3 = new ng2_file_upload_ng2_file_upload__WEBPACK_IMPORTED_MODULE_7__["FileUploader"]({
            url: URL,
            allowedMimeType: ['application/zip', 'application/octet-stream', 'application/x-zip-compressed', 'multipart/x-zip']
        });
        this.uploader4 = new ng2_file_upload_ng2_file_upload__WEBPACK_IMPORTED_MODULE_7__["FileUploader"]({
            url: URL,
            allowedMimeType: ['application/zip', 'application/octet-stream', 'application/x-zip-compressed', 'multipart/x-zip']
        });
        this.uploader5 = new ng2_file_upload_ng2_file_upload__WEBPACK_IMPORTED_MODULE_7__["FileUploader"]({
            url: URL,
            allowedMimeType: ['application/zip', 'application/octet-stream', 'application/x-zip-compressed', 'multipart/x-zip']
        });
        this.duplicateUser = false;
        this.emptyStartDate = false;
        this.emptyEndDate = false;
        this.assignmentCreated = false;
        this.fileUploading = false;
        this.targetFolder1 = 'ROOT';
        this.targetFolder2 = 'ROOT';
        this.targetFolder3 = 'ROOT';
        this.targetFolder4 = 'ROOT';
        this.targetFolder5 = 'ROOT';
        this.type1 = 'ct';
        this.type2 = 'ct';
        this.type3 = 'ct';
        this.type4 = 'ct';
        this.type5 = 'ct';
        this.currentUserList = [];
        this.serverPath = _app_const__WEBPACK_IMPORTED_MODULE_1__["AppConst"].serverPath;
        this._opened = false;
        this.assignment = new _models_assignment__WEBPACK_IMPORTED_MODULE_6__["Assignment"]();
        this.patientNeeded = false;
        this.fileNeeded = false;
        this.noFileSelected = false;
        this.notZipFile = false;
        this.fileUploaded1 = true;
        this.fileUploaded2 = true;
        this.fileUploaded3 = true;
        this.fileUploaded4 = true;
        this.fileUploaded5 = true;
        this.fileUpload1Success = false;
        this.fileUpload2Success = false;
        this.fileUpload3Success = false;
        this.fileUpload4Success = false;
        this.fileUpload5Success = false;
        this.fileUpload1Error = false;
        this.fileUpload2Error = false;
        this.fileUpload3Error = false;
        this.fileUpload4Error = false;
        this.fileUpload5Error = false;
        this.canProceed = false;
        this.startCheck = false;
        this.route.params.forEach(function (params) {
            _this.assignmentId = Number.parseInt(params['id']);
        });
    }
    UploadImagesComponent.prototype.closeAlert = function () {
        this.patientNeeded = false;
        this.fileNeeded = false;
        this.noFileSelected = false;
        this.fileUploading = false;
    };
    UploadImagesComponent.prototype.onSelectImages = function () {
        var _this = this;
        if (this.uploader1.queue.length === 0 && this.uploader2.queue.length === 0 && this.uploader3.queue.length === 0 && this.uploader4.queue.length === 0 && this.uploader5.queue.length === 0) {
            this.fileNeeded = true;
            setTimeout(function () { return _this.fileNeeded = false; }, 5000);
            return;
        }
        this.router.navigate(['/selectImages'], { queryParams: { assignmentId: this.assignmentId } });
    };
    UploadImagesComponent.prototype.cancelUpload = function () {
        this.router.navigate(['/fileManager']);
    };
    UploadImagesComponent.prototype.onUploadAll = function () {
        var _this = this;
        this.startCheck = true;
        if (this.uploader1.queue.length === 0 && this.uploader2.queue.length === 0 && this.uploader3.queue.length === 0 && this.uploader4.queue.length === 0 && this.uploader5.queue.length === 0) {
            this.noFileSelected = true;
            setTimeout(function () { return _this.noFileSelected = false; }, 5000);
            return;
        }
        var uploaderList = [this.uploader1, this.uploader2, this.uploader3, this.uploader4, this.uploader5];
        this.fileUploading = true;
        this.uploader1.onBuildItemForm = function (item, form) {
            form.append('folderName', _this.folderName1);
            form.append('type', _this.type1);
            form.append('folderPath', _this.targetFolder1);
            _this.fileUploaded1 = false;
        };
        this.uploader1.uploadAll();
        this.uploader2.onBuildItemForm = function (item, form) {
            form.append('folderName', _this.folderName2);
            form.append('type', _this.type2);
            form.append('folderPath', _this.targetFolder2);
            _this.fileUploaded2 = false;
        };
        this.uploader2.uploadAll();
        this.uploader3.onBuildItemForm = function (item, form) {
            form.append('folderName', _this.folderName3);
            form.append('type', _this.type3);
            form.append('folderPath', _this.targetFolder3);
            _this.fileUploaded3 = false;
        };
        this.uploader3.uploadAll();
        this.uploader4.onBuildItemForm = function (item, form) {
            // form.append("assignmentId", this.assignmentId);
            form.append('folderName', _this.folderName4);
            form.append('type', _this.type4);
            form.append('folderPath', _this.targetFolder4);
            _this.fileUploaded4 = false;
        };
        this.uploader4.uploadAll();
        this.uploader5.onBuildItemForm = function (item, form) {
            // form.append("assignmentId", this.assignmentId);
            form.append('folderName', _this.folderName5);
            form.append('type', _this.type5);
            form.append('folderPath', _this.targetFolder5);
            _this.fileUploaded5 = false;
        };
        this.uploader5.uploadAll();
        this.ngxSmartModalService.getModal('uploadModal').open();
    };
    UploadImagesComponent.prototype.onSuccessItem1 = function (item, response, status, headers) {
        this.fileUploaded1 = true;
        this.fileUpload1Success = true;
    };
    UploadImagesComponent.prototype.onSuccessItem2 = function (item, response, status, headers) {
        this.fileUploaded2 = true;
        this.fileUpload2Success = true;
    };
    UploadImagesComponent.prototype.onSuccessItem3 = function (item, response, status, headers) {
        this.fileUploaded3 = true;
        this.fileUpload3Success = true;
    };
    UploadImagesComponent.prototype.onSuccessItem4 = function (item, response, status, headers) {
        this.fileUploaded4 = true;
        this.fileUpload4Success = true;
    };
    UploadImagesComponent.prototype.onSuccessItem5 = function (item, response, status, headers) {
        this.fileUploaded5 = true;
        this.fileUpload5Success = true;
    };
    UploadImagesComponent.prototype.onErrorItem1 = function (item, response, status, headers) {
        this.fileUploaded1 = true;
        this.fileUpload1Error = true;
        this.fileUpload1Message = 'Uploader 1 Error: ' + response;
        console.log(response);
        console.log(status);
    };
    UploadImagesComponent.prototype.onErrorItem2 = function (item, response, status, headers) {
        this.fileUploaded2 = true;
        this.fileUpload2Error = true;
        this.fileUpload2Message = 'Uploader 2 Error: ' + response;
    };
    UploadImagesComponent.prototype.onErrorItem3 = function (item, response, status, headers) {
        this.fileUploaded3 = true;
        this.fileUpload3Error = true;
        this.fileUpload3Message = 'Uploader 3 Error: ' + response;
    };
    UploadImagesComponent.prototype.onErrorItem4 = function (item, response, status, headers) {
        this.fileUploaded4 = true;
        this.fileUpload4Error = true;
        this.fileUpload4Message = 'Uploader 4 Error: ' + response;
    };
    UploadImagesComponent.prototype.onErrorItem5 = function (item, response, status, headers) {
        this.fileUploaded5 = true;
        this.fileUpload5Error = true;
        this.fileUpload5Message = 'Uploader 5 Error: ' + response;
    };
    UploadImagesComponent.prototype.browseFolder1 = function () {
        this.currentTargetFolder = 'targetFolder1';
        this.ngxSmartModalService.getModal('myModal').open();
    };
    UploadImagesComponent.prototype.browseFolder2 = function () {
        this.currentTargetFolder = 'targetFolder2';
        this.ngxSmartModalService.getModal('myModal').open();
    };
    UploadImagesComponent.prototype.browseFolder3 = function () {
        this.currentTargetFolder = 'targetFolder3';
        this.ngxSmartModalService.getModal('myModal').open();
    };
    UploadImagesComponent.prototype.browseFolder4 = function () {
        this.currentTargetFolder = 'targetFolder4';
        this.ngxSmartModalService.getModal('myModal').open();
    };
    UploadImagesComponent.prototype.browseFolder5 = function () {
        this.currentTargetFolder = 'targetFolder5';
        this.ngxSmartModalService.getModal('myModal').open();
    };
    UploadImagesComponent.prototype.selectFolder = function () {
        if (this.currentTargetFolder == 'targetFolder1') {
            this.targetFolder1 = this.tempFolder;
        }
        else if (this.currentTargetFolder == 'targetFolder2') {
            this.targetFolder2 = this.tempFolder;
        }
        else if (this.currentTargetFolder == 'targetFolder3') {
            this.targetFolder3 = this.tempFolder;
        }
        else if (this.currentTargetFolder == 'targetFolder4') {
            this.targetFolder4 = this.tempFolder;
        }
        else if (this.currentTargetFolder == 'targetFolder5') {
            this.targetFolder5 = this.tempFolder;
        }
        this.tempFolder = null;
        this.ngxSmartModalService.close('myModal');
    };
    UploadImagesComponent.prototype.onUploadFinished = function () {
        this.ngxSmartModalService.close('uploadModal');
        this.router.navigate(['/fileManager']);
    };
    UploadImagesComponent.prototype.onCancelUpload = function () {
        console.log(this.uploader1);
        this.uploader1.cancelAll();
        this.uploader2.cancelAll();
        this.uploader3.cancelAll();
        this.uploader4.cancelAll();
        this.uploader5.cancelAll();
        this.ngxSmartModalService.close('uploadModal');
    };
    UploadImagesComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.uploader1.onSuccessItem = function (item, response, status, headers) { return _this.onSuccessItem1(item, response, status, headers); };
        this.uploader2.onSuccessItem = function (item, response, status, headers) { return _this.onSuccessItem2(item, response, status, headers); };
        this.uploader3.onSuccessItem = function (item, response, status, headers) { return _this.onSuccessItem3(item, response, status, headers); };
        this.uploader4.onSuccessItem = function (item, response, status, headers) { return _this.onSuccessItem4(item, response, status, headers); };
        this.uploader5.onSuccessItem = function (item, response, status, headers) { return _this.onSuccessItem5(item, response, status, headers); };
        this.uploader1.onErrorItem = function (item, response, status, headers) { return _this.onErrorItem1(item, response, status, headers); };
        this.uploader2.onErrorItem = function (item, response, status, headers) { return _this.onErrorItem2(item, response, status, headers); };
        this.uploader3.onErrorItem = function (item, response, status, headers) { return _this.onErrorItem3(item, response, status, headers); };
        this.uploader4.onErrorItem = function (item, response, status, headers) { return _this.onErrorItem4(item, response, status, headers); };
        this.uploader5.onErrorItem = function (item, response, status, headers) { return _this.onErrorItem5(item, response, status, headers); };
        var that = this;
        setInterval(function () {
            that.canProceed = that.fileUploaded1 && that.fileUploaded2 && that.fileUploaded3 && that.fileUploaded4 && that.fileUploaded5 && that.fileUploading;
            if (that.uploader1.queue.length > 0) {
                var folder1 = that.uploader1.queue[0].file.name;
                that.folderName1 = folder1.substring(0, folder1.length - 4);
            }
            if (that.uploader2.queue.length > 0) {
                var folder2 = that.uploader2.queue[0].file.name;
                that.folderName2 = folder2.substring(0, folder2.length - 4);
            }
            if (that.uploader3.queue.length > 0) {
                var folder3 = that.uploader3.queue[0].file.name;
                that.folderName3 = folder3.substring(0, folder3.length - 4);
            }
            if (that.uploader4.queue.length > 0) {
                var folder4 = that.uploader4.queue[0].file.name;
                that.folderName4 = folder4.substring(0, folder4.length - 4);
            }
            if (that.uploader5.queue.length > 0) {
                var folder5 = that.uploader5.queue[0].file.name;
                that.folderName5 = folder5.substring(0, folder5.length - 4);
            }
        }, 500);
        // setInterval(function(){ alert("Hello"); }, 3000);
        this.helperService.sideMenuStatus$.subscribe(function (open) {
            _this._opened = open;
        });
        this.ioService.selectedFolder$.subscribe(function (selectedFolder) {
            _this.tempFolder = selectedFolder;
            console.log(selectedFolder);
        });
    };
    UploadImagesComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-upload-images',
            template: __webpack_require__(/*! ./upload-images.component.html */ "./src/app/components/upload-images/upload-images.component.html"),
            styles: [__webpack_require__(/*! ./upload-images.component.css */ "./src/app/components/upload-images/upload-images.component.css")]
        }),
        __metadata("design:paramtypes", [_services_helper_service_helper_service__WEBPACK_IMPORTED_MODULE_3__["HelperService"], _services_assignment_service_assignment_service__WEBPACK_IMPORTED_MODULE_5__["AssignmentService"], _services_user_service_user_service__WEBPACK_IMPORTED_MODULE_4__["UserService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], ngx_smart_modal__WEBPACK_IMPORTED_MODULE_8__["NgxSmartModalService"], _services_io_service_io_service__WEBPACK_IMPORTED_MODULE_9__["IoService"]])
    ], UploadImagesComponent);
    return UploadImagesComponent;
}());



/***/ }),

/***/ "./src/app/components/user-panel/user-panel.component.css":
/*!****************************************************************!*\
  !*** ./src/app/components/user-panel/user-panel.component.css ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".checkbox-group {\n\tmargin-left: 20px;\n\tmargin-top: 20px;\n}"

/***/ }),

/***/ "./src/app/components/user-panel/user-panel.component.html":
/*!*****************************************************************!*\
  !*** ./src/app/components/user-panel/user-panel.component.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "    <div class=\"checkbox-group\">\n      <div class=\"form-check\">\n        <input class=\"form-check-input\" type=\"checkbox\" id=\"gridCheck1\">\n        <label class=\"form-check-label\" for=\"gridCheck1\">\n          Check item 1 &nbsp;   <i class=\"fas fa-briefcase-medical\"></i>\n        </label>\n      </div>\n      <div class=\"form-check\">\n        <input class=\"form-check-input\" type=\"checkbox\" id=\"gridCheck2\">\n        <label class=\"form-check-label\" for=\"gridCheck2\">\n          Check item 2 &nbsp;   <i class=\"fas fa-briefcase-medical\"></i>\n        </label>\n      </div>\n      <div class=\"form-check\">\n        <input class=\"form-check-input\" type=\"checkbox\" id=\"gridCheck3\">\n        <label class=\"form-check-label\" for=\"gridCheck3\">\n          Check item 3 &nbsp;   <i class=\"fas fa-briefcase-medical\"></i>\n        </label>\n      </div>\n    </div>\n"

/***/ }),

/***/ "./src/app/components/user-panel/user-panel.component.ts":
/*!***************************************************************!*\
  !*** ./src/app/components/user-panel/user-panel.component.ts ***!
  \***************************************************************/
/*! exports provided: UserPanelComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserPanelComponent", function() { return UserPanelComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var UserPanelComponent = /** @class */ (function () {
    function UserPanelComponent() {
    }
    UserPanelComponent.prototype.ngOnInit = function () {
    };
    UserPanelComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-user-panel',
            template: __webpack_require__(/*! ./user-panel.component.html */ "./src/app/components/user-panel/user-panel.component.html"),
            styles: [__webpack_require__(/*! ./user-panel.component.css */ "./src/app/components/user-panel/user-panel.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], UserPanelComponent);
    return UserPanelComponent;
}());



/***/ }),

/***/ "./src/app/models/assignment.ts":
/*!**************************************!*\
  !*** ./src/app/models/assignment.ts ***!
  \**************************************/
/*! exports provided: Assignment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Assignment", function() { return Assignment; });
var Assignment = /** @class */ (function () {
    function Assignment() {
    }
    return Assignment;
}());



/***/ }),

/***/ "./src/app/models/user.ts":
/*!********************************!*\
  !*** ./src/app/models/user.ts ***!
  \********************************/
/*! exports provided: User */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "User", function() { return User; });
var User = /** @class */ (function () {
    function User() {
    }
    return User;
}());



/***/ }),

/***/ "./src/app/pipes/string-filter.pipe.ts":
/*!*********************************************!*\
  !*** ./src/app/pipes/string-filter.pipe.ts ***!
  \*********************************************/
/*! exports provided: StringFilterPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StringFilterPipe", function() { return StringFilterPipe; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var StringFilterPipe = /** @class */ (function () {
    function StringFilterPipe() {
    }
    // transform(items: any[], args: any): any[] {
    //   let isSearch = (data: any): boolean => {
    //     let isAll = false;
    //     if (typeof data === 'object') {
    //       for (let z in data) {
    //         if (isAll = isSearch(data[z])) {
    //           break;
    //         }
    //       }
    //     } else {
    //       if (typeof args === 'number') {
    //         isAll = data === args;
    //       } else {
    //         isAll = data.toString().match(new RegExp(args, 'i'));
    //       }
    //     }
    //
    //     return isAll;
    //   };
    //
    //   return items.filter(isSearch);
    // }
    StringFilterPipe.prototype.transform = function (items, filter) {
        if (!items || !filter) {
            return items;
        }
        // filter items array, items which match and return true will be
        // kept, false will be filtered out
        return items.filter(function (item) { return item.name.indexOf(filter) !== -1; });
    };
    StringFilterPipe = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Pipe"])({
            name: 'stringFilter'
        })
    ], StringFilterPipe);
    return StringFilterPipe;
}());



/***/ }),

/***/ "./src/app/services/assignment-service/assignment.service.ts":
/*!*******************************************************************!*\
  !*** ./src/app/services/assignment-service/assignment.service.ts ***!
  \*******************************************************************/
/*! exports provided: AssignmentService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AssignmentService", function() { return AssignmentService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var _app_const__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../app-const */ "./src/app/app-const.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var AssignmentService = /** @class */ (function () {
    function AssignmentService(http) {
        this.http = http;
    }
    AssignmentService.prototype.createAssignment = function (assignment) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + '/assignment/';
        var userIdList = [];
        for (var i in assignment.userList) {
            if (assignment.userList[i] != null) {
                userIdList.push(assignment.userList[i].id);
            }
        }
        var tagStr = '';
        var tagList = assignment.tagList;
        for (var i = 0; i < tagList.length; i++) {
            if (typeof tagList[i] === 'object') {
                tagStr += tagList[i].value + ',';
            }
            else {
                tagStr += tagList[i] + ',';
            }
        }
        var info = {
            'id': assignment.id,
            'name': assignment.name,
            'type': assignment.type,
            'description': assignment.description,
            'startDate': assignment.startDate,
            'endDate': assignment.endDate,
            'userIdList': userIdList,
            'tagList': tagStr
        };
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.post(url, info, { withCredentials: true, headers: header });
    };
    AssignmentService.prototype.getAllAssignments = function () {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + '/assignment/getAllAssignments/';
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.get(url, { withCredentials: true, headers: header });
    };
    AssignmentService.prototype.getAssigmentByAssignmentItemId = function (assignmentItemId) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + '/assignment/getAssignmentByAssignmentItemId/' + assignmentItemId;
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.get(url, { withCredentials: true, headers: header });
    };
    AssignmentService.prototype.getAssignmentItemListByUser = function () {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + '/assignment/getAssignmentItemListByUser/';
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.get(url, { withCredentials: true, headers: header });
    };
    AssignmentService.prototype.acceptAssignmentItem = function (assignmentId) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + '/assignment/acceptAssignmentItem';
        var info = {
            'id': assignmentId
        };
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.post(url, info, { withCredentials: true, headers: header });
    };
    AssignmentService.prototype.declineAssignmentItem = function (assignmentId) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + '/assignment/declineAssignmentItem';
        var info = {
            'id': assignmentId
        };
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.post(url, info, { withCredentials: true, headers: header });
    };
    AssignmentService.prototype.submitAssignment = function (assignmentItemId) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + '/assignment/submitAssignmentItem/' + assignmentItemId;
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.post(url, '', { withCredentials: true, headers: header });
    };
    AssignmentService.prototype.checkAssignmentItemFinished = function (assignmentItemId) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + '/assignment/checkAssignmentItemFinished/' + assignmentItemId;
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.post(url, '', { withCredentials: true, headers: header });
    };
    AssignmentService.prototype.getImageListByAssignment = function (id) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + '/assignment/getImageListByAssignment';
        var info = id;
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.post(url, info, { withCredentials: true, headers: header });
    };
    AssignmentService.prototype.completeAssignment = function (id) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + '/assignment/completeAssignment';
        var info = id;
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.post(url, info, { withCredentials: true, headers: header });
    };
    AssignmentService.prototype.getAssignmentItemListByAssignment = function (id) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + '/assignment/getAssignmentItemListByAssignment';
        var info = id;
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.post(url, info, { withCredentials: true, headers: header });
    };
    AssignmentService.prototype.setPickedImages = function (assignmentId, patientId, startImage, endImage) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + '/assignment/setPickedImages';
        var info = {
            'assignmentId': assignmentId,
            'patientId': patientId,
            'startImage': startImage,
            'endImage': endImage
        };
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.post(url, info, { withCredentials: true, headers: header });
    };
    AssignmentService.prototype.getAssignmentByAssignmentId = function (id) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + '/assignment/getAssignmentByAssignmentId/' + id;
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.get(url, { withCredentials: true, headers: header });
    };
    AssignmentService.prototype.selectAssignmentPatientFolder = function (assignmentId, itemList) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + '/assignment/selectAssignmentPatientFolder';
        var info = {
            'assignmentId': assignmentId,
            'itemList': itemList
        };
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.post(url, info, { withCredentials: true, headers: header });
    };
    AssignmentService.prototype.removeAssignmentByAssignmentId = function (id) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + '/assignment/deleteAssignmentByAssignmentId/' + id;
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.delete(url, { withCredentials: true, headers: header });
    };
    AssignmentService.prototype.getUnfinishedAssignmentItemDubListByUser = function () {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + '/assignment/getUnfinishedAssignmentItemDubListByUser';
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.get(url, { withCredentials: true, headers: header });
    };
    AssignmentService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_http__WEBPACK_IMPORTED_MODULE_1__["Http"]])
    ], AssignmentService);
    return AssignmentService;
}());



/***/ }),

/***/ "./src/app/services/helper-service/helper.service.ts":
/*!***********************************************************!*\
  !*** ./src/app/services/helper-service/helper.service.ts ***!
  \***********************************************************/
/*! exports provided: HelperService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HelperService", function() { return HelperService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var HelperService = /** @class */ (function () {
    function HelperService() {
        this.sideMenuSubject = new rxjs__WEBPACK_IMPORTED_MODULE_1__["Subject"]();
        this.sideMenuStatus$ = this.sideMenuSubject.asObservable();
        this.tagListSubject = new rxjs__WEBPACK_IMPORTED_MODULE_1__["Subject"]();
        this.tagList$ = this.tagListSubject.asObservable();
        this.tagSubject = new rxjs__WEBPACK_IMPORTED_MODULE_1__["Subject"]();
        this.tag$ = this.tagSubject.asObservable();
        this.selectedFolderSubject = new rxjs__WEBPACK_IMPORTED_MODULE_1__["Subject"]();
        this.selectedFolder$ = this.selectedFolderSubject.asObservable();
        this.folderActionSubject = new rxjs__WEBPACK_IMPORTED_MODULE_1__["Subject"]();
        this.folderAction$ = this.folderActionSubject.asObservable();
        this.clickAdminPanelSubject = new rxjs__WEBPACK_IMPORTED_MODULE_1__["Subject"]();
        this.clickAdminPanel$ = this.clickAdminPanelSubject.asObservable();
        this.displayImageContentSubject = new rxjs__WEBPACK_IMPORTED_MODULE_1__["Subject"]();
        this.displayImageContent$ = this.displayImageContentSubject.asObservable();
        this.currentFolderPathSubject = new rxjs__WEBPACK_IMPORTED_MODULE_1__["Subject"]();
        this.currentFolderPath$ = this.currentFolderPathSubject.asObservable();
        this.fetchDirectoryStructureSubject = new rxjs__WEBPACK_IMPORTED_MODULE_1__["Subject"]();
        this.fetchDirectoryStructure$ = this.fetchDirectoryStructureSubject.asObservable();
        this.onSwitchImageSubject = new rxjs__WEBPACK_IMPORTED_MODULE_1__["Subject"]();
        this.onSwitchImage$ = this.onSwitchImageSubject.asObservable();
    }
    Object.defineProperty(HelperService.prototype, "sideMenu", {
        set: function (open) {
            this.sideMenuSubject.next(open);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(HelperService.prototype, "tagList", {
        set: function (object) {
            this.tagListSubject.next(object);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(HelperService.prototype, "tag", {
        set: function (object) {
            this.tagSubject.next(object);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(HelperService.prototype, "selectedFolder", {
        set: function (object) {
            this.selectedFolderSubject.next(object);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(HelperService.prototype, "folderAction", {
        set: function (action) {
            this.folderActionSubject.next(action);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(HelperService.prototype, "displayImageContent", {
        set: function (imgObj) {
            this.displayImageContentSubject.next(imgObj);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(HelperService.prototype, "currentFolderPath", {
        set: function (path) {
            this.currentFolderPathSubject.next(path);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(HelperService.prototype, "onSwitchImage", {
        set: function (task) {
            this.onSwitchImageSubject.next(task);
        },
        enumerable: true,
        configurable: true
    });
    HelperService.prototype.setModifiedImageInfo = function (assignmentId, patientId, currentImage) {
        console.log(assignmentId);
        console.log(patientId);
        console.log(currentImage);
        this.assignmentId = assignmentId;
        this.patientId = patientId;
        this.currentImage = currentImage;
    };
    HelperService.prototype.getModifiedImageInfo = function () {
        var info = {
            'assignmentId': this.assignmentId,
            'patientId': this.patientId,
            'currentImage': this.currentImage
        };
        return info;
    };
    Object.defineProperty(HelperService.prototype, "clickAdminPanel", {
        set: function (click) {
            this.clickAdminPanelSubject.next(click);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(HelperService.prototype, "fetchDirectoryStructure", {
        set: function (needFetch) {
            this.fetchDirectoryStructureSubject.next(needFetch);
        },
        enumerable: true,
        configurable: true
    });
    HelperService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [])
    ], HelperService);
    return HelperService;
}());



/***/ }),

/***/ "./src/app/services/image-service/image.service.ts":
/*!*********************************************************!*\
  !*** ./src/app/services/image-service/image.service.ts ***!
  \*********************************************************/
/*! exports provided: ImageService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImageService", function() { return ImageService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var _app_const__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../app-const */ "./src/app/app-const.ts");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var ImageService = /** @class */ (function () {
    function ImageService(http) {
        this.http = http;
        this.currentImageSaved = true;
        this.descriptionSubject = new rxjs__WEBPACK_IMPORTED_MODULE_3__["Subject"]();
        this.currentDescriptionObject$ = this.descriptionSubject.asObservable();
        this.newDescriptionSubject = new rxjs__WEBPACK_IMPORTED_MODULE_3__["Subject"]();
        this.newDescriptionObject$ = this.newDescriptionSubject.asObservable();
        this.taskSubject = new rxjs__WEBPACK_IMPORTED_MODULE_3__["Subject"]();
        this.currentTaskStatus$ = this.taskSubject.asObservable();
        this.patientSubject = new rxjs__WEBPACK_IMPORTED_MODULE_3__["Subject"]();
        this.patientObject$ = this.patientSubject.asObservable();
    }
    ImageService.prototype.getImage = function (name) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + "/image/getImage/" + name + ".jpg";
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({});
        return this.http.get(url, { withCredentials: true, headers: header });
    };
    ImageService.prototype.getAllImagesByUser = function () {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + "/image/getAllImagesByUser";
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({});
        return this.http.get(url, { withCredentials: true, headers: header });
    };
    ImageService.prototype.saveImageAnnotation = function (rectList, dotList, task, state, dotDescriptionList, rectDescriptionList, dotTagList) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + "/image/saveImageAnnotation";
        var info = {
            "task": { id: task.id, taskStatus: task.taskStatus, description: task.description },
            "rectList": rectList,
            "dotList": dotList,
            "status": state,
            "dotDescriptionList": dotDescriptionList,
            "rectDescriptionList": rectDescriptionList,
            "dotTagList": dotTagList
        };
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.post(url, info, { withCredentials: true, headers: header });
    };
    ImageService.prototype.getAnnotationByTask = function (id) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + "/image/getAnnotationByTask/" + id;
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.get(url, { withCredentials: true, headers: header });
    };
    ImageService.prototype.setCurrentTask = function (task) {
        this.currentTask = task;
    };
    ImageService.prototype.getCurrentTask = function () {
        return this.currentTask;
    };
    ImageService.prototype.setCurrentImageAnnotation = function (annotation) {
        this.currentImageAnnotation = annotation;
    };
    ImageService.prototype.getCurrentImageAnnotation = function () {
        return this.currentImageAnnotation;
    };
    ImageService.prototype.setCurrentImageSaved = function (value) {
        this.currentImageSaved = value;
    };
    ImageService.prototype.getCurrentImageSaved = function () {
        return this.currentImageSaved;
    };
    Object.defineProperty(ImageService.prototype, "currentDescription", {
        set: function (object) {
            this.descriptionSubject.next(object);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ImageService.prototype, "newDescription", {
        set: function (object) {
            this.newDescriptionSubject.next(object);
        },
        enumerable: true,
        configurable: true
    });
    // setCurrentDescription(description) {
    //   console.log(description);
    //   this.descriptionSubject = description;
    // }
    ImageService.prototype.getCurrentDescription = function () {
        return this.descriptionSubject;
    };
    Object.defineProperty(ImageService.prototype, "taskStatus", {
        set: function (object) {
            this.taskSubject.next(object);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ImageService.prototype, "patient", {
        set: function (patient) {
            this.patientSubject.next(patient);
        },
        enumerable: true,
        configurable: true
    });
    ImageService.prototype.setCorrectImageTask = function (imageId, taskId) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + "/image/setCorrectImageTask";
        console.log(imageId, taskId);
        var info = {
            "imageId": imageId,
            "taskId": taskId
        };
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.post(url, info, { withCredentials: true, headers: header });
    };
    ImageService.prototype.getImageListByAssignmentAndPatient = function (assignmentId, patientName) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + "/image/getAllImagesByAssignmentAndPatient";
        var info = {
            "assignmentId": assignmentId,
            "patientName": patientName
        };
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.post(url, info, { withCredentials: true, headers: header });
    };
    ImageService.prototype.getPickedImageListByAssignmentAndPatient = function (assignmentId, patientId) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + "/image/getPickedImagesByAssignmentAndPatient";
        var info = {
            "assignmentId": assignmentId,
            "patientId": patientId
        };
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.post(url, info, { withCredentials: true, headers: header });
    };
    ImageService.prototype.getPickedImagesByAssignment = function (assignmentId) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + "/image/getPickedImagesByAssignment/" + assignmentId;
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.get(url, { withCredentials: true, headers: header });
    };
    ImageService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_http__WEBPACK_IMPORTED_MODULE_1__["Http"]])
    ], ImageService);
    return ImageService;
}());



/***/ }),

/***/ "./src/app/services/io-service/io.service.ts":
/*!***************************************************!*\
  !*** ./src/app/services/io-service/io.service.ts ***!
  \***************************************************/
/*! exports provided: IoService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IoService", function() { return IoService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var _app_const__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../app-const */ "./src/app/app-const.ts");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var IoService = /** @class */ (function () {
    function IoService(http) {
        this.http = http;
        this.fileListSubject = new rxjs__WEBPACK_IMPORTED_MODULE_3__["Subject"]();
        this.fileListStatus$ = this.fileListSubject.asObservable();
        this.fetchFileListSubject = new rxjs__WEBPACK_IMPORTED_MODULE_3__["Subject"]();
        this.fetchFileList$ = this.fetchFileListSubject.asObservable();
        this.selectedFolderSubject = new rxjs__WEBPACK_IMPORTED_MODULE_3__["Subject"]();
        this.selectedFolder$ = this.selectedFolderSubject.asObservable();
    }
    Object.defineProperty(IoService.prototype, "fileList", {
        set: function (fileList) {
            console.log(fileList);
            this.fileListSubject.next(fileList);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(IoService.prototype, "fetchFileList", {
        set: function (status) {
            this.fetchFileListSubject.next(status);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(IoService.prototype, "selectedFolder", {
        set: function (folderPath) {
            this.selectedFolderSubject.next(folderPath);
            console.log(folderPath);
        },
        enumerable: true,
        configurable: true
    });
    IoService.prototype.getDirectoryStructure = function () {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + "/io/directoryStructure";
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.get(url, { withCredentials: true, headers: header });
    };
    IoService.prototype.getFileList = function (path) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + "/io/getFileList";
        var info = {
            "path": path,
        };
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.post(url, info, { withCredentials: true, headers: header });
    };
    IoService.prototype.deleteFolder = function (folderNameList) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + '/io/deleteFolder';
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.post(url, folderNameList, { withCredentials: true, headers: header });
    };
    IoService.prototype.createFolder = function (folderPath, folderName, folderType) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + '/io/createNewFolder';
        var info = {
            'folderPath': folderPath,
            'folderName': folderName,
            'folderType': folderType
        };
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.post(url, info, { withCredentials: true, headers: header });
    };
    IoService.prototype.renameFolder = function (fileId, fileName) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + '/io/renameFile';
        var info = {
            'fileId': fileId,
            'fileName': fileName,
        };
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.post(url, info, { withCredentials: true, headers: header });
    };
    IoService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_http__WEBPACK_IMPORTED_MODULE_1__["Http"]])
    ], IoService);
    return IoService;
}());



/***/ }),

/***/ "./src/app/services/login-guard.service.ts":
/*!*************************************************!*\
  !*** ./src/app/services/login-guard.service.ts ***!
  \*************************************************/
/*! exports provided: LoginGuardService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginGuardService", function() { return LoginGuardService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _login_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.service */ "./src/app/services/login.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var LoginGuardService = /** @class */ (function () {
    function LoginGuardService(loginService, router) {
        this.loginService = loginService;
        this.router = router;
        this.loggedIn = false;
    }
    LoginGuardService.prototype.canActivate = function () {
        var _this = this;
        var res = this.loginService.checkLoggedIn();
        console.log(res);
        res.subscribe(function (res) {
            console.log(res);
        }, function (error) {
            _this.router.navigate(['/login']);
        });
        return res;
    };
    LoginGuardService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])(),
        __metadata("design:paramtypes", [_login_service__WEBPACK_IMPORTED_MODULE_1__["LoginService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], LoginGuardService);
    return LoginGuardService;
}());



/***/ }),

/***/ "./src/app/services/login.service.ts":
/*!*******************************************!*\
  !*** ./src/app/services/login.service.ts ***!
  \*******************************************/
/*! exports provided: LoginService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginService", function() { return LoginService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _app_const__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../app-const */ "./src/app/app-const.ts");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var LoginService = /** @class */ (function () {
    function LoginService(http, router) {
        this.http = http;
        this.router = router;
        this.serverPath = _app_const__WEBPACK_IMPORTED_MODULE_1__["AppConst"].serverPath;
    }
    LoginService.prototype.sendCredential = function (username, password) {
        var url = this.serverPath + '/login';
        var body = new URLSearchParams();
        body.set('username', username);
        body.set('password', password);
        var headers = new _angular_http__WEBPACK_IMPORTED_MODULE_2__["Headers"]({
            'Content-Type': 'application/x-www-form-urlencoded',
        });
        return this.http.post(url, body.toString(), { withCredentials: true, headers: headers });
    };
    LoginService.prototype.checkLoggedIn = function () {
        var url = this.serverPath + '/checkLoggedIn';
        var headers = new _angular_http__WEBPACK_IMPORTED_MODULE_2__["Headers"]({
            'Accept': 'application/json',
        });
        return this.http.get(url, { withCredentials: true, headers: headers }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(function (res) {
            if (res) {
                return true;
            }
            return false;
        }));
    };
    LoginService.prototype.checkSession = function () {
        var url = this.serverPath + '/checkSession';
        var headers = new _angular_http__WEBPACK_IMPORTED_MODULE_2__["Headers"]({
            'Accept': 'application/json',
        });
        return this.http.get(url, { withCredentials: true, headers: headers });
    };
    LoginService.prototype.logout = function () {
        var url = this.serverPath + '/logout';
        return this.http.post(url, '', { withCredentials: true });
    };
    LoginService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])(),
        __metadata("design:paramtypes", [_angular_http__WEBPACK_IMPORTED_MODULE_2__["Http"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]])
    ], LoginService);
    return LoginService;
}());



/***/ }),

/***/ "./src/app/services/patient-service/patient.service.ts":
/*!*************************************************************!*\
  !*** ./src/app/services/patient-service/patient.service.ts ***!
  \*************************************************************/
/*! exports provided: PatientService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PatientService", function() { return PatientService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var _app_const__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../app-const */ "./src/app/app-const.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var PatientService = /** @class */ (function () {
    function PatientService(http) {
        this.http = http;
    }
    PatientService.prototype.getPatientsByAssignment = function (assignmentId) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + "/patient/getPatientsByAssignment/" + assignmentId;
        // let info = {
        //   "assignmentId" : assignmentId,
        // };
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.get(url, { withCredentials: true, headers: header });
    };
    PatientService.prototype.getPatientsByAssignmentItem = function (assignmentItemId) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + "/patient/getPatientsByAssignmentItem/" + assignmentItemId;
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.get(url, { withCredentials: true, headers: header });
    };
    PatientService.prototype.getPatientByPatientId = function (patientId) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + "/patient/getPatientByPatientId/" + patientId;
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.get(url, { withCredentials: true, headers: header });
    };
    PatientService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_http__WEBPACK_IMPORTED_MODULE_1__["Http"]])
    ], PatientService);
    return PatientService;
}());



/***/ }),

/***/ "./src/app/services/segment-service/segment.service.ts":
/*!*************************************************************!*\
  !*** ./src/app/services/segment-service/segment.service.ts ***!
  \*************************************************************/
/*! exports provided: SegmentService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SegmentService", function() { return SegmentService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _app_const__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../app-const */ "./src/app/app-const.ts");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var SegmentService = /** @class */ (function () {
    function SegmentService(http) {
        this.http = http;
        this.serverPath = _app_const__WEBPACK_IMPORTED_MODULE_1__["AppConst"].serverPath;
    }
    SegmentService.prototype.getSegmentData = function (assignmentItemId, patientId) {
        var url = this.serverPath + '/segment/data';
        var info = {
            'assignmentItemId': assignmentItemId,
            'patientId': patientId
        };
        var headers = new _angular_http__WEBPACK_IMPORTED_MODULE_2__["Headers"]({
            'Accept': 'application/json',
        });
        return this.http.post(url, info, { withCredentials: true, headers: headers });
    };
    SegmentService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_http__WEBPACK_IMPORTED_MODULE_2__["Http"]])
    ], SegmentService);
    return SegmentService;
}());



/***/ }),

/***/ "./src/app/services/task-service/task.service.ts":
/*!*******************************************************!*\
  !*** ./src/app/services/task-service/task.service.ts ***!
  \*******************************************************/
/*! exports provided: TaskService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TaskService", function() { return TaskService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var _app_const__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../app-const */ "./src/app/app-const.ts");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var TaskService = /** @class */ (function () {
    function TaskService(http) {
        this.http = http;
        this.taskDescriptionSubject = new rxjs__WEBPACK_IMPORTED_MODULE_3__["Subject"]();
        this.taskDescription$ = this.taskDescriptionSubject.asObservable();
        this.newTaskDescriptionSubject = new rxjs__WEBPACK_IMPORTED_MODULE_3__["Subject"]();
        this.newTaskDescription$ = this.newTaskDescriptionSubject.asObservable();
        this.taskSubject = new rxjs__WEBPACK_IMPORTED_MODULE_3__["Subject"]();
        this.currentTaskStatus$ = this.taskSubject.asObservable();
        this.previousTaskSubject = new rxjs__WEBPACK_IMPORTED_MODULE_3__["Subject"]();
        this.previousTaskStatus$ = this.previousTaskSubject.asObservable();
    }
    TaskService.prototype.getTaskById = function (id) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + "/task/getTaskById/" + id;
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({});
        return this.http.get(url, { withCredentials: true, headers: header });
    };
    TaskService.prototype.getTaskListByUser = function () {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + "/task/getTaskListByUser";
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({});
        return this.http.get(url, { withCredentials: true, headers: header });
    };
    TaskService.prototype.setTaskStatus = function (task) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + "/task/setTaskStatus";
        var info = {
            "id": task.id,
            "status": task.status
        };
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.post(url, info, { withCredentials: true, headers: header });
    };
    Object.defineProperty(TaskService.prototype, "taskStatus", {
        set: function (object) {
            this.taskSubject.next(object);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TaskService.prototype, "previousTaskStatus", {
        set: function (object) {
            this.previousTaskSubject.next(object);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TaskService.prototype, "onTaskType", {
        get: function () {
            return this.currentTaskType;
        },
        set: function (type) {
            this.currentTaskType = type;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TaskService.prototype, "onTaskDescription", {
        set: function (obj) {
            this.taskDescriptionSubject.next(obj);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TaskService.prototype, "onNewTaskDescription", {
        set: function (obj) {
            this.newTaskDescriptionSubject.next(obj);
        },
        enumerable: true,
        configurable: true
    });
    TaskService.prototype.getTaskByAssignmentAndImage = function (assignmentId, imageId) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + "/task/getTaskListByAssignmentAndImage";
        var info = {
            "assignmentId": Number(assignmentId),
            "imageId": Number(imageId)
        };
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.post(url, info, { withCredentials: true, headers: header });
    };
    TaskService.prototype.getTaskListByAssignmentAndPatientAndUser = function (assignmentId, patientId) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + "/task/getTaskListByAssignmentAndPatientAndUser";
        var info = {
            "assignmentId": assignmentId,
            "patientId": patientId
        };
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        return this.http.post(url, info, { withCredentials: true, headers: header });
    };
    TaskService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_http__WEBPACK_IMPORTED_MODULE_1__["Http"]])
    ], TaskService);
    return TaskService;
}());



/***/ }),

/***/ "./src/app/services/user-service/user.service.ts":
/*!*******************************************************!*\
  !*** ./src/app/services/user-service/user.service.ts ***!
  \*******************************************************/
/*! exports provided: UserService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserService", function() { return UserService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var _app_const__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../app-const */ "./src/app/app-const.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var UserService = /** @class */ (function () {
    function UserService(http) {
        this.http = http;
    }
    UserService.prototype.getUser = function () {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + "/user/getUser";
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({});
        return this.http.get(url, { withCredentials: true, headers: header });
    };
    UserService.prototype.updateUser = function (user) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + "/user/updateUser";
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        var info = {
            "firstName": user.firstName,
            "lastName": user.lastName,
            "email": user.email,
            "phone": user.phone,
            "username": user.username,
            "id": user.id
        };
        return this.http.post(url, info, { withCredentials: true, headers: header });
    };
    UserService.prototype.updatePassword = function (currentPassword, newPassword) {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + "/user/updatePassword";
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({
            'Content-Type': 'application/json',
        });
        var info = {
            "currentPassword": currentPassword,
            "newPassword": newPassword
        };
        return this.http.post(url, info, { withCredentials: true, headers: header });
    };
    UserService.prototype.getUserList = function () {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + "/user/getUserList";
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({});
        return this.http.get(url, { withCredentials: true, headers: header });
    };
    UserService.prototype.getUserAssignmentItemInfo = function () {
        var url = _app_const__WEBPACK_IMPORTED_MODULE_2__["AppConst"].serverPath + "/user/getUserAssignmentItemInfo";
        var header = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({});
        return this.http.get(url, { withCredentials: true, headers: header });
    };
    UserService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_http__WEBPACK_IMPORTED_MODULE_1__["Http"]])
    ], UserService);
    return UserService;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * In development mode, to ignore zone related error stack frames such as
 * `zone.run`, `zoneDelegate.invokeTask` for easier debugging, you can
 * import the following file, but please comment it out in production mode
 * because it will have performance impact when throw error
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /Users/ledeng/projects/ai-image-label-webapp/longwood-fe/src/main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map